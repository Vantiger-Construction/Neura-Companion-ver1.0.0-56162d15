package com.neura;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

class NeuraClientTest {
  private static MockWebServer server;
  private NeuraClient client;

  @BeforeAll
  static void setup() throws Exception {
    server = new MockWebServer();
    server.start();
  }

  @AfterAll
  static void teardown() throws Exception {
    server.shutdown();
  }

  @BeforeEach
  void init() {
    String baseUrl = server.url("/").toString();
    client = new NeuraClient(baseUrl, "token");
  }

  @Test
  void testListResources() throws Exception {
    server.enqueue(new MockResponse().setBody("{"items":[]}").setResponseCode(200));
    String resp = client.listResources(0, 5);
    assertTrue(resp.contains("items"));
  }
}
