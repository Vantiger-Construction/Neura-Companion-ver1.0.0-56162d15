import axios from 'axios';
import { createNeuraClient } from '../index';

jest.mock('axios');

describe('React Native SDK', () => {
  const baseUrl = 'http://api.test';
  const token = 'test-token';
  const client = createNeuraClient(baseUrl, token);

  it('listResources calls correct endpoint', async () => {
    axios.create.mockReturnThis();
    axios.get.mockResolvedValue({ data: { items: [] }});
    const data = await client.listResources(0, 10);
    expect(axios.get).toHaveBeenCalledWith('/v1/resources', { params: { cursor: 0, limit: 10 } });
    expect(data).toEqual({ items: [] });
  });

  it('subscribe posts correctly', async () => {
    axios.post.mockResolvedValue({ data: { id: 1, url: 'u', eventType: 'e' }});
    const sub = await client.subscribe('u', 'e');
    expect(axios.post).toHaveBeenCalledWith('/v1/webhooks/subscribe', { url: 'u', eventType: 'e' });
    expect(sub).toEqual({ id: 1, url: 'u', eventType: 'e' });
  });
});
