package neura

import (
  "fmt"
  "net/http"
  "net/http/httptest"
  "testing"
)

func TestListResources(t *testing.T) {
  // Create a test server
  ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
    w.WriteHeader(200)
    fmt.Fprint(w, `{"items":[]}`)
  }))
  defer ts.Close()

  client := NewClient(ts.URL, "token")
  resp, err := client.ListResources(0, 10)
  if err != nil {
    t.Fatalf("Expected no error, got %v", err)
  }
  if resp.StatusCode != 200 {
    t.Errorf("Expected status 200, got %d", resp.StatusCode)
  }
}
