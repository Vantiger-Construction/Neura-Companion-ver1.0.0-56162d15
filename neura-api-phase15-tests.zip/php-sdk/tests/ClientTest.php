<?php
use PHPUnit\Framework\TestCase;
use Neura\Sdk\NeuraClient;
use GuzzleHttp\Client;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Psr7\Response;

class ClientTest extends TestCase {
  public function testListResources() {
    $mock = new MockHandler([new Response(200, [], json_encode(['items'=>[]]))]);
    $handler = HandlerStack::create($mock);
    $guzzle = new Client(['handler' => $handler]);
    // Override internal client via reflection if needed
    $client = new NeuraClient('http://test', 'token');
    $client->client = $guzzle;
    $result = $client->listResources();
    $this->assertArrayHasKey('items', $result);
  }
}
