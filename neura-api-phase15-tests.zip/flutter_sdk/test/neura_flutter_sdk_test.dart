import 'package:flutter_test/flutter_test.dart';
import 'package:neura_flutter_sdk/neura_flutter_sdk.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MockClient extends http.BaseClient {
  final http.Client _inner;
  MockClient(this._inner);
  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) {
    final response = http.Response(jsonEncode({'items': []}), 200);
    return Future.value(http.StreamedResponse(
      Stream.fromIterable([response.bodyBytes]), response.statusCode));
  }
}

void main() {
  test('listResources returns data', () async {
    final client = NeuraClient('http://test', 'token');
    http.Client original = client._inner;  // reflectively assign if needed
    client._inner = MockClient(original);
    final result = await client.listResources(cursor: 0, limit: 5);
    expect(result, contains('items'));
  });
}
