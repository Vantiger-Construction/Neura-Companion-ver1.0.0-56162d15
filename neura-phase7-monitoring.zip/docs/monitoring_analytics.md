# Monitoring & Analytics Enhancements

## Front-End Analytics
- Integrated Google Analytics via `react-ga`.  
- Logs page views and onboarding subscription events.  
- Configure `TRACKING_ID` in `src/analytics.js`.

## Business Metrics
- **feature_usage**: Counter for business features (e.g., onboarding, subscription).  
- **event_received_total**: Counter for total webhook events received.  

## Dashboards
- Grafana JSON at `monitoring/grafana/dashboards/business_metrics.json`.  
- Visualizes feature usage trends and event volumes.

## Next Steps
- Create alerts for key business metrics (e.g., sudden drop in events).  
- Integrate segment or alternative analytics providers as needed.
