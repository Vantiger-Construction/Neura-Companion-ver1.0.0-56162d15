import React, { useEffect } from 'react';
import { initGA, logPageView, logEvent } from './analytics';
...
function App() {
  useEffect(() => {
    initGA();
    logPageView();
    window.addEventListener('popstate', logPageView);
    return () => window.removeEventListener('popstate', logPageView);
  }, []);
  ...
}
...
export default App;
