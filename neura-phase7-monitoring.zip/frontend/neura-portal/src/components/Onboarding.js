...
import { logEvent } from '../analytics';
...
const subscribeDefault = (sub) => {
  axios.post('/v1/webhooks/subscribe', sub, {
    headers: { Authorization: `Bearer ${token}` }
  }).then(() => {
    alert(`Subscribed to ${sub.eventType}`);
    logEvent('Onboarding', `Subscribed to ${sub.eventType}`);
  });
};
...
