import ReactGA from 'react-ga';
const TRACKING_ID = 'UA-XXXXXXX-X'; // Replace with your tracking ID
export const initGA = () => ReactGA.initialize(TRACKING_ID);
export const logPageView = () => ReactGA.pageview(window.location.pathname + window.location.search);
export const logEvent = (category = '', action = '') => {
  if (category && action) {
    ReactGA.event({ category, action });
  }
};
