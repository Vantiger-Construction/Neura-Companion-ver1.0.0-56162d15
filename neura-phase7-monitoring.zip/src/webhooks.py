...
from src.metrics import record_event_received
...
@router.post("/receive", status_code=200)
async def receive_event(...):
    ...
    for sub in subs:
        dispatch_event.delay(sub.id, event)
    record_event_received()
    return {"dispatched": len(subs)}
