from prometheus_client import Counter, generate_latest, CONTENT_TYPE_LATEST
from fastapi import Response

# Existing metrics...
FEATURE_USAGE = Counter('feature_usage', 'Count of business feature usage', ['feature'])
EVENT_RECEIVED = Counter('event_received_total', 'Total number of webhook events received')

def record_feature(feature: str):
    FEATURE_USAGE.labels(feature=feature).inc()

def record_event_received():
    EVENT_RECEIVED.inc()

def metrics_endpoint():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)
