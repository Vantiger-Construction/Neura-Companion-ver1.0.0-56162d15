
import 'package:flutter/material.dart';

class MoodWeatherWidget extends StatelessWidget {
  final String mood;

  const MoodWeatherWidget({required this.mood, super.key});

  @override
  Widget build(BuildContext context) {
    String emoji = '🌥️';
    switch (mood) {
      case 'happy': emoji = '☀️'; break;
      case 'sad': emoji = '🌧️'; break;
      case 'angry': emoji = '⛈️'; break;
      case 'neutral': emoji = '🌤️'; break;
      case 'anxious': emoji = '🌪️'; break;
    }

    return AnimatedSwitcher(
      duration: Duration(milliseconds: 600),
      child: Text(
        emoji,
        key: ValueKey(mood),
        style: TextStyle(fontSize: 64),
      ),
    );
  }
}
