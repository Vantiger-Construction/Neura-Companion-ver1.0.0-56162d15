
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EmotionLogEntry {
  final DateTime time;
  final String mood;

  EmotionLogEntry(this.time, this.mood);
}

class EmotionMemory with ChangeNotifier {
  List<EmotionLogEntry> _log = [];

  List<EmotionLogEntry> get log => _log;

  void addMood(String mood) {
    final entry = EmotionLogEntry(DateTime.now(), mood);
    _log.add(entry);
    if (_log.length > 1000) _log.removeAt(0); // Limit memory size
    _saveLog();
    notifyListeners();
  }

  Future<void> _saveLog() async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = _log.map((e) => '${e.time.toIso8601String()}|${e.mood}').toList();
    prefs.setStringList('emotion_log', encoded);
  }

  Future<void> loadLog() async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = prefs.getStringList('emotion_log') ?? [];
    _log = encoded.map((line) {
      final parts = line.split('|');
      return EmotionLogEntry(DateTime.parse(parts[0]), parts[1]);
    }).toList();
    notifyListeners();
  }
}
