
# Neura Companion - Emotion Memory + Weather Mood

✅ Real-time emotion memory logging  
✅ Weather-style animated mood icons  
✅ Personality-based reply engine  
✅ Viseme mouth sync, voice recognition, TTS response

## Run:
flutter pub get  
flutter run
