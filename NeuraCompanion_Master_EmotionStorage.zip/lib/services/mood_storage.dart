
import 'package:hive/hive.dart';
import '../models/mood_entry.dart';

class MoodStorageService {
  static const String boxName = 'mood_entries';

  Future<void> init() async {
    await Hive.openBox<MoodEntry>(boxName);
  }

  List<MoodEntry> getAllEntries() {
    final box = Hive.box<MoodEntry>(boxName);
    return box.values.toList();
  }

  Future<void> addEntry(MoodEntry entry) async {
    final box = Hive.box<MoodEntry>(boxName);
    await box.add(entry);
  }

  Future<void> clearAll() async {
    final box = Hive.box<MoodEntry>(boxName);
    await box.clear();
  }
}
