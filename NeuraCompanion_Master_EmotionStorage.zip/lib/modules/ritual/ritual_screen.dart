
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../mood/mood_log.dart';
import '../mood/emotion_memory_graph.dart';

class RitualScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final moodLog = Provider.of<MoodLog>(context);

    return Scaffold(
      appBar: AppBar(title: Text("Ritual + Emotion Tracker")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: EmotionMemoryGraph(moodData: moodLog.entries),
      ),
    );
  }
}
