
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:screenshot/screenshot.dart';

class MoodEntry {
  final DateTime timestamp;
  final String emotion;
  final double intensity;

  MoodEntry(this.timestamp, this.emotion, this.intensity);
}

class EmotionMemoryGraph extends StatefulWidget {
  final List<MoodEntry> moodData;

  EmotionMemoryGraph({required this.moodData});

  @override
  _EmotionMemoryGraphState createState() => _EmotionMemoryGraphState();
}

class _EmotionMemoryGraphState extends State<EmotionMemoryGraph> {
  String selectedEmotion = 'joy';
  ScreenshotController screenshotController = ScreenshotController();

  List<String> get emotions {
    return widget.moodData.map((e) => e.emotion).toSet().toList();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = widget.moodData.where((entry) => entry.emotion == selectedEmotion).toList();

    final spots = filtered.map((entry) {
      final daysAgo = DateTime.now().difference(entry.timestamp).inDays;
      return FlSpot(-daysAgo.toDouble(), entry.intensity);
    }).toList();

    return Column(
      children: [
        DropdownButton<String>(
          value: selectedEmotion,
          onChanged: (value) => setState(() => selectedEmotion = value!),
          items: emotions.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        ),
        Screenshot(
          controller: screenshotController,
          child: AspectRatio(
            aspectRatio: 1.6,
            child: LineChart(LineChartData(
              gridData: FlGridData(show: true),
              titlesData: FlTitlesData(show: true),
              lineBarsData: [
                LineChartBarData(
                  spots: spots,
                  isCurved: true,
                  colors: [Colors.blueAccent],
                  barWidth: 3,
                  belowBarData: BarAreaData(show: true, colors: [Colors.blue.withOpacity(0.3)]),
                ),
              ],
            )),
          ),
        ),
        ElevatedButton.icon(
          icon: Icon(Icons.download),
          label: Text("Export PNG"),
          onPressed: () async {
            final image = await screenshotController.capture();
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Graph captured as PNG')));
            // Save to gallery or local storage here (platform-specific)
          },
        )
      ],
    );
  }
}
