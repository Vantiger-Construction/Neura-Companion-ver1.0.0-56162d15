
import 'package:flutter/foundation.dart';
import '../../models/mood_entry.dart';
import '../../services/mood_storage.dart';

class MoodLog with ChangeNotifier {
  final MoodStorageService _storage = MoodStorageService();
  List<MoodEntry> _entries = [];

  MoodLog() {
    _entries = _storage.getAllEntries();
  }

  List<MoodEntry> get entries => _entries;

  void addEntry(MoodEntry entry) async {
    await _storage.addEntry(entry);
    _entries = _storage.getAllEntries();
    notifyListeners();
  }
}
