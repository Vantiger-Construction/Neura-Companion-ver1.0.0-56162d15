
import 'package:hive/hive.dart';

part 'mood_entry.g.dart';

@HiveType(typeId: 0)
class MoodEntry extends HiveObject {
  @HiveField(0)
  DateTime timestamp;

  @HiveField(1)
  String emotion;

  @HiveField(2)
  double intensity;

  MoodEntry(this.timestamp, this.emotion, this.intensity);
}
