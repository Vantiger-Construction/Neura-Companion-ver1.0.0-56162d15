
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'models/mood_entry.dart';
import 'modules/mood/mood_log.dart';
import 'modules/journal/journal_screen.dart';
import 'modules/ritual/ritual_screen.dart';
import 'services/mood_storage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(MoodEntryAdapter());
  await MoodStorageService().init();
  runApp(
    ChangeNotifierProvider(
      create: (_) => MoodLog(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool showRitual = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text(showRitual ? "Ritual Tracker" : "Journal Tracker"),
          actions: [
            IconButton(
              icon: Icon(Icons.swap_horiz),
              onPressed: () => setState(() => showRitual = !showRitual),
            )
          ],
        ),
        body: showRitual ? RitualScreen() : JournalScreen(),
      ),
    );
  }
}
