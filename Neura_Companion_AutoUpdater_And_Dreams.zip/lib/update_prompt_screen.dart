// Neura animated screen to offer the update

// TODO: Implement