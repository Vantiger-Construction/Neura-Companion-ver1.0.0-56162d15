// Checks version.txt online and prompts user if newer version found

// TODO: Implement