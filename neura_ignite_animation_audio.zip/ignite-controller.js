// Load animations + trigger audio lines based on emotion and location
