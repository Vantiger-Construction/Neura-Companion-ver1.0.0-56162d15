import os
import hvac
import datetime

def rotate_secret(secret_path, key):
    vault_addr = os.getenv('VAULT_ADDR')
    vault_token = os.getenv('VAULT_TOKEN')
    client = hvac.Client(url=vault_addr, token=vault_token)
    new_value = os.urandom(32).hex()
    client.secrets.kv.v2.create_or_update_secret(
        path=secret_path,
        secret={key: new_value},
    )
    print(f"Rotated {key} at {secret_path} to new value.")
    return new_value

if __name__ == "__main__":
    # Example: rotate DB password
    secret_path = 'neura/db'
    key = 'DATABASE_PASSWORD'
    new_pw = rotate_secret(secret_path, key)
    # Additional logic: update deployment or ConfigMap as needed with new_pw
