# Security & Compliance Finalization

## Container Scanning
- GitHub Action `trivy_scan.yml` scans Docker images for critical/high vulnerabilities.

## DAST
- OWASP ZAP full scan available via `zap_full_scan.yml`.

## Secret Rotation
- `scripts/rotate_vault_secrets.py` rotates secrets in Vault.

## Policy as Code
- OPA Gatekeeper policy `image_registry_policy.yaml` enforces approved image registries.

## Next Steps
- Schedule secret rotation via cron or CI.
- Review OPA policies for additional controls.
- Perform manual penetration tests as needed.
