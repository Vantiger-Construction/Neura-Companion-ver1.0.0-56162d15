@echo off
cd /d "%~dp0build\windows\runner\Release"
start Neuro_Companion.exe
