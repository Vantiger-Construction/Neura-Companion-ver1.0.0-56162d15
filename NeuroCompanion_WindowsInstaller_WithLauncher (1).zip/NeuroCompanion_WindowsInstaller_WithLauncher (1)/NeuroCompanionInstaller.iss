
[Setup]
AppName=Neuro Companion
AppVersion=1.0
DefaultDirName={pf}\NeuroCompanion
DefaultGroupName=Neuro Companion
OutputDir=dist
OutputBaseFilename=NeuroCompanionInstaller
Compression=lzma
SolidCompression=yes

[Files]
Source: "build\windows\runner\Release\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs

[Icons]
Name: "{group}\Neuro Companion"; Filename: "{app}\Neuro_Companion.exe"
Name: "{group}\Uninstall Neuro Companion"; Filename: "{uninstallexe}"
