
# Neuro Companion Windows Installer Instructions

1. Download and install Inno Setup from https://jrsoftware.org/isinfo.php
2. Open the file `NeuroCompanionInstaller.iss` in Inno Setup.
3. Click "Compile" to generate your installer.
4. The output `.exe` installer will appear in the `dist/` folder.
5. Share and install the app easily on any Windows machine!

Make sure your actual `Neuro_Companion.exe` is compiled in `build/windows/runner/Release/` before compiling the installer.
