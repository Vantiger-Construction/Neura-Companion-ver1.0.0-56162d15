$Shell = New-Object -ComObject ("WScript.Shell")
$StartupFolder = $Shell.SpecialFolders.Item("Startup")
$Shortcut = $Shell.CreateShortcut("$StartupFolder\Neuro Companion.lnk")
$Shortcut.TargetPath = "$PSScriptRoot\build\windows\runner\Release\Neuro_Companion.exe"
$Shortcut.WorkingDirectory = "$PSScriptRoot\build\windows\runner\Release"
$Shortcut.Save()
Write-Host "Neuro Companion has been added to Windows Startup!"
