#!/usr/bin/env bash
set -e
echo "Generating TypeScript types..."
cd backend
npx graphql-codegen --config codegen.yml
echo "Generating Dart types..."
cd ../client
flutter pub run build_runner build --delete-conflicting-outputs
echo "Code generation complete."
