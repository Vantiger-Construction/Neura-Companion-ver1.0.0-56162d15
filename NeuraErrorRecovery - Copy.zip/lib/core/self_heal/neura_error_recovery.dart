import 'dart:developer' as dev;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class NeuraErrorMonitor {
  static void init() {
    FlutterError.onError = (FlutterErrorDetails details) async {
      dev.log('⚠️ FlutterError caught: \${details.exceptionAsString()}');
      await NeuraAutoFixEngine.handle(details);
    };

    PlatformDispatcher.instance.onError = (error, stack) {
      dev.log('⚠️ PlatformError: \$error');
      NeuraAutoFixEngine.handleRaw(error, stack);
      return true;
    };
  }
}

class NeuraAutoFixEngine {
  static Future<void> handle(FlutterErrorDetails details) async {
    final error = details.exceptionAsString();
    final contextHint = details.context?.toDescription() ?? "unknown context";

    if (error.contains('setState()')) {
      await _retryDelayed(contextHint);
    } else if (error.contains('null') || error.contains('NoSuchMethodError')) {
      await _nullFixAttempt(contextHint);
    } else {
      await _fallbackReport(error, contextHint);
    }
  }

  static void handleRaw(Object error, StackTrace stack) {
    dev.log('🧠 Neura AI - trying self-repair...');
  }

  static Future<void> _retryDelayed(String context) async {
    dev.log('🧪 Retrying widget logic for context: \$context');
    await Future.delayed(Duration(milliseconds: 300));
  }

  static Future<void> _nullFixAttempt(String context) async {
    dev.log('🛠 Null fix: setting default values for: \$context');
  }

  static Future<void> _fallbackReport(String error, String context) async {
    dev.log('📡 Logging to NeuraErrorLogService...');
    await NeuraErrorLogService.log(error, context);
    NeuraFeedbackBubble.show("Oops! Neura fixed something silently.");
  }
}

class NeuraErrorLogService {
  static Future<void> log(String error, String context) async {
    dev.log('📄 Logged Error: [\$context] \$error');
  }
}

class NeuraFeedbackBubble {
  static void show(String msg) {
    dev.log("💬 NeuraBubble: \$msg");
  }
}