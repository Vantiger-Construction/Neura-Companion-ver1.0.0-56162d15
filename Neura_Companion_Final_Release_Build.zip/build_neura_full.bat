@echo off
title Neura Companion Full Build Script
color 0A

:: Setup
set "ROOT=%~dp0"
set "EXE_DIR=%ROOT%win_installer"
set "APK_DIR=%ROOT%apk_build"
set "WEB_DIR=%ROOT%web_preview"
set "VOICE_DIR=%ROOT%voice_assets"
set "FIREBASE_CONFIG=%ROOT%firebase.json"

echo [🔧] Starting Neura Companion Build...

:: Build Windows EXE
if exist "%EXE_DIR%\setup.exe" (
  echo [🪟] Found EXE stub, running installer build...
  start "" "%EXE_DIR%\setup.exe"
) else (
  echo [⚠️] EXE stub missing! Neura says: 'Oops, maybe a parallel universe has it.'
)

:: Build Android APK
if exist "%APK_DIR%\build.bat" (
  echo [📱] Launching APK build...
  call "%APK_DIR%\build.bat"
) else (
  echo [⚠️] No APK builder found. Neura says: 'Flutter might be asleep...'
)

:: Copy Web Preview to GitHub Pages
if exist "%WEB_DIR%\index.html" (
  echo [🌐] Deploying Web Preview to GitHub Pages...
  xcopy "%WEB_DIR%\*" "%ROOT%gh-pages" /s /e /y
  echo [✅] Web Preview staged in 'gh-pages' folder.
) else (
  echo [⚠️] Web content not found. Neura says: 'Dreaming of pixels...'
)

:: Firebase Deploy
if exist "%FIREBASE_CONFIG%" (
  echo [🚀] Firebase config found. Running deploy...
  firebase deploy --only hosting
) else (
  echo [⚠️] Firebase config not found. Neura says: 'I can host dreams, but not files... yet.'
)

:: Voice & Viseme Sync
if exist "%VOICE_DIR%\neura_voice.mp3" (
  echo [🎙️] Neura’s voice found! Embedding into engine...
  copy "%VOICE_DIR%\neura_voice.mp3" "%ROOT%speech_system"
) else (
  echo [⚠️] No voice file. Neura says: 'Silent mode... engage.'
)

:: Done
echo [✅] Neura Companion Build Complete!
pause
exit
