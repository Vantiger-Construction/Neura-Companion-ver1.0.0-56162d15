from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app import auth, mood, events, admin

app = FastAPI(
    title="Neura Companion API",
    description="The world's smartest, most interactive AI Companion platform. Real-time, emotional, and admin-friendly.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    contact={
        "name": "Neura Dev Team",
        "url": "https://neuracompanion.com",
        "email": "dev@neuracompanion.com",
    },
    license_info={
        "name": "MIT License",
        "url": "https://opensource.org/licenses/MIT",
    }
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api/v1/auth", tags=["auth"])
app.include_router(mood.router, prefix="/api/v1/mood", tags=["mood"])
app.include_router(events.router, prefix="/api/v1/events", tags=["events"])
app.include_router(admin.router, prefix="/api/v1/admin", tags=["admin"])
