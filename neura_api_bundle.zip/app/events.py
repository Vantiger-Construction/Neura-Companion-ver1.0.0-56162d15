from fastapi import APIRouter, Depends
from app.auth import get_current_user, require_admin, User
import datetime

router = APIRouter()

event_log = []

class EventEntry:
    def __init__(self, user, event_type, payload):
        self.timestamp = datetime.datetime.utcnow()
        self.user = user
        self.event_type = event_type
        self.payload = payload

    def dict(self):
        return {
            "timestamp": self.timestamp.isoformat(),
            "user": self.user,
            "event_type": self.event_type,
            "payload": self.payload,
        }

@router.get("/", summary="Get event logs", description="Admin only: View all API event logs")
def get_events(admin=Depends(require_admin)):
    return [e.dict() for e in event_log]

@router.post("/webhook-test", summary="Trigger webhook (demo)", description="Test sending a fake webhook event.")
def webhook_test(url: str, event: str, payload: dict, admin=Depends(require_admin)):
    print(f"Would send webhook to {url}: {event} - {payload}")
    return {"detail": "Webhook trigger simulated."}
