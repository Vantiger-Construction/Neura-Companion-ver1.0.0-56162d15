from fastapi import APIRouter, Depends, HTTPException
from app.auth import require_admin, users_db
from app.mood import user_moods

router = APIRouter()

@router.get("/users", summary="List all users", description="Admin only: Get all usernames and roles.")
def list_users(admin=Depends(require_admin)):
    return [{"username": user, "role": users_db[user]["role"]} for user in users_db]

@router.get("/moods", summary="Get all mood entries", description="Admin only: View all users' mood logs.")
def dump_all_moods(admin=Depends(require_admin)):
    return {
        user: [m.dict() for m in moods]
        for user, moods in user_moods.items()
    }

@router.post("/reset-password", summary="Reset a user password", description="Admin only: Set a new password for any user.")
def reset_password(username: str, new_password: str, admin=Depends(require_admin)):
    if username not in users_db:
        raise HTTPException(status_code=404, detail="User not found.")
    users_db[username]["password"] = new_password
    return {"detail": f"Password for {username} reset."}

@router.post("/nuke", summary="Danger Zone: Nuke everything", description="Dev only: Destroys all data (do not use in prod!)")
def nuke(admin=Depends(require_admin)):
    user_moods.clear()
    return {"detail": "All mood logs wiped! You monster."}
