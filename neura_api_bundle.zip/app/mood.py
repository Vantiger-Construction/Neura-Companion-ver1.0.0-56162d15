from fastapi import APIRouter, HTTPException, Depends, Path, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
from typing import List, Optional
from app.auth import get_current_user, User
from app.events import event_log, EventEntry
import datetime
from collections import defaultdict
import asyncio

router = APIRouter()

user_moods = {}
active_connections = defaultdict(list)

class MoodEntry(BaseModel):
    mood: str
    note: Optional[str] = None
    timestamp: datetime.datetime

class MoodSubmit(BaseModel):
    mood: str
    note: Optional[str] = None

class MoodEdit(BaseModel):
    mood: Optional[str] = None
    note: Optional[str] = None

async def notify_user(username, data):
    for ws in list(active_connections.get(username, [])):
        try:
            await ws.send_json(data)
        except Exception:
            pass

@router.post("/", response_model=MoodEntry)
def submit_mood(mood: MoodSubmit, user: User = Depends(get_current_user)):
    entry = MoodEntry(
        mood=mood.mood,
        note=mood.note,
        timestamp=datetime.datetime.utcnow()
    )
    moods = user_moods.setdefault(user.username, [])
    moods.append(entry)
    asyncio.create_task(notify_user(user.username, {"type": "new", "mood": entry.dict()}))
    event_log.append(EventEntry(user.username, "mood_submit", entry.dict()))
    return entry

@router.get(
    "/", response_model=List[MoodEntry],
    summary="Get mood history",
    description="Returns up to the latest 20 mood entries for the authenticated user."
)
def get_mood_history(limit: int = 20, user: User = Depends(get_current_user)):
    moods = user_moods.get(user.username, [])
    return list(reversed(moods))[:limit]

@router.get("/latest", response_model=MoodEntry)
def get_latest_mood(user: User = Depends(get_current_user)):
    moods = user_moods.get(user.username, [])
    if not moods:
        raise HTTPException(
            status_code=404,
            detail="No mood recorded yet. Feeling mysterious?"
        )
    return moods[-1]

@router.put("/{timestamp}", response_model=MoodEntry)
def edit_mood(
    timestamp: str = Path(..., description="ISO timestamp of the mood to edit"),
    edit: MoodEdit = None,
    user: User = Depends(get_current_user)
):
    moods = user_moods.get(user.username, [])
    for entry in moods:
        if entry.timestamp.isoformat() == timestamp:
            if edit.mood:
                entry.mood = edit.mood
            if edit.note is not None:
                entry.note = edit.note
            asyncio.create_task(notify_user(user.username, {"type": "edit", "mood": entry.dict()}))
            event_log.append(EventEntry(user.username, "mood_edit", entry.dict()))
            return entry
    raise HTTPException(
        status_code=404,
        detail=f"Mood with timestamp {timestamp} not found. The plot thickens."
    )

@router.delete("/{timestamp}", response_model=MoodEntry)
def delete_mood(
    timestamp: str = Path(..., description="ISO timestamp of the mood to delete"),
    user: User = Depends(get_current_user)
):
    moods = user_moods.get(user.username, [])
    for i, entry in enumerate(moods):
        if entry.timestamp.isoformat() == timestamp:
            removed = moods.pop(i)
            asyncio.create_task(notify_user(user.username, {"type": "delete", "timestamp": timestamp}))
            event_log.append(EventEntry(user.username, "mood_delete", entry.dict()))
            return removed
    raise HTTPException(
        status_code=404,
        detail=f"Mood with timestamp {timestamp} not found. Either it never existed, or it's in the Twilight Zone."
    )

@router.websocket("/ws")
async def mood_ws(websocket: WebSocket):
    token = websocket.query_params.get("token") or websocket.headers.get("Authorization", "").replace("Bearer ", "")
    try:
        user = get_current_user(token)
    except Exception as e:
        await websocket.close(code=4001)
        return
    username = user.username
    await websocket.accept()
    active_connections[username].append(websocket)
    try:
        moods = user_moods.get(username, [])
        await websocket.send_json({"type": "history", "moods": [m.dict() for m in moods]})
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        if websocket in active_connections[username]:
            active_connections[username].remove(websocket)
