# Neura Companion API Demo

## Quickstart

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Auth
POST /api/v1/auth/token
(username: tigger, password: neura_is_best)

## Endpoints
- Mood CRUD (with real-time WebSocket streaming)
- Admin tools: user list, dump moods, password reset, nuke all
- Event log & webhook test
- Full OpenAPI docs at /docs

## Docker

```bash
docker build -t neura-api .
docker run -p 8000:8000 neura-api
```
