void main() {
  print('🧠 Neura Companion Initialized');
}