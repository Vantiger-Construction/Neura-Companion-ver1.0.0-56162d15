@echo off
REM Neura Companion Multi-Platform Installer

echo [🧠] Welcome to the Neura Companion installer...
echo.

REM Set up Firebase config for Android
IF EXIST flutter_app\android\app (
  echo [✅] Copying google-services.json to Android directory...
  copy google-services.json flutter_app\android\app\google-services.json >nul
)

REM Build Android APK
echo [🚧] Building Android APK...
cd flutter_app
flutter pub get
flutter build apk --release

REM Build Windows EXE
echo [🚧] Building Windows version...
flutter build windows

REM Build Web App
echo [🚧] Building Web version...
flutter build web

cd ..
echo [✅] All builds complete.
echo.

echo [📦] Outputs:
echo  - APK: flutter_app\build\app\outputs\flutter-apk\app-release.apk
echo  - Windows: flutter_app\build\windows\runner\Release\
echo  - Web: flutter_app\build\web\index.html

pause
