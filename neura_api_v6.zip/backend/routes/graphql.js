const { ApolloServer, gql, PubSub } = require('apollo-server-express');
const pubsub = new PubSub();
// Import Mongoose models
const Memory = require('../models/Memory');
const User = require('../models/User');
// ...other models as needed

const typeDefs = gql`
  scalar JSON

  type User { id: ID!, email: String!, role: String! }
  type Memory { id: ID!, userId: ID!, data: JSON! }
  type Query {
    me: User
    memories(userId: ID!): [Memory]
  }
  type Mutation {
    addMemory(userId: ID!, data: JSON!): Memory
  }
  type Subscription {
    memoryAdded(userId: ID!): Memory
  }
`;

const resolvers = {
  JSON: require('graphql-type-json'),
  Query: {
    me: (_, __, { user }) => user,
    memories: (_, { userId }) => Memory.find({ userId }),
  },
  Mutation: {
    addMemory: async (_, { userId, data }) => {
      const mem = new Memory({ userId, data });
      await mem.save();
      pubsub.publish(\`MEMORY_ADDED_\${userId}\`, { memoryAdded: mem });
      return mem;
    },
  },
  Subscription: {
    memoryAdded: {
      subscribe: (_, { userId }) => pubsub.asyncIterator([\`MEMORY_ADDED_\${userId}\`]),
    },
  },
};

module.exports = { typeDefs, resolvers };
