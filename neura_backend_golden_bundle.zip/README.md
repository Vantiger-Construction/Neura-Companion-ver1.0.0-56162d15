# Neura Companion Backend Golden Bundle

- `pip install -r requirements.txt`
- Edit `.env` for your keys (OpenAI, Slack, Zapier, etc)
- `uvicorn app.main:app --reload`

All API endpoints, models, and modules are included and ready for prod.
