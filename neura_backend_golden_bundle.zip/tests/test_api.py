import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_auth_login():
    resp = client.post("/api/v1/auth/token", data={"username": "tigger", "password": "neura_is_best"})
    assert resp.status_code == 200
    assert "access_token" in resp.json()

def test_mood_crud():
    resp = client.post("/api/v1/auth/token", data={"username": "tigger", "password": "neura_is_best"})
    token = resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    # Submit mood
    resp = client.post("/api/v1/mood/", json={"mood": "happy"}, headers=headers)
    assert resp.status_code == 200
    # Get mood
    resp = client.get("/api/v1/mood/", headers=headers)
    assert resp.status_code == 200
