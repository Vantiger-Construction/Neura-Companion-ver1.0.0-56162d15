from fastapi import APIRouter, HTTPException, Depends, Path, WebSocket, WebSocketDisconnect
from sqlmodel import select, Session
from typing import List, Optional
from app.auth import get_current_user, User
from app.models import MoodEntry
from app.db import get_session
import datetime
from collections import defaultdict
import asyncio

router = APIRouter()
active_connections = defaultdict(list)

@router.post("/", response_model=MoodEntry)
def submit_mood(
    mood: dict,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session)
):
    entry = MoodEntry(
        username=user.username,
        mood=mood["mood"],
        note=mood.get("note"),
    )
    session.add(entry)
    session.commit()
    session.refresh(entry)
    asyncio.create_task(notify_user(user.username, {"type": "new", "mood": entry.dict()}))
    return entry

@router.get("/", response_model=List[MoodEntry])
def get_mood_history(
    limit: int = 20,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session)
):
    statement = select(MoodEntry).where(MoodEntry.username == user.username).order_by(MoodEntry.timestamp.desc()).limit(limit)
    return session.exec(statement).all()

@router.websocket("/ws")
async def mood_ws(websocket: WebSocket):
    token = websocket.query_params.get("token") or websocket.headers.get("Authorization", "").replace("Bearer ", "")
    session = next(get_session())
    try:
        user = get_current_user(token, session)
    except Exception:
        await websocket.close(code=4001)
        return
    username = user.username
    await websocket.accept()
    active_connections[username].append(websocket)
    try:
        statement = select(MoodEntry).where(MoodEntry.username == username).order_by(MoodEntry.timestamp.desc()).limit(20)
        moods = session.exec(statement).all()
        await websocket.send_json({"type": "history", "moods": [m.dict() for m in moods]})
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        if websocket in active_connections[username]:
            active_connections[username].remove(websocket)
async def notify_user(username, data):
    for ws in list(active_connections.get(username, [])):
        try:
            await ws.send_json(data)
        except Exception:
            pass
