from fastapi import APIRouter, Depends, Response
from app.auth import require_admin, User
from app.models import MoodEntry
from app.db import get_session
from sqlmodel import select, Session
import csv
import io

router = APIRouter()

@router.get("/moods/csv", summary="Export moods as CSV")
def export_moods_csv(user: User = Depends(require_admin), session: Session = Depends(get_session)):
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id", "username", "mood", "note", "timestamp"])
    for mood in session.exec(select(MoodEntry)):
        writer.writerow([mood.id, mood.username, mood.mood, mood.note, mood.timestamp])
    output.seek(0)
    return Response(output.read(), media_type="text/csv")
