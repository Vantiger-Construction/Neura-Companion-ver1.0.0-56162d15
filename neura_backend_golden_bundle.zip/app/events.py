from fastapi import APIRouter, Depends
from sqlmodel import select, Session
from app.auth import require_admin, get_current_user, User
from app.models import EventLog, Webhook
from app.db import get_session
import httpx, datetime, os

router = APIRouter()

@router.get("/", summary="Get event logs")
def get_events(admin=Depends(require_admin), session: Session = Depends(get_session)):
    statement = select(EventLog).order_by(EventLog.timestamp.desc()).limit(100)
    return session.exec(statement).all()

@router.post("/webhook/register")
def register_webhook(url: str, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    webhook = Webhook(url=url, owner=user.username)
    session.add(webhook)
    session.commit()
    session.refresh(webhook)
    return webhook

@router.get("/webhook/list")
def list_webhooks(user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    statement = select(Webhook).where(Webhook.owner == user.username)
    return session.exec(statement).all()

async def trigger_webhooks(event_type: str, payload: dict, user: str, session: Session):
    statement = select(Webhook).where(Webhook.active == True)
    for hook in session.exec(statement):
        try:
            async with httpx.AsyncClient() as client:
                await client.post(hook.url, json={"event_type": event_type, "payload": payload, "user": user})
        except Exception:
            pass

def log_event(username: str, event_type: str, payload: dict, session: Session):
    evt = EventLog(username=username, event_type=event_type, payload=str(payload))
    session.add(evt)
    session.commit()
