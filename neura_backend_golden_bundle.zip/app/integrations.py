from fastapi import APIRouter, Depends
from app.auth import require_admin, get_current_user, User
import httpx, os

router = APIRouter()
SLACK_WEBHOOK_URL = os.getenv("SLACK_WEBHOOK_URL")
ZAPIER_WEBHOOK_URL = os.getenv("ZAPIER_WEBHOOK_URL")

@router.post("/slack/send")
async def send_slack_message(text: str, user: User = Depends(require_admin)):
    if not SLACK_WEBHOOK_URL:
        return {"error": "Slack webhook URL not set."}
    payload = {"text": text}
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.post(SLACK_WEBHOOK_URL, json=payload)
        return {"ok": resp.status_code == 200}

@router.post("/zapier/trigger")
async def zapier_trigger(event_type: str, payload: dict, user: User = Depends(require_admin)):
    if not ZAPIER_WEBHOOK_URL:
        return {"error": "Zapier webhook URL not set."}
    data = {"event_type": event_type, "payload": payload}
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.post(ZAPIER_WEBHOOK_URL, json=data)
        return {"ok": resp.status_code == 200}

@router.post("/sms/send")
async def send_sms(phone: str, message: str, user: User = Depends(require_admin)):
    # For demo; swap with Twilio real send
    print(f"Would send SMS to {phone}: {message}")
    return {"ok": True}
