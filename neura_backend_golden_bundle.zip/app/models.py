from sqlmodel import SQLModel, Field
from typing import Optional
import datetime

class UserAccount(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True)
    username: str
    password: str
    role: str = "user"
    org: str = "default"

class MoodEntry(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True)
    username: str
    mood: str
    note: Optional[str] = None
    timestamp: datetime.datetime = Field(default_factory=datetime.datetime.utcnow)

class EventLog(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True)
    username: str
    event_type: str
    payload: str
    timestamp: datetime.datetime = Field(default_factory=datetime.datetime.utcnow)

class Webhook(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True)
    url: str
    owner: str
    active: bool = True
