from fastapi import APIRouter, Depends
from app.auth import get_current_user, User
import os
import httpx

router = APIRouter()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

@router.post("/")
async def ai_copilot(query: str, user: User = Depends(get_current_user)):
    if not OPENAI_API_KEY:
        return {"response": "OpenAI API key not set."}
    prompt = f"You are Neura Copilot, a helpful developer and API assistant. User asked: {query}"
    payload = {
        "model": "gpt-4o",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.2
    }
    headers = {"Authorization": f"Bearer {OPENAI_API_KEY}"}
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post("https://api.openai.com/v1/chat/completions", json=payload, headers=headers)
        if resp.status_code == 200:
            return {"response": resp.json()["choices"][0]["message"]["content"]}
        return {"error": resp.text}
