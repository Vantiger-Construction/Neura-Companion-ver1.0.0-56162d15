from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app import auth, mood, admin, events, copilot, export, integrations
from app.db import init_db
from slowapi import Limiter
from slowapi.util import get_remote_address

app = FastAPI(
    title="Neura Companion API",
    description="Neura's full platform API. AI, analytics, teams, integrations.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    init_db()

# Routers
app.include_router(auth.router, prefix="/api/v1/auth", tags=["auth"])
app.include_router(mood.router, prefix="/api/v1/mood", tags=["mood"])
app.include_router(events.router, prefix="/api/v1/events", tags=["events"])
app.include_router(admin.router, prefix="/api/v1/admin", tags=["admin"])
app.include_router(copilot.router, prefix="/api/v1/copilot", tags=["ai"])
app.include_router(export.router, prefix="/api/v1/export", tags=["export"])
app.include_router(integrations.router, prefix="/api/v1/integrations", tags=["integrations"])
