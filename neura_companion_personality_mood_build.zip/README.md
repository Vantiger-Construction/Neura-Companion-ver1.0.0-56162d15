
# Neura Companion AI - Personality & Mood Engine

Includes:
- 🧠 Mood tracking from voice input
- 🎭 Persistent evolving personality traits
- 🎤 Speech-to-text + animation + emotional mapping
- 🫦 Mouth sync with speech + expressive Lottie animations

## Run Instructions:
flutter pub get
flutter run

## Bonus:
Try interacting more to evolve Neura’s behavior!
