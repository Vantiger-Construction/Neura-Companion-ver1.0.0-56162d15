
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NeuraPersona with ChangeNotifier {
  String _currentMood = "neutral";
  Map<String, double> _traits = {
    "friendly": 0.8,
    "cheeky": 0.2,
    "empathetic": 0.6,
    "curious": 0.5,
    "playful": 0.4,
    "protective": 0.3,
  };

  String get currentMood => _currentMood;
  Map<String, double> get traits => Map.unmodifiable(_traits);

  void updateMood(String mood) {
    _currentMood = mood;
    _savePersona();
    notifyListeners();
  }

  void evolveTrait(String trait, double delta) {
    if (_traits.containsKey(trait)) {
      _traits[trait] = (_traits[trait]! + delta).clamp(0.0, 1.0);
      _savePersona();
      notifyListeners();
    }
  }

  Future<void> _savePersona() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString("neura_mood", _currentMood);
    _traits.forEach((key, value) {
      prefs.setDouble("trait_$key", value);
    });
  }

  Future<void> loadPersona() async {
    final prefs = await SharedPreferences.getInstance();
    _currentMood = prefs.getString("neura_mood") ?? "neutral";
    _traits = {
      for (var k in _traits.keys)
        k: prefs.getDouble("trait_$k") ?? _traits[k]!,
    };
    notifyListeners();
  }
}
