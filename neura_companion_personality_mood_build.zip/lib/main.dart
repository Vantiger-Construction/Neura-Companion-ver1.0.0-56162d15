
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'neura_voice_reactive_widget.dart';
import 'neura_emotion_state.dart';
import 'neura_persona.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final persona = NeuraPersona();
  await persona.loadPersona();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => NeuraEmotionState()),
        ChangeNotifierProvider(create: (_) => persona),
      ],
      child: const NeuraApp(),
    ),
  );
}

class NeuraApp extends StatelessWidget {
  const NeuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion AI',
      theme: ThemeData.dark(),
      home: const NeuraHome(),
    );
  }
}

class NeuraHome extends StatelessWidget {
  const NeuraHome({super.key});

  @override
  Widget build(BuildContext context) {
    final mood = context.watch<NeuraPersona>().currentMood;
    return Scaffold(
      appBar: AppBar(title: Text('Mood: $mood')),
      body: const SafeArea(
        child: Center(
          child: NeuraVoiceReactiveWidget(),
        ),
      ),
    );
  }
}
