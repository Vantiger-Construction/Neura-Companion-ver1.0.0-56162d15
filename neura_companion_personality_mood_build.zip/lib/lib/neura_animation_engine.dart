
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'neura_emotion_state.dart';

const Map<String, String> emotionToAnimation = {
  'happy': 'assets/peace_sign_cheer.json',
  'calm': 'assets/idle_breathing_glow.json',
  'sad': 'assets/sad_reflective_look.json',
  'anxious': 'assets/hug_open_arms.json',
  'surprised': 'assets/surprised_blink.json',
  'confident': 'assets/confident_gaze.json',
  'playful': 'assets/cheeky_wink.json',
  'tired': 'assets/yawn_sleepy.json',
  'frustrated': 'assets/annoyed_puff.json',
  'curious': 'assets/smirk_sideways.json',
  'neutral': 'assets/idle_breathing_glow.json',
};

class NeuraAnimationEngine extends StatefulWidget {
  final String emotion;
  const NeuraAnimationEngine({Key? key, required this.emotion}) : super(key: key);

  @override
  State<NeuraAnimationEngine> createState() => _NeuraAnimationEngineState();
}

class _NeuraAnimationEngineState extends State<NeuraAnimationEngine> {
  late String animationPath;

  @override
  void initState() {
    super.initState();
    animationPath = emotionToAnimation[widget.emotion] ?? emotionToAnimation['neutral']!;
  }

  @override
  void didUpdateWidget(covariant NeuraAnimationEngine oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.emotion != widget.emotion) {
      setState(() {
        animationPath = emotionToAnimation[widget.emotion] ?? emotionToAnimation['neutral']!;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Lottie.asset(animationPath);
  }
}
