
import 'package:shared_preferences/shared_preferences.dart';

class MoodMemory {
  static const String _key = 'mood_history';

  static Future<void> logMood(String mood) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> history = prefs.getStringList(_key) ?? [];
    history.insert(0, mood);
    if (history.length > 5) history = history.sublist(0, 5);
    await prefs.setStringList(_key, history);
  }

  static Future<List<String>> getMoodHistory() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_key) ?? [];
  }
}
