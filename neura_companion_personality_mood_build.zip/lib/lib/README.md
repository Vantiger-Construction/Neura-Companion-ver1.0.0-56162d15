
# Neura Companion - Full Voice + Emotion + Mouth Sync Integration

Includes:
- NeuraVoiceReactiveWidget: voice → emotion → animation → synced mouth
- Real-time animated mouth with viseme logic
- Drop-in compatible with full Neura Companion layout

Add this widget into any room or dashboard view using:
```
ChangeNotifierProvider(
  create: (_) => NeuraEmotionState(),
  child: NeuraVoiceReactiveWidget(),
)
```

Dependencies:
- flutter_tts
- speech_to_text
- shared_preferences
- provider
- lottie

Assets required:
- viseme_0_rest.png
- viseme_1_a_e.png
- viseme_2_o_u.png
- viseme_3_m.png
- viseme_4_l.png
