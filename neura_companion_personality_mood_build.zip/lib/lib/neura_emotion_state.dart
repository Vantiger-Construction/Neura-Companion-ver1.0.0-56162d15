
import 'package:flutter/foundation.dart';

class NeuraEmotionState extends ChangeNotifier {
  String _emotion = 'neutral';

  String get emotion => _emotion;

  void update(String newEmotion) {
    _emotion = newEmotion;
    notifyListeners();
  }
}
