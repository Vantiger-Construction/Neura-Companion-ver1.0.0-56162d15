
String mapTextToEmotion(String input) {
  input = input.toLowerCase();
  if (input.contains('happy') || input.contains('yay')) return 'happy';
  if (input.contains('sad') || input.contains('cry')) return 'sad';
  if (input.contains('tired') || input.contains('sleep')) return 'tired';
  if (input.contains('angry') || input.contains('ugh')) return 'frustrated';
  if (input.contains('nervous') || input.contains('worried')) return 'anxious';
  if (input.contains('surprise') || input.contains('wow')) return 'surprised';
  if (input.contains('ok') || input.contains('fine')) return 'calm';
  if (input.contains('cool') || input.contains('awesome')) return 'confident';
  if (input.contains('fun') || input.contains('joke')) return 'playful';
  if (input.contains('hmm') || input.contains('why')) return 'curious';
  return 'neutral';
}
