
import 'package:flutter/material.dart';

class MouthVisemeController extends StatefulWidget {
  final bool speaking;

  const MouthVisemeController({super.key, required this.speaking});

  @override
  State<MouthVisemeController> createState() => _MouthVisemeControllerState();
}

class _MouthVisemeControllerState extends State<MouthVisemeController> {
  int _currentFrame = 0;
  late final List<String> _frames;
  late final List<Duration> _timing;
  late final Ticker _ticker;

  @override
  void initState() {
    super.initState();
    _frames = [
      'assets/viseme_0_rest.png',
      'assets/viseme_1_a_e.png',
      'assets/viseme_2_o_u.png',
      'assets/viseme_3_m.png',
      'assets/viseme_4_l.png',
    ];
    _timing = [
      const Duration(milliseconds: 120),
      const Duration(milliseconds: 100),
      const Duration(milliseconds: 90),
      const Duration(milliseconds: 110),
      const Duration(milliseconds: 95),
    ];
    _startTicker();
  }

  void _startTicker() {
    _ticker = Ticker((elapsed) {
      if (widget.speaking) {
        setState(() {
          _currentFrame = (_currentFrame + 1) % _frames.length;
        });
      } else {
        setState(() {
          _currentFrame = 0;
        });
      }
    });
    _ticker.start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Image.asset(_frames[_currentFrame], width: 72, height: 72);
  }
}

class Ticker {
  final void Function(Duration) callback;
  late final Stopwatch _stopwatch;
  bool _active = false;

  Ticker(this.callback) {
    _stopwatch = Stopwatch();
  }

  void start() {
    _active = true;
    _stopwatch.start();
    _tick();
  }

  void _tick() async {
    while (_active) {
      await Future.delayed(const Duration(milliseconds: 100));
      callback(_stopwatch.elapsed);
    }
  }

  void dispose() {
    _active = false;
    _stopwatch.stop();
  }
}
