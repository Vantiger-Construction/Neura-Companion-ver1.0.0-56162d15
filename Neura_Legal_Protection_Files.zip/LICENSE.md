Copyright © 2025 Neura Companion. All rights reserved.

This software and all related assets (code, designs, AI modules, graphics, voice data, branding, etc.)
are the intellectual property of the Neura Companion project and its creator.

Unauthorized reproduction, modification, distribution, or commercial use is strictly prohibited.
All uses of this software and its associated materials must receive explicit written consent.

Neura Companion is a proprietary product protected by copyright, trademark, and applicable intellectual property laws.