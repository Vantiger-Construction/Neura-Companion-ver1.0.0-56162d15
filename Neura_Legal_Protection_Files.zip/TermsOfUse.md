# Terms of Use – Neura Companion

By using the Neura Companion application or site, you agree to the following:

- You will not attempt to reverse engineer, duplicate, or resell the software or any components.
- You understand that Neura Companion is a work in progress and features may evolve or change.
- All content within the app is the property of the Neura Companion project and protected by law.

Violation of these terms may result in loss of access and legal action.