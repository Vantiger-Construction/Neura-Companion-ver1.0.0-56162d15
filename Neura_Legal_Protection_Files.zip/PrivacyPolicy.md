# Privacy Policy – Neura Companion

Effective Date: July 31, 2025

Neura Companion respects your privacy. We do not sell or share your personal data.
All personal data (mood, journaling, preferences) is stored securely and used solely to enhance your experience.
By using Neura Companion, you agree to this privacy policy.

For any data-related requests, please email neuracompanion@gmail.com.