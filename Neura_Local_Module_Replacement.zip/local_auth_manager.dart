// Handles offline authentication locally

class LocalAuthManager {
  static final _fakeUserDB = {'user@example.com': 'secure123'};

  static bool login(String email, String password) {
    return _fakeUserDB[email] == password;
  }

  static void logout() {
    // Clear local user session
  }

  static String? getCurrentUser() {
    return 'user@example.com';
  }
}