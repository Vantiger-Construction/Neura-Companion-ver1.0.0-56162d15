// Replaces Firebase Analytics with local event tracking

import 'dart:io';
import 'package:path_provider/path_provider.dart';

class UsageInsightsTracker {
  static Future<void> logEvent(String name, Map<String, dynamic> properties) async {
    final dir = await getApplicationDocumentsDirectory();
    final logFile = File('${dir.path}/usage_events.log');
    final entry = 'EVENT: $name -> ${properties.toString()}\n';
    await logFile.writeAsString(entry, mode: FileMode.append);
  }
}