// Replaces Firebase Storage for storing user assets

import 'dart:io';
import 'package:path_provider/path_provider.dart';

class LocalFileStorage {
  static Future<String> saveFile(String filename, List<int> bytes) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/$filename');
    await file.writeAsBytes(bytes);
    return file.path;
  }

  static Future<File?> loadFile(String filename) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/$filename');
    return file.existsSync() ? file : null;
  }
}