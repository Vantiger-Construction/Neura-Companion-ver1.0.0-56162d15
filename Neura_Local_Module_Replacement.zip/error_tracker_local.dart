// Tracks and stores errors locally instead of Firebase Crashlytics

import 'dart:io';
import 'package:path_provider/path_provider.dart';

class ErrorTracker {
  static Future<void> logError(String message, [String? stackTrace]) async {
    final dir = await getApplicationDocumentsDirectory();
    final logFile = File('${dir.path}/error_log.txt');
    final timestamp = DateTime.now().toIso8601String();
    final entry = '[$timestamp] $message\n$stackTrace\n';
    await logFile.writeAsString(entry, mode: FileMode.append);
  }
}