// Manages local database for storing mood logs, journals, etc.

import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class LocalDataStore {
  static Future<String> _getFilePath(String filename) async {
    final dir = await getApplicationDocumentsDirectory();
    return '${dir.path}/$filename.json';
  }

  static Future<void> save(String key, dynamic data) async {
    final path = await _getFilePath(key);
    final file = File(path);
    await file.writeAsString(jsonEncode(data));
  }

  static Future<Map<String, dynamic>> load(String key) async {
    final path = await _getFilePath(key);
    final file = File(path);
    if (await file.exists()) {
      return jsonDecode(await file.readAsString());
    } else {
      return {};
    }
  }
}