
module.exports = function(schema) {
  schema.add({ tenantId: String });
  function applyTenant(next) {
    if (this.options && this.options.tenantId) {
      this.where({ tenantId: this.options.tenantId });
    }
    next();
  }
  schema.pre('find', applyTenant);
  schema.pre('findOne', applyTenant);
  schema.pre('save', function(next) {
    if (this.isNew && this.$__.options && this.$__.options.tenantId) {
      this.tenantId = this.$__.options.tenantId;
    }
    next();
  });
};
