const { SchemaDirectiveVisitor } = require('apollo-server-express');
const { defaultFieldResolver } = require('graphql');
class RoleDirective extends SchemaDirectiveVisitor {
  visitFieldDefinition(field) {
    const { resolve = defaultFieldResolver } = field;
    const { roles } = this.args;
    field.resolve = async function(root, args, context, info) {
      const userRole = context.user && context.user.role;
      if (!roles.includes(userRole)) {
        throw new Error('Forbidden: missing required role');
      }
      return resolve.call(this, root, args, context, info);
    };
  }
}
module.exports = RoleDirective;
