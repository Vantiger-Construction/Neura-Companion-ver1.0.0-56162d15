
const { SchemaDirectiveVisitor } = require('apollo-server-express');
const { defaultFieldResolver } = require('graphql');
class CacheControlDirective extends SchemaDirectiveVisitor {
  visitFieldDefinition(field) {
    const { resolve = defaultFieldResolver } = field;
    const { maxAge, scope } = this.args;
    field.resolve = async function(...args) {
      const [, , context] = args;
      if (context.cacheControl) {
        context.cacheControl.setCacheHint({ maxAge, scope });
      }
      return resolve.apply(this, args);
    };
  }
}
module.exports = CacheControlDirective;
