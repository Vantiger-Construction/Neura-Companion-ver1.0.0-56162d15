const { SchemaDirectiveVisitor } = require('apollo-server-express');
const { defaultFieldResolver } = require('graphql');
class AbacDirective extends SchemaDirectiveVisitor {
  visitFieldDefinition(field) {
    const { resolve = defaultFieldResolver } = field;
    const { action, resource } = this.args;
    field.resolve = async function(source, args, context, info) {
      const { user } = context;
      if (!user ||
          !user.permissions ||
          !user.permissions.some(p => p.resource === resource && p.actions.includes(action))
      ) {
        throw new Error('ABAC: Access denied');
      }
      return resolve.apply(this, [source, args, context, info]);
    };
  }
}
module.exports = AbacDirective;
