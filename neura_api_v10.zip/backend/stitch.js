const { stitchSchemas } = require('@graphql-tools/stitch');
const { introspectSchema, makeRemoteExecutableSchema, delegateToSchema } = require('@graphql-tools/wrap');
const fetch = require('node-fetch');
const { HttpLink } = require('apollo-link-http');

async function createStitchedSchema() {
  // Remote service URLs via env
  const usersLink = new HttpLink({ uri: process.env.USERS_URL, fetch });
  const ordersLink = new HttpLink({ uri: process.env.ORDERS_URL, fetch });

  const usersSchema = makeRemoteExecutableSchema({
    schema: await introspectSchema(usersLink),
    link: usersLink,
  });
  const ordersSchema = makeRemoteExecutableSchema({
    schema: await introspectSchema(ordersLink),
    link: ordersLink,
  });

  return stitchSchemas({
    subschemas: [usersSchema, ordersSchema],
    typeDefs: /* GraphQL */ `
      extend type User {
        orders: [Order]
      }
    `,
    resolvers: {
      User: {
        orders: {
          selectionSet: `{ id }`,
          resolve(user, args, context, info) {
            return delegateToSchema({
              schema: ordersSchema,
              operation: 'query',
              fieldName: 'ordersByUser',
              args: { userId: user.id },
              context, info
            });
          }
        }
      }
    }
  });
}

module.exports = { createStitchedSchema };
