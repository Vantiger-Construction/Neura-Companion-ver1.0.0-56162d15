const DataLoader = require('dataloader');
const Memory = require('../models/Memory');
module.exports = () => new DataLoader(async userIds => {
  const memories = await Memory.find({ userId: { $in: userIds } });
  return userIds.map(id => memories.filter(m => m.userId.toString() === id.toString()));
});
