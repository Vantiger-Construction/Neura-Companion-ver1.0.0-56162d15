require('./telemetry');

const { buildFederatedSchema } = require('@apollo/federation');
const { ApolloServerPluginCacheControl } = require('apollo-server-plugin-cache-control');
const tenantPlugin = require('./plugins/tenant');
const CacheControlDirective = require('./directives/cacheControlDirective');

require('dotenv').config();
const express = require('express');
const http = require('http');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const { typeDefs, resolvers } = require('./routes/graphql');
const RoleDirective = require('./directives/roleDirective');
const socketEvents = require('./routes/socket_events');
const { ApolloServer } = require('apollo-server-express');
const { Server } = require('socket.io');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');

const auth = require('./routes/auth');
const jokes = require('./routes/jokes');
const dreams = require('./routes/dreams');
const settings = require('./routes/settings');
const memory = require('./routes/memory');


const app = express();
const httpServer = http.createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });
io.on('connection', socket => console.log('Socket connected:', socket.id));
app.use('/api/socket', socketEvents(io));

// Apollo GraphQL setup
async function startApollo() {
  const server = new ApolloServer({
    schema: buildFederatedSchema([{ typeDefs, resolvers }]),
    plugins: [ApolloServerPluginCacheControl({ defaultMaxAge: 60 })],
    schemaDirectives: { auth: AuthDirective, hasRole: RoleDirective, cacheControl: CacheControlDirective },
    context: ({ req, connection }) => {
      const user = req ? req.user : connection.context.user;
      const tenantId = req ? req.tenantId : connection.context.tenantId;
      return { user, tenantId, memoryLoader: require('./loaders/memoryLoader')(), cacheControl: req.cacheControl };
    },
  });

  const server = new ApolloServer({ typeDefs, resolvers, context: ({req}) => ({ user: req.user }) });
  await server.start();
  server.applyMiddleware({
      app,
      path: '/api/graphql',
      playground: process.env.NODE_ENV !== 'production',
    });
}
startApollo();
