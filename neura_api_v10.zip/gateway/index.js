require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { ApolloServer } = require('apollo-server-express');
const { ApolloGateway } = require('@apollo/gateway');

const gateway = new ApolloGateway({
  serviceList: [
    { name: 'users', url: process.env.USERS_URL },
    { name: 'orders', url: process.env.ORDERS_URL },
    { name: 'neura', url: process.env.NEURA_URL }
  ]
});

(async () => {
  const server = new ApolloServer({
    gateway,
    subscriptions: false,
    context: ({ req }) => ({ headers: req.headers })
  });
  await server.start();
  const app = express();
  app.use(cors());
  server.applyMiddleware({ app, path: '/graphql' });
  const port = process.env.GATEWAY_PORT || 4000;
  app.listen(port, () => console.log(`Gateway ready at http://localhost:${port}/graphql`));
})();
