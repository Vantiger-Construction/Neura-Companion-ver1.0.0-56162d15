#!/usr/bin/env bash
set -e
echo "Installing Neura API v10 with Federation Gateway, ABAC, and Stitching..."
cd backend && npm install
cd ../gateway && npm install
