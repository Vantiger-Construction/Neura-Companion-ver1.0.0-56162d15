#!/usr/bin/env bash
set -e
echo "Installing Neura API v8 with directives, DataLoader, and OpenTelemetry..."
cd backend && npm install
