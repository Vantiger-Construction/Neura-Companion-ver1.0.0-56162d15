#!/usr/bin/env bash
set -e
echo "Installing Neura API v9 with Federation, Multi-Tenancy, and Cache-Control..."
cd backend && npm install
