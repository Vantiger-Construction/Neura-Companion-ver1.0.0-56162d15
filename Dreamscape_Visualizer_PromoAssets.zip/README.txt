DREAMSCAPE VISUALIZER PREVIEW ASSETS

- Dreamscape_Preview.png
  Promotional visual showing AI image generation, dream journaling, and playback features.
  Use this for trailers, app store images, or marketing material.

- Coming soon: animated Lottie/video trailer and interactive website demo
