@echo off
mkdir C:\NeuraCompanion
xcopy /Y /E Neura_Companion_All_In_One_Source_Build.zip C:\NeuraCompanion
cd C:\NeuraCompanion
@echo Neura Companion Installed Successfully!