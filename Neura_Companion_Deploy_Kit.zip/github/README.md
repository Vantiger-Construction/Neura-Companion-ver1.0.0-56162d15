# Neura Companion

This repository contains the full source code and assets for the Neura Companion AI assistant.