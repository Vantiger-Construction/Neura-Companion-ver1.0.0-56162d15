# Neura Lottie Animation

This bundle contains the Lottie JSON and preview for Neura's wave animation.

Includes:
- wave_smile_hello.json
- idle_breathing_glow.json
- peace_sign_cheer.json
- celebrate_raise_arms.json
- listening_mode_ear_glow.json
- sad_reflective_look.json
- hug_open_arms.json
- sleep_curl_mode.json