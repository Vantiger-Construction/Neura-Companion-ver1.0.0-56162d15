library clinical_module;

import 'dart:convert';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:http/http.dart';
import 'package:fhir/r4.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Clinical features for medical professionals.
class ClinicalModule {
  final InAppPurchasePlatform iap;
  final Client httpClient;
  final FlutterSecureStorage storage;
  final String fhirServerUrl;
  final String apiKey;
  final String subscriptionId;

  ProductDetails? _product;
  bool _subscribed = false;

  ClinicalModule({
    required this.iap,
    required this.httpClient,
    required this.storage,
    required this.fhirServerUrl,
    required this.apiKey,
    this.subscriptionId = 'clinical_module_pro',
  });

  /// Initialize, verify or prompt subscription.
  Future<void> init() async {
    if (!await iap.isAvailable()) {
      throw Exception('IAP unavailable');
    }
    // load product
    final response = await iap.queryProductDetails({subscriptionId});
    if (response.productDetails.isEmpty) throw Exception('Product not found');
    _product = response.productDetails.first;
    // check past purchases
    final past = await iap.queryPastPurchases();
    for (var p in past.pastPurchases) {
      if (p.productID == subscriptionId && p.status == PurchaseStatus.purchased) {
        _subscribed = true;
      }
    }
    if (!_subscribed) throw Exception('Subscription required');
  }

  /// Trigger purchase flow
  Future<void> purchase() async {
    if (_product == null) throw Exception('Product not loaded');
    final param = PurchaseParam(productDetails: _product!);
    await iap.buyNonConsumable(purchaseParam: param);
  }

  /// Fetch Patient via FHIR
  Future<Patient> fetchPatient(String patientId) async {
    _ensureSub();
    final res = await httpClient.get(
      Uri.parse('\$fhirServerUrl/Patient/\$patientId'),
      headers: {
        'Authorization': 'Bearer \$apiKey',
        'Accept': 'application/fhir+json'
      },
    );
    if (res.statusCode == 200) {
      return Patient.fromJson(jsonDecode(res.body));
    }
    throw Exception('Fetch failed: \${res.statusCode}');
  }

  /// Send Observation
  Future<void> sendObservation(Observation obs) async {
    _ensureSub();
    final res = await httpClient.post(
      Uri.parse('\$fhirServerUrl/Observation'),
      headers: {
        'Authorization': 'Bearer \$apiKey',
        'Content-Type': 'application/fhir+json'
      },
      body: jsonEncode(obs.toJson()),
    );
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Send failed: \${res.statusCode}');
    }
  }

  void _ensureSub() {
    if (!_subscribed) throw Exception('Not subscribed');
  }
}
