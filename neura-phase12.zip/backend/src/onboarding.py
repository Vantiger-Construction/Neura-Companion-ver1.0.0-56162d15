"""Onboarding endpoints for new users"""
from fastapi import APIRouter, Depends
from typing import List
from src.schemas import SubscriptionCreate

router = APIRouter()

@router.post("/onboarding/default-subscriptions", response_model=List[SubscriptionCreate])
def default_subscriptions():
    # Suggested subscriptions for new users
    return [
        {"url": "https://example.com/webhooks/resource", "eventType": "resource.created"},
        {"url": "https://example.com/webhooks/daily-summary", "eventType": "daily.summary"},
    ]
