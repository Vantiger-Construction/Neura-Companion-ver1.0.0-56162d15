# Onboarding Flow

`POST /v1/onboarding/default-subscriptions`

Returns default recommended webhook subscriptions for new users.
