describe('Onboarding Flow', () => {
  it('Displays default subscriptions and allows subscribe', () => {
    cy.visit('/onboarding');
    cy.contains('Welcome to Neura');
    cy.get('button').contains('Subscribe').first().click();
    cy.on('window:alert', (txt) => {
      expect(txt).to.contains('Subscribed to');
    });
  });
});
