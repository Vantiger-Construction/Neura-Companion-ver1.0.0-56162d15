import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import BackgroundWrapper from './components/BackgroundWrapper';
import NeuraDashboardWrapper from './components/NeuraDashboardWrapper';
import MoodTracker from './components/MoodTracker';
import Journal from './components/Journal';
import Exercise from './components/Exercise';
import RealTimeEvents from './components/RealTimeEvents';
import Onboarding from './components/Onboarding';

function App() {
  return (
    <BrowserRouter>
      <BackgroundWrapper>
        <nav className="p-4 bg-gray-800 text-white flex space-x-4">
          <Link to="/">Dashboard</Link>
          <Link to="/mood">Mood Tracker</Link>
          <Link to="/journal">Journal</Link>
          <Link to="/exercise">Exercise</Link>
          <Link to="/realtime">Real-Time</Link>
          <Link to="/onboarding">Onboarding</Link>
        </nav>
        <div className="p-4">
          <Routes>
            <Route path="/" element={<NeuraDashboardWrapper />} />
            <Route path="/mood" element={<MoodTracker />} />
            <Route path="/journal" element={<Journal />} />
            <Route path="/exercise" element={<Exercise />} />
            <Route path="/realtime" element={<RealTimeEvents />} />
            <Route path="/onboarding" element={<Onboarding />} />
          </Routes>
        </div>
      </BackgroundWrapper>
    </BrowserRouter>
  );
}

export default App;
