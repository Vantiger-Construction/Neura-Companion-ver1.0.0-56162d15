import React, { useEffect, useState } from "react";
import axios from "axios";

export default function Onboarding() {
  const [defaults, setDefaults] = useState([]);
  const token = localStorage.getItem('neura_token') || '';

  useEffect(() => {
    axios.post('/v1/onboarding/default-subscriptions', {}, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(res => setDefaults(res.data));
  }, []);

  const subscribeDefault = (sub) => {
    axios.post('/v1/webhooks/subscribe', sub, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(() => alert(`Subscribed to ${sub.eventType}`));
  };

  return (
    <div className="bg-white bg-opacity-80 rounded p-4">
      <h2 className="text-2xl font-bold">Welcome to Neura!</h2>
      <p>We recommend starting with these subscriptions:</p>
      <ul>
        {defaults.map((d, i) => (
          <li key={i} className="border p-2 m-2 flex justify-between">
            <span>{d.eventType}</span>
            <button onClick={() => subscribeDefault(d)} className="bg-blue-500 text-white px-2 rounded">
              Subscribe
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
