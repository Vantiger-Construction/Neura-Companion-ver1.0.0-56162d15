
import 'package:flutter/material.dart';
import 'ritual_portal_controller.dart';

class RitualPortalScreen extends StatefulWidget {
  const RitualPortalScreen({super.key});

  @override
  State<RitualPortalScreen> createState() => _RitualPortalScreenState();
}

class _RitualPortalScreenState extends State<RitualPortalScreen> {
  final controller = RitualPortalController();

  @override
  Widget build(BuildContext context) {
    final scenes = controller.getAvailableScenes();

    return Scaffold(
      appBar: AppBar(title: const Text("🌀 Ritual Portal")),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text("Choose your portal to enter a new ritual realm:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500)),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: scenes.length,
              itemBuilder: (context, index) {
                final scene = scenes[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: Icon(scene['icon'], size: 36),
                    title: Text(scene['name']),
                    subtitle: Text(scene['description']),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => controller.enterScene(context, scene['name']),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
