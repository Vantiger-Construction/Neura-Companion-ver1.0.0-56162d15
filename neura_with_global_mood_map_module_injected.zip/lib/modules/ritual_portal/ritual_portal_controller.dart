
import 'package:flutter/material.dart';

class RitualPortalController {
  List<Map<String, dynamic>> getAvailableScenes() {
    return [
      {
        'name': 'Forest of Focus',
        'icon': Icons.park,
        'description': 'A calm green landscape for mindfulness and breathing.'
      },
      {
        'name': 'Temple of Light',
        'icon': Icons.temple_buddhist,
        'description': 'A spiritual zone for clarity and peace rituals.'
      },
      {
        'name': 'Dreamscape Realm',
        'icon': Icons.nightlight,
        'description': 'A surreal setting for imagination and sleep rituals.'
      },
    ];
  }

  void enterScene(BuildContext context, String sceneName) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => SceneViewScreen(sceneName: sceneName),
    ));
  }
}

class SceneViewScreen extends StatelessWidget {
  final String sceneName;
  const SceneViewScreen({super.key, required this.sceneName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("🌀 Entering $sceneName")),
      body: Center(
        child: Text("🔮 You are now in the $sceneName", style: const TextStyle(fontSize: 24)),
      ),
    );
  }
}
