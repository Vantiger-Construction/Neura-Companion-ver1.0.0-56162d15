
import 'package:flutter/material.dart';
import 'clinical_screen.dart';

Map<String, WidgetBuilder> clinicalRoutes = {
  '/clinical': (context) => const ClinicalScreen(),
};
