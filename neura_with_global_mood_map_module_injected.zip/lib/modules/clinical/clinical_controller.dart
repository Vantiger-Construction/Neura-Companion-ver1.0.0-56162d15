
import 'package:flutter/material.dart';

class ClinicalController {
  final heartRateController = TextEditingController();
  final temperatureController = TextEditingController();

  void uploadVitals(BuildContext context) {
    final heartRate = heartRateController.text;
    final temperature = temperatureController.text;

    // Simulate API call
    Future.delayed(const Duration(seconds: 1), () {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Vitals sent: HR $heartRate bpm, Temp $temperature°F"),
        ),
      );
    });
  }

  void dispose() {
    heartRateController.dispose();
    temperatureController.dispose();
  }
}
