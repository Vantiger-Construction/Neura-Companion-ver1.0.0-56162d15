
class RitualCuratorController {
  Map<String, String> generatePersonalizedRitual() {
    return {
      "goal": "Increase Focus",
      "duration": "10 minutes",
      "steps": "1. Sit comfortably\n2. Breathe deeply for 2 mins\n3. Visualize your main task\n4. Say affirmation: 'I am laser focused'\n5. Begin task with Neura's encouragement."
    };
  }
}
