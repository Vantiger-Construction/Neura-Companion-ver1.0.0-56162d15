
import 'package:flutter/material.dart';
import 'ritual_curator_controller.dart';

class RitualCuratorScreen extends StatelessWidget {
  const RitualCuratorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = RitualCuratorController();
    final ritual = controller.generatePersonalizedRitual();

    return Scaffold(
      appBar: AppBar(title: const Text("🧭 AI Ritual Curator")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text("💡 Today's Suggested Ritual",
              style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 20),
            Card(
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("🎯 Goal: ${ritual['goal']}", style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text("🕒 Duration: ${ritual['duration']}"),
                    const SizedBox(height: 10),
                    Text("✨ Instructions:"),
                    Text(ritual['steps']),
                  ],
                ),
              ),
            ),
            const Spacer(),
            ElevatedButton.icon(
              icon: const Icon(Icons.refresh),
              label: const Text("New Suggestion"),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => const RitualCuratorScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
