
import 'package:flutter/material.dart';
import 'companion_cast_controller.dart';

class CompanionCastScreen extends StatefulWidget {
  const CompanionCastScreen({super.key});

  @override
  State<CompanionCastScreen> createState() => _CompanionCastScreenState();
}

class _CompanionCastScreenState extends State<CompanionCastScreen> {
  final controller = CompanionCastController();

  @override
  Widget build(BuildContext context) {
    final characters = controller.getCast();

    return Scaffold(
      appBar: AppBar(title: const Text("🎭 Companion Cast Dialogues")),
      body: ListView.builder(
        itemCount: characters.length,
        itemBuilder: (context, index) {
          final cast = characters[index];
          return Card(
            child: ListTile(
              leading: CircleAvatar(backgroundImage: AssetImage(cast["avatar"])),
              title: Text(cast["name"]),
              subtitle: Text(cast["mood"]),
              onTap: () => controller.startDialogue(context, cast["name"]),
            ),
          );
        },
      ),
    );
  }
}
