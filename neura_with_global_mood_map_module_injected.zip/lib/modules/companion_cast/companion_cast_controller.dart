
import 'package:flutter/material.dart';

class CompanionCastController {
  List<Map<String, String>> getCast() {
    return [
      {
        "name": "Neura",
        "mood": "Empathetic & Playful",
        "avatar": "assets/avatars/neura.png"
      },
      {
        "name": "Neuro",
        "mood": "Logical & Encouraging",
        "avatar": "assets/avatars/neuro.png"
      },
      {
        "name": "Echo",
        "mood": "Creative & Chill",
        "avatar": "assets/avatars/echo.png"
      }
    ];
  }

  void startDialogue(BuildContext context, String name) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => DialogueScreen(characterName: name),
    ));
  }
}

class DialogueScreen extends StatelessWidget {
  final String characterName;

  const DialogueScreen({super.key, required this.characterName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("🗣️ Talking to $characterName")),
      body: Center(
        child: Text(
          "💬 $characterName says: Hello! Ready to talk?",
          style: const TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
