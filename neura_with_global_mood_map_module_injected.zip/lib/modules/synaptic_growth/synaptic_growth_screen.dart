
import 'package:flutter/material.dart';
import 'synaptic_growth_controller.dart';

class SynapticGrowthScreen extends StatelessWidget {
  const SynapticGrowthScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = SynapticGrowthController();
    final report = controller.getGrowthAnalysis();

    return Scaffold(
      appBar: AppBar(title: const Text("Synaptic Growth Mode")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("🌱 Growth Insights", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text("📊 Habit–Emotion Correlation:"),
            ...report['insights'].map<Widget>((insight) => ListTile(
              leading: const Icon(Icons.link),
              title: Text(insight),
            )),
            const Divider(),
            Text("🔥 Current Streak: ${report['streak']} days"),
            const SizedBox(height: 10),
            Text("🎁 Rewards Unlocked: ${report['rewards']}"),
          ],
        ),
      ),
    );
  }
}
