
class ReflectiveMirrorController {
  String generateNarration() {
    final moods = ["calm", "motivated", "anxious", "relieved"];
    final summary = [
      "Over the past few days, your mood has shifted from anxious to relieved.",
      "You found calm through quiet reflection and steady progress toward your goals.",
      "Your journaling shows growth and your emotions are stabilizing.",
      "Neura is proud of you. Keep nurturing this momentum."
    ];
    return summary.join(" ");
  }
}
