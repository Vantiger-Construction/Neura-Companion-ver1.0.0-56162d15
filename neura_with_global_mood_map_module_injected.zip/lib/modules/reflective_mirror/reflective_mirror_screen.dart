
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'reflective_mirror_controller.dart';

class ReflectiveMirrorScreen extends StatefulWidget {
  const ReflectiveMirrorScreen({super.key});

  @override
  State<ReflectiveMirrorScreen> createState() => _ReflectiveMirrorScreenState();
}

class _ReflectiveMirrorScreenState extends State<ReflectiveMirrorScreen> {
  final _controller = ReflectiveMirrorController();
  final _tts = FlutterTts();
  String? _narration;

  @override
  void initState() {
    super.initState();
    _narration = _controller.generateNarration();
    _tts.speak(_narration!);
  }

  @override
  void dispose() {
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Reflective Mirror Mode")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text("🪞 Your Emotional Reflection", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(
                  _narration ?? "",
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            ),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: () => _tts.speak(_narration!),
              icon: const Icon(Icons.volume_up),
              label: const Text("Replay Voice Summary"),
            ),
          ],
        ),
      ),
    );
  }
}
