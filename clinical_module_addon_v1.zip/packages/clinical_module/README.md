# Clinical Module

## Installation
Add to your root `pubspec.yaml`:
```yaml
clinical_module:
  path: ./packages/clinical_module
```

## Usage
```dart
import 'package:clinical_module/clinical_module.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await ClinicalModule.init();
    // Now you can call clinical methods:
    final patient = await ClinicalModule.fetchPatient(
      'patient-id', 'https://fhir.example.com', 'API_KEY'
    );
    print(patient.toJson());
  } catch (e) {
    // Handle missing subscription or errors
  }
}
```
