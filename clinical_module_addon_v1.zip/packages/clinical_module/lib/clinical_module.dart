library clinical_module;

import 'dart:developer';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:http/http.dart' as http;
import 'package:fhir/r4.dart';

/// Module providing clinical features for medical professionals.
class ClinicalModule {
  static const _productID = 'clinical_module_pro';

  /// Initialize the module, verifying professional subscription.
  static Future<void> init() async {
    final available = await InAppPurchase.instance.isAvailable();
    if (!available) {
      throw Exception('In-app purchases not available');
    }
    final purchases = await InAppPurchase.instance.queryPastPurchases();
    final hasPro = purchases.pastPurchases.any((p) => p.productID == _productID && p.status == PurchaseStatus.purchased);
    if (!hasPro) {
      throw Exception('Professional subscription required');
    }
    developer.log('ClinicalModule initialized: subscription verified', name: 'ClinicalModule');
  }

  /// Fetch patient data via FHIR API.
  static Future<Patient> fetchPatient(String patientId, String fhirServer, String apiKey) async {
    final url = Uri.parse('\$fhirServer/Patient/\$patientId');
    final response = await http.get(url, headers: {
      'Authorization': 'Bearer \$apiKey',
      'Accept': 'application/fhir+json'
    });
    if (response.statusCode == 200) {
      return Patient.fromJson(response.body);
    } else {
      throw Exception('Failed to fetch patient: \${response.statusCode}');
    }
  }
}
