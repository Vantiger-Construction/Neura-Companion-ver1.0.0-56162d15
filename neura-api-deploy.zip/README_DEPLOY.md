# Neura API Deployment Kit

## Local Development with Docker Compose
1. Copy your `.env` file (or rename `.env.example` to `.env`) and set values.
2. Run migrations: `docker-compose run --rm migrate`
3. Start services: `docker-compose up --build`

Visit http://localhost:8000 for the API and http://localhost:8000/docs for Swagger UI.

## Kubernetes Deployment
1. Create secrets:
   ```bash
   kubectl create secret generic neura-api-secrets \
     --from-literal=JWT_SECRET=$JWT_SECRET \
     --from-literal=WEBHOOK_SECRET=$WEBHOOK_SECRET \
     --from-literal=DATABASE_URL=$DATABASE_URL
   ```
2. Apply resources:
   ```bash
   kubectl apply -f k8s/deployment.yaml -f k8s/service.yaml -f k8s/ingress.yaml
   ```

Ensure your container image `ghcr.io/<your-org>/neura-api:latest` exists in GitHub Container Registry.
