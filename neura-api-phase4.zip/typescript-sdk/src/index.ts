import axios, { AxiosInstance } from 'axios';

export class NeuraClient {
  private client: AxiosInstance;

  constructor(private baseUrl: string, private token: string) {
    this.client = axios.create({
      baseURL: baseUrl,
      headers: { Authorization: `Bearer ${token}` },
    });
  }

  async listResources(cursor: number = 0, limit: number = 50) {
    const resp = await this.client.get('/v1/resources', { params: { cursor, limit } });
    return resp.data;
  }

  async subscribe(url: string, eventType: string) {
    const resp = await this.client.post('/v1/webhooks/subscribe', { url, eventType });
    return resp.data;
  }
}
