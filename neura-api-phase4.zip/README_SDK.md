# Neura API SDKs & Samples

## Python SDK

Install and use the Python SDK:

```bash
cd python-sdk
pip install .
# Set environment variables or use defaults
neura-harness
```

This will list resources and create a test subscription.

## TypeScript SDK

Build and use the TypeScript SDK in your Node.js project:

```bash
cd typescript-sdk
npm install
npm run build
```

Then in your code:

```ts
import { NeuraClient } from '@neura/sdk';

const client = new NeuraClient('http://localhost:8000', 'your-token');
client.listResources().then(console.log);
```

## React Demo

A minimal React demo is available in `webhooks-dashboard` for viewing subscriptions. Install dependencies and start:

```bash
cd webhooks-dashboard
npm install
npm start
```

## Environment Variables

- `NEURA_API_URL`: Base URL of your Neura API (default: http://localhost:8000)  
- `NEURA_USERNAME`, `NEURA_PASSWORD`: Credentials for auth harness
