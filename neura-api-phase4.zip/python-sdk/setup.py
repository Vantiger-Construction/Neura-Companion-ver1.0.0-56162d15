from setuptools import setup, find_packages

setup(
    name='neura_sdk',
    version='0.1.0',
    description='Python client SDK for Neura API',
    author='Neura Companion',
    packages=find_packages(),
    install_requires=[
        'requests',
    ],
    entry_points={
        'console_scripts': [
            'neura-harness=neura_sdk.harness:main',
        ],
    },
)
