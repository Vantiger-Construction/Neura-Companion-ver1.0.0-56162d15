import os
import time
import hmac
import jwt
from neura_sdk.client import NeuraClient

def main():
    base_url = os.getenv('NEURA_API_URL', 'http://localhost:8000')
    username = os.getenv('NEURA_USERNAME', 'alice')
    password = os.getenv('NEURA_PASSWORD', 'secret')
    # Obtain token
    from requests import post
    resp = post(f"{base_url}/v1/auth/token", data={'username': username, 'password': password})
    resp.raise_for_status()
    token = resp.json()['access_token']
    client = NeuraClient(base_url, token)
    print("Listing resources...")
    resources = client.list_resources()
    print(resources)
    # Subscribe to a test webhook
    print("Subscribing to webhook...")
    sub = client.subscribe('https://webhook.site/your-id', 'resource.created')
    print("Created subscription:", sub)

if __name__ == '__main__':
    main()
