import requests

class NeuraClient:
    def __init__(self, base_url: str, token: str):
        self.base_url = base_url.rstrip('/')
        self.token = token

    def list_resources(self, cursor: int = 0, limit: int = 50):
        resp = requests.get(
            f"{self.base_url}/v1/resources",
            params={"cursor": cursor, "limit": limit},
            headers={"Authorization": f"Bearer {self.token}"},
        )
        resp.raise_for_status()
        return resp.json()

    def subscribe(self, url: str, event_type: str):
        resp = requests.post(
            f"{self.base_url}/v1/webhooks/subscribe",
            json={"url": url, "eventType": event_type},
            headers={"Authorization": f"Bearer {self.token}"},
        )
        resp.raise_for_status()
        return resp.json()

    # add more client methods as needed
