import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/mood_provider.dart';
import '../widgets/mood_chart.dart';

class MoodPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final moodProv = Provider.of<MoodProvider>(context);
    final moods = moodProv.moods;
    return Scaffold(
      appBar: AppBar(title: Text('Mood Tracker')),
      body: Column(
        children: [
          SizedBox(height: 180, child: MoodChart(moods)),
          Expanded(
            child: ListView(
              children: moods.map((m) => ListTile(
                title: Text(m.mood),
                subtitle: Text(m.note ?? ''),
                trailing: Text(m.timestamp.toLocal().toString().substring(0, 16)),
              )).toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: MoodForm(),
          ),
        ],
      ),
    );
  }
}

class MoodForm extends StatefulWidget {
  @override
  State<MoodForm> createState() => _MoodFormState();
}

class _MoodFormState extends State<MoodForm> {
  final _moodCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();

  void _submit() {
    if (_moodCtrl.text.isEmpty) return;
    Provider.of<MoodProvider>(context, listen: false)
        .submitMood(_moodCtrl.text, _noteCtrl.text.isEmpty ? null : _noteCtrl.text);
    _moodCtrl.clear();
    _noteCtrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: TextField(controller: _moodCtrl, decoration: InputDecoration(labelText: 'Mood'))),
        Expanded(child: TextField(controller: _noteCtrl, decoration: InputDecoration(labelText: 'Note'))),
        ElevatedButton(onPressed: _submit, child: Text('Add'))
      ],
    );
  }
}
