import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../models/mood.dart';

class MoodChart extends StatelessWidget {
  final List<Mood> moods;
  MoodChart(this.moods);

  @override
  Widget build(BuildContext context) {
    final points = moods
        .asMap()
        .entries
        .map((e) => FlSpot(e.key.toDouble(), e.value.mood.hashCode.toDouble() % 10))
        .toList();
    return LineChart(LineChartData(
      titlesData: FlTitlesData(show: false),
      borderData: FlBorderData(show: false),
      lineBarsData: [
        LineChartBarData(spots: points, isCurved: true, dotData: FlDotData(show: true))
      ],
    ));
  }
}
