
@echo off
REM Setup Neuro Companion Flutter Project with Environment and Android Studio Launch

:: Set environment variables (adjust these paths if Flutter is in a different directory)
setx FLUTTER_HOME "C:\src\flutter" /M
setx PATH "%PATH%;C:\src\flutter\bin;C:\src\flutter\bin\cache\dart-sdk\bin" /M

:: Change to the project directory
cd /d "%~dp0"

echo Cleaning project...
flutter clean

echo Getting Flutter packages...
flutter pub get

echo Attempting to launch Android Studio...

:: Try to launch Android Studio (adjust if installed elsewhere)
IF EXIST "C:\Program Files\Android\Android Studio\bin\studio64.exe" (
    START "" "C:\Program Files\Android\Android Studio\bin\studio64.exe" "%cd%"
) ELSE (
    echo Android Studio not found at default location.
    echo Please launch Android Studio manually and open the project from: %cd%
)

echo Setup complete.
pause
