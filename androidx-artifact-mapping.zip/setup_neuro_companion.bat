
@echo off
REM Setup Neuro Companion Flutter Project

cd /d "%~dp0"

echo Running flutter clean...
flutter clean

echo Getting dependencies...
flutter pub get

echo Setup complete. You can now open this project in Android Studio or VS Code.

pause
