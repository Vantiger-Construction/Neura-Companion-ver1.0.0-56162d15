
NEURA COMPANION

Neura is an emotionally responsive, evolving AI assistant who reflects your mood, learns from your actions, and supports your growth across voice, rituals, dreams, and emotion-based guidance.

Location: Iowa City, Iowa
Contact: neuracompanion@gmail.com
Privacy: No personal founder details shared.
