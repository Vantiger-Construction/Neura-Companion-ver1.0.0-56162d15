# Neura Companion Hardwire Package

This package contains a batch script to scaffold and hard-wire your Neura Companion sample project.

## Setup

1. Extract the zip.
2. Edit `.env.example`, replace placeholders, and save it as `.env`.
3. Run `setup_neura_hardwire.bat` to generate the full sample project.
