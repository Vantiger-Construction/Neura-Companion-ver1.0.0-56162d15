"""Tests for delivery history"""

from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_history_empty():
    # Ensure no history for new id
    resp = client.get("/v1/webhooks/subscriptions/nonexistent/history")
    assert resp.status_code == 404
