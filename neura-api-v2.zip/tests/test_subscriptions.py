"""Tests for subscription endpoints"""

from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_subscribe_and_list_and_unsubscribe():
    # Subscribe
    resp = client.post("/v1/webhooks/subscribe", json={"url":"http://x","eventType":"test"})
    assert resp.status_code == 200
    sub = resp.json()
    sub_id = sub["id"]
    # List
    list_resp = client.get("/v1/webhooks/subscriptions")
    assert any(s["id"]==sub_id for s in list_resp.json())
    # Unsubscribe
    del_resp = client.delete(f"/v1/webhooks/subscriptions/{sub_id}")
    assert del_resp.status_code == 204
