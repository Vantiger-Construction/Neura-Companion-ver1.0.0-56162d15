# Neura API v2 Schema

## Subscription Management

### Subscribe
POST /v1/webhooks/subscribe

### List Subscriptions
GET /v1/webhooks/subscriptions

### Unsubscribe
DELETE /v1/webhooks/subscriptions/{id}

### Delivery History
GET /v1/webhooks/subscriptions/{id}/history

## Custom Events

- `user.deceased`
- `session.transfer`
