// TypeScript SDK for Neura API

import axios from 'axios';

export class NeuraClient {
  constructor(private baseUrl: string, private token: string) {}

  listSubscriptions() {
    return axios.get(`${this.baseUrl}/webhooks/subscriptions`, { headers: { Authorization: `Bearer ${this.token}` } });
  }

  unsubscribe(id: string) {
    return axios.delete(`${this.baseUrl}/webhooks/subscriptions/${id}`, { headers: { Authorization: `Bearer ${this.token}` } });
  }
}
