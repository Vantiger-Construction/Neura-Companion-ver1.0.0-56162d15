"""Python SDK for Neura API"""

import requests

class NeuraClient:
    def __init__(self, base_url, token):
        self.base_url = base_url
        self.token = token

    def list_subscriptions(self):
        return requests.get(f"{self.base_url}/webhooks/subscriptions", headers={"Authorization": f"Bearer {self.token}"}).json()

    def unsubscribe(self, sub_id):
        return requests.delete(f"{self.base_url}/webhooks/subscriptions/{sub_id}", headers={"Authorization": f"Bearer {self.token}"})
