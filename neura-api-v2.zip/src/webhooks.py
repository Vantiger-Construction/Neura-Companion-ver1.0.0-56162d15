"""Webhook management and event handling"""

import os
import hmac
import httpx
from fastapi import APIRouter, Request, HTTPException, Depends
from src.security import verify_replay, sign_payload
from slowapi import limiter

router = APIRouter()
subscriptions = {}
delivery_history = {}

@router.post("/subscribe")
@limiter.limit("50/minute")
async def subscribe(body: dict, token: str = Depends()):
    sub_id = "sub" + str(len(subscriptions)+1)
    subscriptions[sub_id] = body
    delivery_history[sub_id] = []
    return {"id": sub_id, **body}

@router.get("/subscriptions")
@limiter.limit("50/minute")
async def list_subscriptions(token: str = Depends()):
    return [{"id": k, **v} for k,v in subscriptions.items()]

@router.delete("/subscriptions/{id}", status_code=204)
@limiter.limit("20/minute")
async def unsubscribe(id: str, token: str = Depends()):
    if id not in subscriptions:
        raise HTTPException(status_code=404, detail="Subscription not found")
    del subscriptions[id]
    delivery_history.pop(id, None)
    return

@router.get("/subscriptions/{id}/history")
@limiter.limit("50/minute")
async def get_history(id: str, token: str = Depends()):
    if id not in delivery_history:
        raise HTTPException(status_code=404, detail="History not found")
    return {"id": id, "history": delivery_history[id]}

@router.post("/receive")
@limiter.limit("100/minute")
async def receive_event(request: Request):
    timestamp = request.headers.get("X-Timestamp")
    signature = request.headers.get("X-Signature")
    body = await request.body()
    if not timestamp or not signature or not verify_replay(timestamp):
        raise HTTPException(status_code=400, detail="Invalid or missing signature/timestamp")
    expected = sign_payload(os.getenv("WEBHOOK_SECRET", "secretkey"), body)
    if not hmac.compare_digest(expected, signature):
        raise HTTPException(status_code=401, detail="Signature verification failed")
    event = await request.json()
    results = []
    for sid, sub in subscriptions.items():
        try:
            resp = await httpx.post(sub["url"], json=event)
            code = resp.status_code
        except:
            code = "error"
        record = {"timestamp": timestamp, "statusCode": code}
        delivery_history[sid].append(record)
        results.append({"id": sid, "status": code})
    return {"dispatched": results}

@router.post("/legacy")
@limiter.limit("30/minute")
async def legacy_trigger(body: dict):
    event = {"type": body.get("legacyEventName"), **body.get("payload", {})}
    results = []
    for sid, sub in subscriptions.items():
        try:
            resp = await httpx.post(sub["url"], json=event)
            code = resp.status_code
        except:
            code = "error"
        record = {"timestamp": str(int(__import__('time').time())), "statusCode": code}
        delivery_history[sid].append(record)
        results.append({"id": sid, "status": code})
    return {"dispatched": results}
