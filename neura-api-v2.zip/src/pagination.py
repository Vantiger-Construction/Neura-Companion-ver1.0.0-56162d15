"""Simple cursor-based pagination"""

def paginate_list(items, cursor=None, limit=50):
    start = int(cursor) if cursor else 0
    end = start + limit
    next_cursor = str(end) if end < len(items) else None
    prev_cursor = str(start - limit) if start - limit >= 0 else None
    return {"items": items[start:end], "pageInfo": {"nextCursor": next_cursor, "prevCursor": prev_cursor}}
