#!/usr/bin/env bash
set -e
echo "Installing Neura Companion feature modules..."
flutter pub get
echo "✔ All feature modules registered."
