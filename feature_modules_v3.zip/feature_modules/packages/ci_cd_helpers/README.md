# ci_cd_helpers

## Installation
Add to root pubspec.yaml:
```yaml
ci_cd_helpers:
  path: ./packages/ci_cd_helpers
```

## Usage
```dart
import 'package:ci_cd_helpers/ci_cd_helpers.dart';
await CiCdHelpers.init();
```