library ci_cd_helpers;

class CiCdHelpers {
  static void init() {/* setup CI badges in README */}
}