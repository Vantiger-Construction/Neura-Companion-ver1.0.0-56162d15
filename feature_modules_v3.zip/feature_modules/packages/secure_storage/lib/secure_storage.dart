library secure_storage;

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorage {
  static final _st = FlutterSecureStorage();

  static Future<void> init() async {}

  static Future<void> write(String key, String val) => _st.write(key: key, value: val);
  static Future<String?> read(String key) => _st.read(key: key);
}