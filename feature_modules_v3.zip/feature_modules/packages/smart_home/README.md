# smart_home

## Installation
Add to root pubspec.yaml:
```yaml
smart_home:
  path: ./packages/smart_home
```

## Usage
```dart
import 'package:smart_home/smart_home.dart';
await SmartHome.init();
```