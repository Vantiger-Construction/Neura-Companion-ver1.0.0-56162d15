library dynamic_theme;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DynamicTheme extends StatefulWidget {
  final Widget Function(BuildContext, ThemeData) builder;
  const DynamicTheme({required this.builder, Key? key}) : super(key: key);

  static late SharedPreferences prefs;
  static Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
  }

  @override
  _DynamicThemeState createState() => _DynamicThemeState();
}

class _DynamicThemeState extends State<DynamicTheme> {
  late bool _isDark;

  @override
  void initState() {
    super.initState();
    _isDark = DynamicTheme.prefs.getBool('darkMode') ?? false;
  }

  void _toggleMode() {
    setState(() => _isDark = !_isDark);
    DynamicTheme.prefs.setBool('darkMode', _isDark);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: _toggleMode,
      child: widget.builder(context, _isDark ? ThemeData.dark() : ThemeData.light()),
    );
  }
}