library state_di;

import 'package:get_it/get_it.dart';

final sl = GetIt.instance;

class StateDi {
  static Future<void> init() async {
    // sl.registerSingleton<SomeService>(SomeServiceImpl());
  }
}