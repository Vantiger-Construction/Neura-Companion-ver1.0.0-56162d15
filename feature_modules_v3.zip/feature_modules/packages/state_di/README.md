# state_di

## Installation
Add to root pubspec.yaml:
```yaml
state_di:
  path: ./packages/state_di
```

## Usage
```dart
import 'package:state_di/state_di.dart';
await StateDi.init();
```