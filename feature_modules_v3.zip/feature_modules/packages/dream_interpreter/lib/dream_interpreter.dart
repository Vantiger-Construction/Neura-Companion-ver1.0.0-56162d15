library dream_interpreter;

import 'dart:convert';
import 'package:http/http.dart' as http;

class DreamInterpreter {
  static late String _apiKey;
  static void configure({required String apiKey}) => _apiKey = apiKey;

  static Future<String> analyze(String transcript) async {
    final resp = await http.post(
      Uri.parse('https://api.openai.com/v1/chat/completions'),
      headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $_apiKey'},
      body: jsonEncode({
        'model': 'gpt-4o-mini',
        'messages': [{'role': 'user', 'content': 'Interpret my dream: $transcript'}]
      }),
    );
    if (resp.statusCode == 200) return jsonDecode(resp.body)['choices'][0]['message']['content'];
    throw Exception('Dream API error: ${resp.statusCode}');
  }
}