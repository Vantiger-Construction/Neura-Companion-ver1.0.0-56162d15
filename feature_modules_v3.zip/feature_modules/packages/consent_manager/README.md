# consent_manager

## Installation
Add to root pubspec.yaml:
```yaml
consent_manager:
  path: ./packages/consent_manager
```

## Usage
```dart
import 'package:consent_manager/consent_manager.dart';
await ConsentManager.init();
```