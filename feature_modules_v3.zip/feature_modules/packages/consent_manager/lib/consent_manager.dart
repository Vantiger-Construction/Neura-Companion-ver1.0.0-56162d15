library consent_manager;

import 'package:shared_preferences/shared_preferences.dart';

class ConsentManager {
  static late SharedPreferences _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    if (!(_prefs.getBool('consentGiven') ?? false)) {
      _prefs.setBool('consentGiven', true);
    }
  }
}