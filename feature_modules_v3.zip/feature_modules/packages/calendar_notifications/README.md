# calendar_notifications

## Installation
Add to root pubspec.yaml:
```yaml
calendar_notifications:
  path: ./packages/calendar_notifications
```

## Usage
```dart
import 'package:calendar_notifications/calendar_notifications.dart';
await CalendarNotifications.init();
```