from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_subscribe_batch_and_delete_batch():
    # Bulk subscribe
    subs_payload = [
        {"url": "http://x1", "eventType": "e1"},
        {"url": "http://x2", "eventType": "e2"}
    ]
    resp = client.post("/v1/webhooks/subscriptions/bulk", json=subs_payload)
    assert resp.status_code == 201
    created = resp.json()
    ids = [s["id"] for s in created]
    assert len(ids) == 2

    # Bulk unsubscribe
    del_resp = client.delete("/v1/webhooks/subscriptions/bulk", json=ids)
    assert del_resp.status_code == 204

def test_dispatch_bulk(monkeypatch):
    # Create a subscription
    resp = client.post("/v1/webhooks/subscriptions/bulk", json=[{"url":"http://x","eventType":"e"}])
    sid = resp.json()[0]["id"]
    # Bulk dispatch
    events = {"events": [{"foo":"bar"}, {"baz":123}]}
    resp2 = client.post("/v1/webhooks/dispatch-bulk", json=events)
    assert resp2.status_code == 200
    assert resp2.json()["dispatchedCount"] >= 2
