import os
import hmac
import time
import datetime
from fastapi import APIRouter, Request, Depends, HTTPException
from typing import List, Dict, Any
from sqlmodel import select
from src.db import get_session
from src.models import Subscription
from src.schemas import SubscriptionCreate, LegacyTrigger
from src.errors import APIError
from src.tasks import dispatch_event
from slowapi import limiter

router = APIRouter()

@router.post("/subscriptions/bulk", response_model=List[Subscription], status_code=201)
@limiter.limit("20/minute")
def subscribe_bulk(subs: List[SubscriptionCreate], session=Depends(get_session)):
    created = []
    for sub in subs:
        s = Subscription(url=sub.url, eventType=sub.eventType)
        session.add(s)
        created.append(s)
    session.commit()
    for s in created:
        session.refresh(s)
    return created

@router.delete("/subscriptions/bulk", status_code=204)
@limiter.limit("10/minute")
def unsubscribe_bulk(ids: List[int], session=Depends(get_session)):
    for sid in ids:
        s = session.get(Subscription, sid)
        if not s:
            raise APIError("SUB_NOT_FOUND")
        session.delete(s)
    session.commit()

@router.post("/dispatch-bulk", status_code=200)
@limiter.limit("50/minute")
def dispatch_bulk(payload: Dict[str, List[Dict[str, Any]]], session=Depends(get_session)):
    events = payload.get("events", [])
    subs = session.exec(select(Subscription)).all()
    count = 0
    for event in events:
        for sub in subs:
            dispatch_event.delay(sub.id, event)
            count += 1
    return {"dispatchedCount": count}
