library state_di;

import 'package:get_it/get_it.dart';

final sl = GetIt.instance;

abstract class ExampleService {
  String fetchInfo();
}

class ExampleServiceImpl implements ExampleService {
  @override
  String fetchInfo() => 'Example Service Data';
}

class StateDi {
  static Future<void> init() async {
    sl.registerLazySingleton<ExampleService>(() => ExampleServiceImpl());
  }
}