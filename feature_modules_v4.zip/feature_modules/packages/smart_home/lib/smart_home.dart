library smart_home;

import 'dart:async';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';

class SmartHomeHooks {
  static late MqttServerClient client;

  static Future<void> init({required String server, int port = 1883, String clientId = 'neura'}) async {
    client = MqttServerClient(server, clientId);
    client.port = port;
    client.keepAlivePeriod = 20;
    client.logging(on: false);
    client.onConnected = () => print('MQTT connected');
    client.onDisconnected = () => print('MQTT disconnected');
    final connMess = MqttConnectMessage()
        .withClientIdentifier(clientId)
        .startClean()
        .withWillQos(MqttQos.atLeastOnce);
    client.connectionMessage = connMess;
    try {
      await client.connect();
    } catch (e) {
      client.disconnect();
      throw Exception('MQTT connection failed: \$e');
    }
  }

  static void subscribe(String topic) {
    client.subscribe(topic, MqttQos.atLeastOnce);
  }

  static void publish(String topic, String message) {
    final builder = MqttClientPayloadBuilder();
    builder.addString(message);
    client.publishMessage(topic, MqttQos.atLeastOnce, builder.payload!);
  }
}