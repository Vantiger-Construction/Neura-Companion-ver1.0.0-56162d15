library ci_cd_helpers;

import 'dart:io';

class CiCdHelpers {
  /// Call this to inject CI badges into README.md
  static Future<void> init() async {
    final readme = File('README.md');
    if (!await readme.exists()) return;
    final content = await readme.readAsString();
    final badge = '![Build Status](https://github.com/yourrepo/neura/workflows/CI/badge.svg)';
    if (!content.contains(badge)) {
      await readme.writeAsString('\$badge\n\n\$content');
      print('CI badge injected.');
    }
  }
}