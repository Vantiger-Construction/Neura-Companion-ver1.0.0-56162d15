
import 'package:flutter/material.dart';

class MoodForecastAnimation extends StatelessWidget {
  final String mood;
  MoodForecastAnimation({required this.mood});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: Duration(seconds: 2),
      curve: Curves.easeInOut,
      color: mood == 'happy' ? Colors.yellowAccent :
             mood == 'sad' ? Colors.blueGrey :
             mood == 'angry' ? Colors.redAccent :
             Colors.white,
      child: Center(
        child: Text(
          'Forecast: $mood',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
