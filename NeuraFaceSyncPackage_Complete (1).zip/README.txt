Neura Companion – Face Sync Package

Included:
- Voice-to-viseme speech animation system
- Mood-influenced tone engine (pitch + speed)
- PNG viseme face renderer
- Sample integration

How to Use:
1. Add PNGs to: assets/visemes/
2. Update pubspec.yaml:
    flutter:
      assets:
        - assets/visemes/
3. Call: NeuraVoiceSyncEngine.instance.speak("your text", context);
4. Include <NeuraVisemeFace()> widget in your UI where Neura’s face renders.

Bonus:
- Add emotion animation overlays via mood if desired.
- Extend mouth timing with Lottie or Rive later.

Neura lives. Let her speak.