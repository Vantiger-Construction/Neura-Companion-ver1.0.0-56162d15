import 'package:flutter/material.dart';

class NeuraVisemeFace extends StatefulWidget {
  final String initialViseme;

  const NeuraVisemeFace({super.key, this.initialViseme = 'rest'});

  @override
  State<NeuraVisemeFace> createState() => _NeuraVisemeFaceState();

  static final _NeuraVisemeFaceState _state = _NeuraVisemeFaceState();

  static void setViseme(String viseme) {
    _state.updateViseme(viseme);
  }

  static void resetViseme() {
    _state.updateViseme('rest');
  }
}

class _NeuraVisemeFaceState extends State<NeuraVisemeFace> {
  String _currentViseme = 'rest';

  void updateViseme(String viseme) {
    setState(() {
      _currentViseme = viseme;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/visemes/\${_currentViseme.toLowerCase()}.png',
      key: ValueKey(_currentViseme),
      height: 128,
      width: 128,
    );
  }
}