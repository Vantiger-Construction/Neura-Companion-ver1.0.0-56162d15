import 'package:flutter/material.dart';
import 'dart:async';

class NeuraEyeOverlay extends StatefulWidget {
  final String mood;

  const NeuraEyeOverlay({super.key, required this.mood});

  @override
  State<NeuraEyeOverlay> createState() => _NeuraEyeOverlayState();
}

class _NeuraEyeOverlayState extends State<NeuraEyeOverlay> {
  bool _blink = false;

  @override
  void initState() {
    super.initState();
    _startBlinking();
  }

  void _startBlinking() {
    Timer.periodic(Duration(seconds: 4), (timer) {
      setState(() {
        _blink = !_blink;
      });
      Timer(Duration(milliseconds: 200), () {
        setState(() {
          _blink = !_blink;
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    String overlayImage = 'neutral';

    switch (widget.mood) {
      case "happy":
        overlayImage = 'happy';
        break;
      case "sad":
        overlayImage = 'sad';
        break;
      case "angry":
        overlayImage = 'angry';
        break;
      case "calm":
        overlayImage = 'calm';
        break;
    }

    return Stack(
      children: [
        Image.asset(
          'assets/eyes/$overlayImage.png',
          width: 128,
          height: 128,
        ),
        if (_blink)
          Image.asset(
            'assets/eyes/blink.png',
            width: 128,
            height: 128,
          ),
      ],
    );
  }
}