import 'NeuraVisemeFace.dart';

class NeuraVisemeAnimator {
  static void startSpeaking() => NeuraVisemeFace.setViseme('a');

  static void updateFromWord(String word) {
    final lower = word.toLowerCase();
    if (lower.contains(RegExp(r'[aei]'))) {
      NeuraVisemeFace.setViseme('e');
    } else if (lower.contains(RegExp(r'[ou]'))) {
      NeuraVisemeFace.setViseme('o');
    } else if (lower.contains(RegExp(r'[mnbp]'))) {
      NeuraVisemeFace.setViseme('m');
    } else if (lower.contains(RegExp(r'[wq]'))) {
      NeuraVisemeFace.setViseme('w');
    } else {
      NeuraVisemeFace.setViseme('a');
    }
  }

  static void stopSpeaking() => NeuraVisemeFace.resetViseme();
}