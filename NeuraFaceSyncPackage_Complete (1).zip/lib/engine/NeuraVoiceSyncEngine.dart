import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../widgets/NeuraVisemeAnimator.dart';
import '../mood/NeuraMoodManager.dart';

class NeuraVoiceSyncEngine {
  final FlutterTts _tts = FlutterTts();

  NeuraVoiceSyncEngine._privateConstructor() {
    _setupTTS();
  }

  static final NeuraVoiceSyncEngine _instance =
      NeuraVoiceSyncEngine._privateConstructor();

  static NeuraVoiceSyncEngine get instance => _instance;

  void _setupTTS() {
    _tts.setLanguage("en-US");
    _tts.setPitch(1.0);
    _tts.setSpeechRate(0.45);

    _tts.setStartHandler(() {
      NeuraVisemeAnimator.startSpeaking();
    });

    _tts.setProgressHandler((String text, int start, int end, String word) {
      NeuraVisemeAnimator.updateFromWord(word);
    });

    _tts.setCompletionHandler(() {
      NeuraVisemeAnimator.stopSpeaking();
    });
  }

  Future<void> speak(String text, BuildContext context) async {
    final mood = Provider.of<NeuraMoodManager>(context, listen: false).currentMood;
    double pitch = 1.0;
    double rate = 0.45;

    switch (mood) {
      case "happy":
        pitch = 1.3;
        rate = 0.5;
        break;
      case "sad":
        pitch = 0.8;
        rate = 0.4;
        break;
      case "angry":
        pitch = 1.1;
        rate = 0.6;
        break;
      case "calm":
        pitch = 0.95;
        rate = 0.42;
        break;
    }

    await _tts.setPitch(pitch);
    await _tts.setSpeechRate(rate);
    await _tts.speak(text);
  }
}