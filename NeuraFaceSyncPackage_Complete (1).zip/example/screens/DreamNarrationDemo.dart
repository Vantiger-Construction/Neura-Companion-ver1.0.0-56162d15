import 'package:flutter/material.dart';
import '../../lib/engine/NeuraVoiceSyncEngine.dart';

class DreamNarrationDemo extends StatelessWidget {
  const DreamNarrationDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Dream Narration Demo')),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            NeuraVoiceSyncEngine.instance.speak(
              "Last night, I dreamed I was flying through stars!",
              context,
            );
          },
          child: Text("Narrate Dream"),
        ),
      ),
    );
  }
}