import 'package:flutter/material.dart';
import '../../lib/engine/NeuraVoiceSyncEngine.dart';

class JournalNarrationDemo extends StatelessWidget {
  const JournalNarrationDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Journal Narration Demo')),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            NeuraVoiceSyncEngine.instance.speak(
              "Today I felt really proud of myself.",
              context,
            );
          },
          child: Text("Narrate Journal Entry"),
        ),
      ),
    );
  }
}