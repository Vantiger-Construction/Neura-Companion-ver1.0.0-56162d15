import 'package:flutter/material.dart';
import '../../lib/engine/NeuraVoiceSyncEngine.dart';

class ChatBubbleDemo extends StatelessWidget {
  const ChatBubbleDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Neura Chat Bubble')),
      body: ListView(
        children: [
          ListTile(
            title: Text("You: How are you, Neura?"),
          ),
          ListTile(
            title: Text("Neura: I'm doing well, thank you!"),
            onTap: () {
              NeuraVoiceSyncEngine.instance.speak("I'm doing well, thank you!", context);
            },
          )
        ],
      ),
    );
  }
}