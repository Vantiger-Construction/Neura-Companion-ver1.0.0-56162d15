
Neura Companion – Real Export Assets

📽️ video/dream_mode_preview.mp4 – Dream Mode cinematic (placeholder)
🧩 lottie/dream_mode_animation.json – Lottie animation for Dream Mode
🛠 installer/setup_neura_installer.nsi – Windows installer script (NSIS)

Replace MP4 and JSON with real exports for launch.
Use NSIS (Nullsoft) to compile setup_neura_installer.nsi into a .exe installer.
