
; Neura Companion Installer Script (NSIS)
Outfile "NeuraCompanionInstaller.exe"
InstallDir $PROGRAMFILES\NeuraCompanion
Page directory
Page instfiles
Section ""
  SetOutPath $INSTDIR
  File dream_mode_preview.mp4
  File dream_mode_animation.json
  CreateShortCut "$DESKTOP\Neura Companion.lnk" "$INSTDIR\NeuraCompanion.exe"
SectionEnd
