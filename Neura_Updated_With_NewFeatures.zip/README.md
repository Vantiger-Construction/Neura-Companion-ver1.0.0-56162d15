
# Neura Mega Module

This Flutter module contains the full Neura AI Companion system with all advanced features:

## Core Features:
- Emotion Engine + Animated Glow Avatar
- Voice Personality + Quiet Mode
- Growth Memory + Instrument Learning
- Full Joke System (clean/spicy, rating, favorites)
- Dream Recording, Interpretation, Journal & Show Player
- Billing and Add-on Toggle Logic

## Usage:
Import the components from `lib/neura/` into your app.

Use NeuraManager to control and synchronize her brain, memory, and behavior.

