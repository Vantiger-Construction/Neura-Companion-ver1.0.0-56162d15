# BiometricFeedback

## Installation
Add to root `pubspec.yaml`:
```yaml
biometric_feedback:
  path: ./packages/biometric_feedback
```

## Usage
```dart
import 'package:biometric_feedback/biometric_feedback.dart';

// Initialize
final module = await BiometricFeedback.init(HealthApiImpl()); // or pass mock for tests

// Example
final hrv = await module.fetchAverageHrv(DateTime.now().subtract(Duration(hours:1)), DateTime.now());
```
