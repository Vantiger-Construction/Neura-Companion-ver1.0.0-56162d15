# HapticVisualCues

## Installation
Add to root `pubspec.yaml`:
```yaml
haptic_visual_cues:
  path: ./packages/haptic_visual_cues
``` 

## Usage
```dart
import 'package:haptic_visual_cues/haptic_visual_cues.dart';

await HapticVisualCues.init();
// Example:
// TODO: use HapticVisualCues features
```