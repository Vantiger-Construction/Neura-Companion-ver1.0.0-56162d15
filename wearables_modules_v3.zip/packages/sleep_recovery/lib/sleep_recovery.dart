library sleep_recovery;

import 'package:health/health.dart';

class SleepRecovery {
  static final _health = HealthFactory();

  static Future<void> init() async {
    final types = [HealthDataType.SLEEP_IN_BED, HealthDataType.SLEEP_ASLEEP];
    await _health.requestAuthorization(types);
  }

  static Future<Map<String, Duration>> fetchSleepStats(DateTime start, DateTime end) async {
    final raw = await _health.getHealthDataFromTypes(start, end, [HealthDataType.SLEEP_IN_BED, HealthDataType.SLEEP_ASLEEP]);
    Duration inBed = Duration.zero, asleep = Duration.zero;
    for (var e in raw) {
      final dur = e.unit == HealthDataUnit.MINUTE
          ? Duration(minutes: (e.value as double).round())
          : Duration.zero;
      if (e.type == HealthDataType.SLEEP_IN_BED) inBed += dur;
      if (e.type == HealthDataType.SLEEP_ASLEEP) asleep += dur;
    }
    return {'inBed': inBed, 'asleep': asleep};
  }
}