import 'package:biometric_feedback/biometric_feedback.dart';
import 'package:activity_posture/activity_posture.dart';

class WearableModulesV3 {
  static Future<void> initAll() async {
    await BiometricFeedback.init(HealthApiImpl());
    await ActivityPosture.init(HealthApiImpl());
  }
}
