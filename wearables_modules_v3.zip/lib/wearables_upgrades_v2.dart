import 'package:biometric_feedback/biometric_feedback.dart';
import 'package:activity_posture/activity_posture.dart';
import 'package:sleep_recovery/sleep_recovery.dart';
import 'package:haptic_visual_cues/haptic_visual_cues.dart';
import 'package:on_the_go_logging/on_the_go_logging.dart';
import 'package:micro_workouts/micro_workouts.dart';
import 'package:health_trend_insights/health_trend_insights.dart';
import 'package:third_party_sensors/third_party_sensors.dart';

class WearableModulesV2 {
  static Future<void> initAll() async {
    await BiometricFeedback.init();
    await ActivityPosture.init();
    await SleepRecovery.init();
    await HapticVisualCues.init();
    await OnTheGoLogging.init();
    await MicroWorkouts.init();
    await HealthTrendInsights.init();
    await ThirdPartySensors.init();
  }
}
