import 'dart:async';

class NeuraAmbientListener {
  final Function onQuietDetected;
  Timer? _idleTimer;

  void startMonitoring() {
    _idleTimer = Timer(Duration(minutes: 5), () {
      onQuietDetected();
    });
  }

  void reset() {
    _idleTimer?.cancel();
    startMonitoring();
  }

  void stop() {
    _idleTimer?.cancel();
  }
}