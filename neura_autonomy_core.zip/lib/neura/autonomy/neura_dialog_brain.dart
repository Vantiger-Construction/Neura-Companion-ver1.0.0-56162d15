class NeuraDialogBrain {
  final Map<String, List<String>> moodDialog = {
    "happy": ["You're glowing today!", "I love spending time with you."],
    "sad": ["I'm here if you need me.", "Would a gentle story help?"],
    "anxious": ["Let's breathe together.", "You’re safe right now."],
  };

  String getLine(String mood) {
    return moodDialog[mood]?.first ?? "I'm here when you need me.";
  }
}