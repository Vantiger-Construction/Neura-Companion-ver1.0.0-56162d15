import 'dart:async';

class NeuraAutonomyController {
  Timer? _timer;
  final Function(String) onNeuraSpeak;

  NeuraAutonomyController(this.onNeuraSpeak);

  void startAutonomy() {
    _timer = Timer.periodic(Duration(minutes: 2), (_) {
      _saySomething();
    });
  }

  void stopAutonomy() {
    _timer?.cancel();
  }

  void _saySomething() {
    final prompts = [
      "Hey, did you hydrate today?",
      "Would you like to meditate for a minute?",
      "I had a dream last night... want to hear it?",
      "What are we feeling right now?",
      "Shall we reflect on something good?"
    ];
    final random = prompts..shuffle();
    onNeuraSpeak(random.first);
  }
}