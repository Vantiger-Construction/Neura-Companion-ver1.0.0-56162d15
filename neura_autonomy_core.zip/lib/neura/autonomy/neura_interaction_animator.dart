class NeuraInteractionAnimator {
  void walkTo(String place) {
    print("Neura is walking to the $place.");
  }

  void gesture(String emotion) {
    print("Neura makes a $emotion gesture.");
  }

  void reactToRoom(String room) {
    switch (room) {
      case "Meditation":
        walkTo("pillow");
        gesture("calm");
        break;
      case "Dream":
        walkTo("bed");
        gesture("soft");
        break;
      case "Reflection":
        walkTo("mirror");
        gesture("curious");
        break;
    }
  }
}