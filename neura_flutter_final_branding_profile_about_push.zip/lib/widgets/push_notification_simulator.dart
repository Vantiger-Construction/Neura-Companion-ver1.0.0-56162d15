import 'package:flutter/material.dart';

class PushNotificationSimulator extends StatefulWidget {
  @override
  State<PushNotificationSimulator> createState() => _PushNotificationSimulatorState();
}

class _PushNotificationSimulatorState extends State<PushNotificationSimulator> {
  final List<String> _notifs = [];

  void _pushDemo() {
    setState(() {
      _notifs.add("🔔 You received a Neura notification at ${DateTime.now().toLocal().toString().substring(11,16)}");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ElevatedButton.icon(
          icon: Icon(Icons.send),
          label: Text("Simulate Push Notification"),
          onPressed: _pushDemo,
        ),
        SizedBox(height: 12),
        ..._notifs.map((n) => Card(child: Padding(padding: EdgeInsets.all(8), child: Text(n)))).toList()
      ],
    );
  }
}
