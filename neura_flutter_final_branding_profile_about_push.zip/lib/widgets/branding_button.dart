import 'package:flutter/material.dart';

class BrandingButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  BrandingButton({required this.label, required this.onPressed});
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        elevation: 2,
        textStyle: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)
      ),
      child: Text(label),
      onPressed: onPressed,
    );
  }
}
