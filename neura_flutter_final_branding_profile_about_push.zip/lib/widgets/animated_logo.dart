import 'package:flutter/material.dart';
import 'dart:math';

class AnimatedLogo extends StatefulWidget {
  @override
  State<AnimatedLogo> createState() => _AnimatedLogoState();
}

class _AnimatedLogoState extends State<AnimatedLogo> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: Duration(seconds: 2))..repeat();
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (ctx, child) => Transform.rotate(
        angle: _controller.value * 2 * pi,
        child: child,
      ),
      child: Icon(Icons.psychology, color: Colors.indigoAccent, size: 80),
    );
  }
}
