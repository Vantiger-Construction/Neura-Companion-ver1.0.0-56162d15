import 'package:flutter/material.dart';
import '../widgets/push_notification_simulator.dart';

class PushNotificationsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Push Notifications")),
      body: PushNotificationSimulator(),
    );
  }
}
