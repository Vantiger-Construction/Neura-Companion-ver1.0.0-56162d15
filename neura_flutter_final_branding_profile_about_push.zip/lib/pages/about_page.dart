import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("About Neura")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Neura Companion", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text("Your AI-powered mood, productivity, and wellness companion. Neura helps you track, understand, and grow—all in one app.", style: TextStyle(fontSize: 16)),
            SizedBox(height: 16),
            Text("Version 1.0.0", style: TextStyle(color: Colors.grey)),
            SizedBox(height: 16),
            Text("Developed by Team Neura.", style: TextStyle(color: Colors.grey)),
            SizedBox(height: 32),
            ElevatedButton.icon(
              icon: Icon(Icons.contact_mail),
              label: Text("Contact Support"),
              onPressed: () => Navigator.pushNamed(context, '/contact'),
            ),
          ],
        ),
      ),
    );
  }
}
