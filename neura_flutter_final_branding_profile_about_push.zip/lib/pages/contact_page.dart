import 'package:flutter/material.dart';

class ContactPage extends StatelessWidget {
  final _ctrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Contact Neura Team")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _ctrl,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: "How can we help? Type your message here.",
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 12),
            ElevatedButton(
              child: Text("Send"),
              onPressed: () {
                // You'd call your backend or email API here
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Message sent! We'll be in touch.")),
                );
                _ctrl.clear();
              },
            ),
            SizedBox(height: 16),
            Text("Or email us: support@neuracompanion.com", style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
