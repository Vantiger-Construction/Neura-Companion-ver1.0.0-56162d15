import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  final _displayCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    // Example user info stub, wire up with your user provider/api.
    final user = {"username": "tigger", "role": "Admin", "org": "Neura HQ", "email": "tigger@neuracompanion.com"};

    return Scaffold(
      appBar: AppBar(title: Text("Profile Settings")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            CircleAvatar(radius: 40, child: Icon(Icons.person, size: 48)),
            SizedBox(height: 12),
            Text("Username: ${user["username"]}", style: TextStyle(fontWeight: FontWeight.bold)),
            Text("Role: ${user["role"]}"),
            Text("Org: ${user["org"]}"),
            SizedBox(height: 16),
            TextField(
              controller: _displayCtrl..text = user["username"]!,
              decoration: InputDecoration(labelText: "Display Name"),
            ),
            TextField(
              controller: _emailCtrl..text = user["email"]!,
              decoration: InputDecoration(labelText: "Email"),
            ),
            TextField(
              controller: _passCtrl,
              obscureText: true,
              decoration: InputDecoration(labelText: "New Password"),
            ),
            SizedBox(height: 16),
            ElevatedButton(child: Text("Update Profile"), onPressed: () {
              // Call update API (stub)
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Profile updated (demo).")));
            }),
            SizedBox(height: 24),
            OutlinedButton.icon(
              icon: Icon(Icons.logout),
              label: Text("Sign Out"),
              onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
            )
          ],
        ),
      ),
    );
  }
}
