
# Neura Companion Multiverse Bundle

Includes:
- Flutter Android build: NeuraAICompanion.apk
- Unity VR project files
- Shared logic modules (Dart)
- Error healing, emotion tracking, and Dimensional Sync Logic

Install instructions in each subfolder.
