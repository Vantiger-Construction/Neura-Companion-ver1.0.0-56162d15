@echo off
setlocal enabledelayedexpansion

:: Define paths
set DEST=Z:\Neura_Companion_Complete
set TEMPZIP=%DEST%\temp_zip
set LOG=%DEST%\merge_log.txt
set ERRLOG=%DEST%\merge_errors.log
mkdir "%TEMPZIP%" 2>nul
echo. > "%LOG%"
echo. > "%ERRLOG%"

echo 📦 Scanning for ZIPs across Z:\ ...

:: Loop through all zip files recursively
for /R "Z:\" %%Z in (*.zip) do (
    echo ------------------------------------------------------ >> "%LOG%"
    echo 🔍 Processing: %%Z >> "%LOG%"
    powershell -nologo -noprofile -command "Expand-Archive -Force '%%Z' '%TEMPZIP%'" 2>>"%ERRLOG%"

    for /R "%TEMPZIP%" %%F in (*) do (
        set "FNAME=%%~nxF"
        set "EXT=%%~xF"
        set "FILE=%%F"
        set "SUCCESS=0"

        set "TARGET="

        if /I "!EXT!"==".dart" set "TARGET=%DEST%\lib"
        if /I "!FNAME!"=="main.dart" set "TARGET=%DEST%"
        if /I "!FNAME!"=="pubspec.yaml" set "TARGET=%DEST%"
        if /I "!EXT!"==".mp3" set "TARGET=%DEST%\assets\audio"
        if /I "!EXT!"==".wav" set "TARGET=%DEST%\assets\audio"
        if /I "!EXT!"==".ogg" set "TARGET=%DEST%\assets\audio"
        if /I "!EXT!"==".png" set "TARGET=%DEST%\assets\images"
        if /I "!EXT!"==".jpg" set "TARGET=%DEST%\assets\images"
        if /I "!EXT!"==".svg" set "TARGET=%DEST%\assets\images"
        if /I "!EXT!"==".gif" set "TARGET=%DEST%\assets\images"
        if /I "!EXT!"==".json" set "TARGET=%DEST%\assets\data"
        if /I "!EXT!"==".txt" set "TARGET=%DEST%\assets\text"
        if /I "!EXT!"==".csv" set "TARGET=%DEST%\assets\text"
        if /I "!EXT!"==".lottie" set "TARGET=%DEST%\assets\animations"
        if /I "!EXT!"==".riv" set "TARGET=%DEST%\assets\animations"
        if /I "!EXT!"==".anim" set "TARGET=%DEST%\assets\animations"
        if /I "!EXT!"==".bat" set "TARGET=%DEST%\scripts"
        if /I "!EXT!"==".cmd" set "TARGET=%DEST%\scripts"
        if /I "!EXT!"==".sh" set "TARGET=%DEST%\scripts"
        if /I "!EXT!"==".onnx" set "TARGET=%DEST%\ai\models"
        if /I "!EXT!"==".tflite" set "TARGET=%DEST%\ai\models"
        if /I "!EXT!"==".bin" set "TARGET=%DEST%\ai\models"
        if /I "!FNAME!"=="README.md" set "TARGET=%DEST%\docs"
        if /I "!FNAME!"=="LICENSE" set "TARGET=%DEST%\docs"

        if defined TARGET (
            mkdir "!TARGET!" >nul 2>&1
            move /Y "%%F" "!TARGET!" >> "%LOG%" 2>>"%ERRLOG%"
        ) else (
            echo ⚠️ Skipped (no target): %%F >> "%ERRLOG%"
            del /F /Q "%%F" >> "%LOG%" 2>>"%ERRLOG%"
        )
    )

    timeout /t 1 >nul
    rmdir /S /Q "%TEMPZIP%" >nul
    mkdir "%TEMPZIP%" >nul
)

echo ✅ Merge complete. All unmatched files deleted.
pause
