# Privacy Policy – Neura Companion

Effective Date: July 31, 2025

Neura Companion, a product of VanTiger Construction, respects your privacy.
We do not sell, share, or misuse personal data.

All information (mood, journaling, preferences, etc.) is securely stored and used solely to improve user experience.

Contact: neuracompanion@gmail.com