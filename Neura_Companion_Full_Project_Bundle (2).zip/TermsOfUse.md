# Terms of Use – Neura Companion

By using Neura Companion, a product of VanTiger Construction, you agree to:

- Not reverse engineer or resell any part of the application
- Acknowledge that Neura Companion is protected under IP law
- Understand features may evolve and data is used solely for internal enhancement

Violators will face legal recourse under US copyright and software protection law.