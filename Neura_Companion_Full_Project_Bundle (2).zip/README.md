# Neura Companion – Live Preview Demo

This is the **private full build** of Neura Companion™, including:
- All core modules and logic
- AI personality, emotion sync, dream engine, voice system
- Lottie animation handling and VR/AR prep
- GitHub Actions for APK and site deployment
- Full legal ownership, trademark, and licensing

## 🔍 Live Preview Instructions

The `investor_site/` folder contains your static preview website.
To view locally or deploy:

1. Run a simple local server from the root of this project:
   ```bash
   python3 -m http.server 8080
   ```
2. Open `http://localhost:8080/investor_site` in your browser.

---

© 2025 VanTiger Construction. All rights reserved.