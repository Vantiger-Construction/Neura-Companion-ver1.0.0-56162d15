# Neura Companion™

An emotionally intelligent AI assistant developed by **VanTiger Construction**.

Features:
- Animated AI companion with real-time emotion sync
- Smart rituals, mental wellness tools, dream engine, and mood logging
- Cross-platform: Android, Web, VR, and Desktop
- Proprietary logic modules, personality engine, and voice system

© 2025 VanTiger Construction. All rights reserved.