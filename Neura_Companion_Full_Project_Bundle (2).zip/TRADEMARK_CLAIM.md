# TRADEMARK AND OWNERSHIP CLAIM

Neura Companion™ is an original product owned by VanTiger Construction.

This archive contains all proprietary source files, branding, code, and logic modules.
This bundle serves as legal proof of creation and ownership.

Any attempt to copy, clone, reverse-engineer, or redistribute is strictly prohibited.