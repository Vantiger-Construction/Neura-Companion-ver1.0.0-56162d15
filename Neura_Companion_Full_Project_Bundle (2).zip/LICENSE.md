Copyright © 2025 VanTiger Construction. All rights reserved.

This software and all associated assets (code, designs, AI modules, graphics, audio, brand, etc.)
are the intellectual property of VanTiger Construction.

Unauthorized reproduction, modification, distribution, or commercial use is strictly prohibited.

"Neura Companion" is a trademark of VanTiger Construction.