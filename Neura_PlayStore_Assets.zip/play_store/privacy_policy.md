# Privacy Policy

Neura Companion does not collect personal data unless explicitly authorized.

- We do not sell or share your data.
- Optional Firebase sync is encrypted and secured.
- Offline mode ensures complete privacy.
- Voice and journal data stay on your device unless exported.

Contact: support@neuracompanion.ai
