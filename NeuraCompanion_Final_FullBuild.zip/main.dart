
import 'package:flutter/material.dart';
import 'mood_forecast_anim.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      home: Scaffold(
        appBar: AppBar(title: Text('Neura Companion')),
        body: MoodForecastAnimation(mood: 'happy'),
      ),
    );
  }
}
