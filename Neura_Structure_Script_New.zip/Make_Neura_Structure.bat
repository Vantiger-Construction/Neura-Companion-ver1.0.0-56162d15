@echo off
REM Scaffold Neura Companion structure

mkdir asset_kit\Figma
mkdir asset_kit\SVG
mkdir asset_kit\Rive
mkdir asset_kit\PNGs
mkdir asset_kit\Flutter
mkdir asset_kit\.github\workflows

REM Build APK
flutter build apk --release

REM Copy APK
copy build\app\outputs\flutter-apk\app-release.apk asset_kit\

echo Done!
