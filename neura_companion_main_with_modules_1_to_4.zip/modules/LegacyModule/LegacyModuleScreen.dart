
import 'package:flutter/material.dart';
import 'dart:io';

class LegacyModuleScreen extends StatefulWidget {
  @override
  _LegacyModuleScreenState createState() => _LegacyModuleScreenState();
}

class _LegacyModuleScreenState extends State<LegacyModuleScreen> {
  bool legacyModeEnabled = false;
  final TextEditingController legacyTextController = TextEditingController();
  String legacyMessage = '';

  void saveLegacyCapsule() async {
    final capsule = legacyTextController.text;
    final file = File('assets/legacy/last_capsule.legacy');
    await file.writeAsString(capsule);
    setState(() {
      legacyMessage = capsule;
    });
    // Simulated Neura feedback
    print("Memory capsule recorded. I'll keep it safe.");
  }

  Future<void> loadLegacyCapsule() async {
    final file = File('assets/legacy/last_capsule.legacy');
    if (await file.exists()) {
      final contents = await file.readAsString();
      setState(() {
        legacyMessage = contents;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    loadLegacyCapsule();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Legacy Capsule')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            SwitchListTile(
              title: Text("Enable Legacy Mode"),
              value: legacyModeEnabled,
              onChanged: (bool value) {
                setState(() {
                  legacyModeEnabled = value;
                });
              },
            ),
            TextField(
              controller: legacyTextController,
              decoration: InputDecoration(hintText: "Write your legacy message..."),
              maxLines: 5,
            ),
            ElevatedButton(
              onPressed: saveLegacyCapsule,
              child: Text("Record Capsule"),
            ),
            if (legacyMessage.isNotEmpty)
              Padding(
                padding: EdgeInsets.only(top: 20),
                child: Text("Last Saved Capsule:
$legacyMessage"),
              ),
          ],
        ),
      ),
    );
  }
}
