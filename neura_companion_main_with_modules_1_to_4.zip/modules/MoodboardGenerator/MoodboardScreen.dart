
import 'package:flutter/material.dart';

class MoodboardEntry {
  final String mood;
  final String assetPath;
  final DateTime timestamp;

  MoodboardEntry({required this.mood, required this.assetPath, required this.timestamp});
}

class MoodboardScreen extends StatefulWidget {
  @override
  _MoodboardScreenState createState() => _MoodboardScreenState();
}

class _MoodboardScreenState extends State<MoodboardScreen> {
  final List<String> moods = ['Joy', 'Sadness', 'Calm', 'Anger', 'Inspired'];
  final Map<String, String> moodToAsset = {
    'Joy': 'assets/moodboard_samples/joy.png',
    'Sadness': 'assets/moodboard_samples/sadness.png',
    'Calm': 'assets/moodboard_samples/calm.png',
    'Anger': 'assets/moodboard_samples/anger.png',
    'Inspired': 'assets/moodboard_samples/inspired.png',
  };

  String selectedMood = 'Joy';
  late String previewImage;
  List<MoodboardEntry> moodboard = [];

  @override
  void initState() {
    super.initState();
    previewImage = moodToAsset[selectedMood]!;
  }

  void saveMoodboardToLocal() {
    setState(() {
      moodboard.add(MoodboardEntry(
        mood: selectedMood,
        assetPath: previewImage,
        timestamp: DateTime.now(),
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Moodboard Generator')),
      body: Column(
        children: [
          DropdownButton<String>(
            value: selectedMood,
            items: moods.map((String mood) {
              return DropdownMenuItem(value: mood, child: Text(mood));
            }).toList(),
            onChanged: (String? newMood) {
              setState(() {
                selectedMood = newMood!;
                previewImage = moodToAsset[newMood]!;
              });
            },
          ),
          Image.asset(previewImage, height: 200),
          ElevatedButton(
            onPressed: saveMoodboardToLocal,
            child: Text("Save to Moodboard"),
          ),
          Expanded(
            child: GridView.builder(
              itemCount: moodboard.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
              itemBuilder: (context, index) {
                final entry = moodboard[index];
                return Column(
                  children: [
                    Image.asset(entry.assetPath, height: 100),
                    Text(entry.mood),
                  ],
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
