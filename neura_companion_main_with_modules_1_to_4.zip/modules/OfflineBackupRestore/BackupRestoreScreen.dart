
import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:convert';
import 'package:file_picker/file_picker.dart';

class BackupRestoreScreen extends StatefulWidget {
  @override
  _BackupRestoreScreenState createState() => _BackupRestoreScreenState();
}

class _BackupRestoreScreenState extends State<BackupRestoreScreen> {
  List<Map<String, dynamic>> moodLog = [];
  List<Map<String, dynamic>> journalEntries = [];
  List<Map<String, dynamic>> ritualHistory = [];

  Future<void> exportNeuraBackup() async {
    final data = {
      'moods': moodLog,
      'journal': journalEntries,
      'rituals': ritualHistory,
    };
    final jsonStr = jsonEncode(data);
    final file = File('neura_backup_${DateTime.now().millisecondsSinceEpoch}.neura');
    await file.writeAsString(jsonStr);
    print("Backup exported.");
  }

  Future<void> importNeuraBackup(File file, {bool overwrite = false}) async {
    final contents = await file.readAsString();
    final Map<String, dynamic> data = jsonDecode(contents);

    setState(() {
      if (overwrite) {
        moodLog = List<Map<String, dynamic>>.from(data['moods']);
        journalEntries = List<Map<String, dynamic>>.from(data['journal']);
        ritualHistory = List<Map<String, dynamic>>.from(data['rituals']);
      } else {
        moodLog.addAll(List<Map<String, dynamic>>.from(data['moods']));
        journalEntries.addAll(List<Map<String, dynamic>>.from(data['journal']));
        ritualHistory.addAll(List<Map<String, dynamic>>.from(data['rituals']));
      }
    });

    print("Backup imported.");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Offline Backup & Restore')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: exportNeuraBackup,
              child: Text("Export All (.neura)"),
            ),
            ElevatedButton(
              onPressed: () async {
                final FilePickerResult? result = await FilePicker.platform.pickFiles();
                if (result != null) {
                  final file = File(result.files.single.path!);
                  await importNeuraBackup(file, overwrite: true);
                }
              },
              child: Text("Import Backup (.neura)"),
            ),
          ],
        ),
      ),
    );
  }
}
