Neura Companion - Chain-of-Thought Reasoning Patch

Features:
- Neura explains thoughts step-by-step (toggle in settings).
- Animated bubble for each step.
- Works in planning, mood, therapy, and calendar modules.

Steps:
1. Copy folders into your project.
2. Add COT toggle in settings.
3. Replace AI calls with NeuraAIClient().askWithCOT().
4. Add 'assets/cot_neuron_glow.json' to pubspec.yaml.
