import 'package:http/http.dart' as http;

class NeuraAIClient {
  Future<List<String>> askWithCOT(String prompt) async {
    final cotPrompt = "Let's think step by step. $prompt";
    final response = await http.post(
      Uri.parse('https://api.openai.com/v1/chat/completions'),
      headers: {
        'Authorization': 'Bearer <YOUR_API_KEY>',
        'Content-Type': 'application/json',
      },
      body: '''
        {
          "model": "gpt-4o",
          "messages": [{"role": "user", "content": "$cotPrompt"}]
        }
      ''',
    );
    final String body = response.body;
    final steps = RegExp(r'Step \d+: (.*?)(?=Step \d+:|\Z)', dotAll: true)
        .allMatches(body)
        .map((m) => m.group(1)?.trim() ?? '')
        .toList();
    return steps.isEmpty ? body.split('\n').where((s) => s.trim().isNotEmpty).toList() : steps;
  }
}
