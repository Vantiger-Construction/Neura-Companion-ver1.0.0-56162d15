import 'package:flutter/material.dart';

class NeuraCOTBubble extends StatelessWidget {
  final List<String> steps;
  const NeuraCOTBubble({required this.steps, super.key});
  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Neura is thinking…', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ...steps.asMap().entries.map((entry) => AnimatedOpacity(
              opacity: 1,
              duration: Duration(milliseconds: 300 + entry.key * 100),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.bubble_chart, size: 18, color: Colors.indigo),
                    const SizedBox(width: 6),
                    Expanded(child: Text(entry.value, style: TextStyle(fontSize: 16))),
                  ],
                ),
              ),
            )),
          ],
        ),
      ),
    );
  }
}
