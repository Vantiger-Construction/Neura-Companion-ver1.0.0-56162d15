import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AppState extends ChangeNotifier {
  bool showCOT = true;
  void setShowCOT(bool value) {
    showCOT = value;
    notifyListeners();
  }
}

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      title: const Text('Show Neura’s Thought Process'),
      value: context.watch<AppState>().showCOT,
      onChanged: (val) => context.read<AppState>().setShowCOT(val),
    );
  }
}
