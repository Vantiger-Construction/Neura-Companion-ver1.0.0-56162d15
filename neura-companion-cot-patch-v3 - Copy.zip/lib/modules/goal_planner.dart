import '../ai/neura_ai_client.dart';
import '../widgets/neura_cot_bubble.dart';
import 'package:flutter/material.dart';

class GoalPlanner extends StatefulWidget {
  @override
  _GoalPlannerState createState() => _GoalPlannerState();
}

class _GoalPlannerState extends State<GoalPlanner> {
  List<String> _cotSteps = [];
  bool _loading = false;

  void planGoal(String goal) async {
    setState(() { _loading = true; });
    final steps = await NeuraAIClient().askWithCOT(goal);
    setState(() {
      _cotSteps = steps;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextField(onSubmitted: planGoal),
        if (_loading) CircularProgressIndicator(),
        if (_cotSteps.isNotEmpty) NeuraCOTBubble(steps: _cotSteps),
      ],
    );
  }
}
