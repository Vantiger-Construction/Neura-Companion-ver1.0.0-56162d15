
import 'package:flutter/material.dart';

class RouteLoaderWrapper extends StatefulWidget {
  final Widget page;
  final String voiceMessage;

  const RouteLoaderWrapper({super.key, required this.page, required this.voiceMessage});

  @override
  State<RouteLoaderWrapper> createState() => _RouteLoaderWrapperState();
}

class _RouteLoaderWrapperState extends State<RouteLoaderWrapper> {
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 800), () {
      setState(() => _loading = false);
    });

    // Simulate voice intro playback (stub)
    print("🔊 Neura says: '${widget.voiceMessage}'");
  }

  @override
  Widget build(BuildContext context) {
    return _loading
        ? const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          )
        : widget.page;
  }
}
