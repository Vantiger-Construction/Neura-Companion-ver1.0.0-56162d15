from ariadne import QueryType, make_executable_schema
from ariadne.asgi import GraphQL
from sqlmodel import select
from src.db import get_session
from src.models import Resource, Subscription, DeliveryRecord

type_defs = """
    type Resource { id: Int, name: String }
    type Subscription { id: Int, url: String, eventType: String }
    type DeliveryRecord { id: Int, timestamp: String, statusCode: Int }
    type Query {
        resources(cursor: Int = 0, limit: Int = 50): [Resource]
        subscriptions: [Subscription]
        history(subscriptionId: Int!): [DeliveryRecord]
    }
"""

query = QueryType()

@query.field("resources")
def resolve_resources(_, info, cursor=0, limit=50):
    session = next(get_session())
    stmt = select(Resource).offset(cursor).limit(limit)
    results = session.exec(stmt).all()
    session.close()
    return [r.dict() for r in results]

@query.field("subscriptions")
def resolve_subscriptions(_, info):
    session = next(get_session())
    results = session.exec(select(Subscription)).all()
    session.close()
    return [s.dict() for s in results]

@query.field("history")
def resolve_history(_, info, subscriptionId):
    session = next(get_session())
    stmt = select(DeliveryRecord).where(DeliveryRecord.subscription_id == subscriptionId)
    results = session.exec(stmt).all()
    session.close()
    return [d.dict() for d in results]

schema = make_executable_schema(type_defs, query)
app = GraphQL(schema, debug=False)
