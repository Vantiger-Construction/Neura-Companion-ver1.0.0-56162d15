import React, { useEffect, useState } from "react";
import axios from "axios";

function App() {
  const [subs, setSubs] = useState([]);
  const [history, setHistory] = useState({});
  useEffect(() => {
    axios.get("/v1/webhooks/subscriptions", { headers: { Authorization: "Bearer <token>" } })
      .then(res => setSubs(res.data));
  }, []);
  const loadHistory = (id) => {
    axios.get(`/v1/webhooks/subscriptions/${id}/history`, { headers: { Authorization: "Bearer <token>" } })
      .then(res => setHistory(prev => ({ ...prev, [id]: res.data })));
  };
  const retry = (id) => {
    axios.post(`/v1/webhooks/dispatch-bulk`, { events: [] }, { headers: { Authorization: "Bearer <token>" } });
    alert("Retry queued");
  };
  const deleteSub = (id) => {
    axios.delete(`/v1/webhooks/subscriptions/${id}`, { headers: { Authorization: "Bearer <token>" } })
      .then(() => setSubs(subs.filter(s => s.id !== id)));
  };
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Webhooks Dashboard</h1>
      {subs.map(s => (
        <div key={s.id} className="border p-2 m-2">
          <div>ID: {s.id}</div>
          <div>URL: {s.url}</div>
          <div>Event: {s.eventType}</div>
          <button onClick={() => loadHistory(s.id)}>Load History</button>
          <button onClick={() => retry(s.id)} className="ml-2">Retry Dispatch</button>
          <button onClick={() => deleteSub(s.id)} className="ml-2">Delete</button>
          {history[s.id] && (
            <ul className="mt-2">
              {history[s.id].map((h, idx) => (
                <li key={idx}>{h.timestamp} - {h.statusCode}</li>
              ))}
            </ul>
          )}
        </div>
      ))}
    </div>
  );
}

export default App;
