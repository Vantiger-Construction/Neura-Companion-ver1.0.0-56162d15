module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}", "../webhooks-dashboard/src/**/*.{js,jsx}"],
  theme: { extend: {} },
  plugins: [],
};
