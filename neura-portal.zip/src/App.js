import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Dashboard from './components/NeuraDashboardWrapper';
import MoodTracker from './components/MoodTracker';
import Journal from './components/Journal';
import Exercise from './components/Exercise';
import BackgroundWrapper from './components/BackgroundWrapper';

function App() {
  return (
    <BrowserRouter>
      <BackgroundWrapper>
        <nav className="p-4 bg-gray-800 text-white flex space-x-4">
          <Link to="/">Dashboard</Link>
          <Link to="/mood">Mood Tracker</Link>
          <Link to="/journal">Journal</Link>
          <Link to="/exercise">Exercise</Link>
        </nav>
        <div className="p-4">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/mood" element={<MoodTracker />} />
            <Route path="/journal" element={<Journal />} />
            <Route path="/exercise" element={<Exercise />} />
          </Routes>
        </div>
      </BackgroundWrapper>
    </BrowserRouter>
  );
}

export default App;
