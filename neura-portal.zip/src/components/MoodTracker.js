import React from 'react';

export default function MoodTracker() {
  return (
    <div className="bg-white bg-opacity-80 rounded p-4">
      <h2 className="text-2xl font-bold">Mood Tracker</h2>
      {/* TODO: Implement mood tracking UI */}
    </div>
  );
}
