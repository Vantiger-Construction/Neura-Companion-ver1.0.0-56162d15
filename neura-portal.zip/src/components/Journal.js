import React from 'react';

export default function Journal() {
  return (
    <div className="bg-white bg-opacity-80 rounded p-4">
      <h2 className="text-2xl font-bold">Journal</h2>
      {/* TODO: Implement journaling UI */}
    </div>
  );
}
