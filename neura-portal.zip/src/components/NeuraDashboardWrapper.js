import React from 'react';
import WebhooksDashboard from 'webhooks-dashboard/dist/App';

export default function NeuraDashboardWrapper() {
  const token = localStorage.getItem('neura_token') || '';
  return (
    <div className="bg-white bg-opacity-80 rounded p-4">
      <WebhooksDashboard token={token} />
    </div>
  );
}
