import React from 'react';
import { useLocation } from 'react-router-dom';

const backgrounds = {
  '/': 'url("/assets/dashboard-bg.jpg")',
  '/mood': 'url("/assets/mood-bg.jpg")',
  '/journal': 'url("/assets/journal-bg.jpg")',
  '/exercise': 'url("/assets/exercise-bg.jpg")',
};

export default function BackgroundWrapper({ children }) {
  const location = useLocation();
  const bgImage = backgrounds[location.pathname] || backgrounds['/'];
  return (
    <div style={{
      backgroundImage: bgImage,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      minHeight: '100vh'
    }}>
      {children}
    </div>
  );
}
