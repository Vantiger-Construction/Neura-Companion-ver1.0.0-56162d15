import React from 'react';

export default function Exercise() {
  return (
    <div className="bg-white bg-opacity-80 rounded p-4">
      <h2 className="text-2xl font-bold">Guided Exercise</h2>
      {/* TODO: Implement guided exercise UI */}
    </div>
  );
}
