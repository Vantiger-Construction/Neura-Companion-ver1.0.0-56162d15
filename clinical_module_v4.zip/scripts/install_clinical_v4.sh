#!/usr/bin/env bash
set -e
echo "Installing Clinical Module v4..."
flutter pub get
