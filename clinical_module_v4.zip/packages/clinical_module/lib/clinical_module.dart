library clinical_module;

import 'dart:convert';
import 'dart:developer';

import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:http/http.dart';
import 'package:fhir/r4.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Clinical features for medical professionals.
class ClinicalModule {
  final InAppPurchasePlatform iap;
  final Client httpClient;
  final FlutterSecureStorage storage;
  final String fhirServerUrl;
  final String apiKey;
  final String subscriptionId;

  ProductDetails? _product;
  bool _subscribed = false;

  ClinicalModule({
    required this.iap,
    required this.httpClient,
    required this.storage,
    required this.fhirServerUrl,
    required this.apiKey,
    this.subscriptionId = 'clinical_module_pro',
  });

  /// Initialize, verify subscription.
  Future<void> init() async {
    if (!await iap.isAvailable()) {
      throw Exception('IAP unavailable');
    }
    final response = await iap.queryProductDetails({subscriptionId});
    if (response.productDetails.isEmpty) throw Exception('Product not found');
    _product = response.productDetails.first;
    final past = await iap.queryPastPurchases();
    for (var p in past.pastPurchases) {
      if (p.productID == subscriptionId && p.status == PurchaseStatus.purchased) {
        _subscribed = true;
      }
    }
    if (!_subscribed) throw Exception('Subscription required');
  }

  /// Trigger purchase flow.
  Future<void> purchase() async {
    if (_product == null) throw Exception('Product not loaded');
    final param = PurchaseParam(productDetails: _product!);
    await iap.buyNonConsumable(purchaseParam: param);
  }

  void _ensureSubscription() {
    if (!_subscribed) throw Exception('Not subscribed');
  }

  /// Fetch Patient via FHIR, with caching.
  Future<Patient> fetchPatient(String patientId) async {
    _ensureSubscription();
    final key = 'patient_\$patientId';
    try {
      final res = await httpClient.get(
        Uri.parse('\$fhirServerUrl/Patient/\$patientId'),
        headers: {'Authorization': 'Bearer \$apiKey', 'Accept': 'application/fhir+json'},
      );
      if (res.statusCode == 200) {
        await storage.write(key: key, value: res.body);
        return Patient.fromJson(jsonDecode(res.body));
      }
      throw Exception('Fetch failed: \${res.statusCode}');
    } catch (e) {
      developer.log('Fetch error: \$e, trying cache', name: 'ClinicalModule');
      final cached = await storage.read(key: key);
      if (cached != null) {
        return Patient.fromJson(jsonDecode(cached));
      }
      rethrow;
    }
  }

  /// Send Observation, with offline queue.
  Future<void> sendObservation(Observation obs) async {
    _ensureSubscription();
    final queueKey = 'obs_queue';
    try {
      final res = await httpClient.post(
        Uri.parse('\$fhirServerUrl/Observation'),
        headers: {'Authorization': 'Bearer \$apiKey', 'Content-Type': 'application/fhir+json'},
        body: jsonEncode(obs.toJson()),
      );
      if (!(res.statusCode >= 200 && res.statusCode < 300)) {
        throw Exception('Send failed: \${res.statusCode}');
      }
    } catch (e) {
      developer.log('Send error: \$e, queuing', name: 'ClinicalModule');
      // queue observation
      final queueJson = await storage.read(key: queueKey);
      final List<dynamic> list = queueJson != null ? jsonDecode(queueJson) : [];
      list.add(obs.toJson());
      await storage.write(key: queueKey, value: jsonEncode(list));
    }
  }

  /// Flush queued observations.
  Future<void> flushQueue() async {
    _ensureSubscription();
    final queueKey = 'obs_queue';
    final queueJson = await storage.read(key: queueKey);
    if (queueJson == null) return;
    final List<dynamic> list = jsonDecode(queueJson);
    final remaining = <dynamic>[];
    for (var item in list) {
      try {
        final obs = Observation.fromJson(item);
        await sendObservation(obs); // will re-queue on failure
      } catch (_) {
        remaining.add(item);
      }
    }
    if (remaining.isEmpty) {
      await storage.delete(key: queueKey);
    } else {
      await storage.write(key: queueKey, value: jsonEncode(remaining));
    }
  }

  /// List cached patients.
  Future<List<String>> listCachedPatients() async {
    final all = await storage.readAll();
    return all.keys.where((k) => k.startsWith('patient_')).toList();
  }
}
