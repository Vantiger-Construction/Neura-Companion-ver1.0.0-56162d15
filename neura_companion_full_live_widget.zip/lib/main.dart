
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'neura_voice_reactive_widget.dart';
import 'neura_emotion_state.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => NeuraEmotionState(),
      child: const NeuraApp(),
    ),
  );
}

class NeuraApp extends StatelessWidget {
  const NeuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      theme: ThemeData.dark(),
      home: const NeuraHome(),
    );
  }
}

class NeuraHome extends StatelessWidget {
  const NeuraHome({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SafeArea(
        child: Center(
          child: NeuraVoiceReactiveWidget(),
        ),
      ),
    );
  }
}
