
# Neura Companion - LIVE Assistant (Full Stack)

🧠 Voice Input → Emotion Mapped → Animated Response → Mouth Sync  
🎤 Neura listens, speaks, reacts, and remembers moods.

## To Run:
```
flutter pub get
flutter run
```

Ensure:
- Microphone permissions granted
- TTS works on your device
- Assets folder included
