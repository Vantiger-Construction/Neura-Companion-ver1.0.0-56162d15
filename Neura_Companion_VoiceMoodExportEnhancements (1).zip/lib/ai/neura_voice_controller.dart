
import 'package:path_provider/path_provider.dart';
import '../services/mood/mood_logger_service.dart';
import '../services/mood/mood_export_service.dart';
import '../services/tts/neura_speech_service.dart';
import '../widgets/neura_emotion_animator.dart';

Future<void> handleVoiceIntent(String command) async {
  if (command.contains("export mood") || command.contains("save my moods")) {
    final entries = MoodLoggerService.getMoodHistory();
    final now = DateTime.now();
    final dateStr = "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";
    final dir = await getApplicationDocumentsDirectory();
    final pdfPath = "\${dir.path}/mood_log_\${dateStr}.pdf";

    await MoodExportService.exportToPDF(entries, pdfPath);

    int upbeatCount = entries.where((e) => e["mood"] == "happy" || e["mood"] == "excited").length;
    if (upbeatCount >= 3) {
      NeuraEmotionAnimator.play("happy_wave.json");
      await NeuraSpeechService.speak("I noticed you were more upbeat this week! 🎉 Keep it going!");
    } else {
      NeuraEmotionAnimator.play("default_wave.json");
      await NeuraSpeechService.speak("I’ve exported your mood history as a PDF.");
    }
  }
}


  else if (command.contains("remind me every week") || command.contains("schedule mood export")) {
    scheduleWeeklyMoodReminder();
    NeuraSpeechService.speak("Okay, I'll remind you every week to export your mood history!");
    NeuraEmotionAnimator.play("calendar_confirm.json");
  }
