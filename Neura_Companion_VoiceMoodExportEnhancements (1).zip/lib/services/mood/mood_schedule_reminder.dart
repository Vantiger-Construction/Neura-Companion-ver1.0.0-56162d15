
import 'dart:async';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../ai/neura_voice_controller.dart';
import '../services/mood/mood_logger_service.dart';
import '../services/mood/mood_export_service.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void scheduleWeeklyMoodReminder() async {
  const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
    'weekly_mood_channel',
    'Weekly Mood Reminder',
    channelDescription: 'Reminds the user to export mood log every week',
    importance: Importance.max,
    priority: Priority.high,
  );
  const NotificationDetails platformDetails =
      NotificationDetails(android: androidDetails);

  await flutterLocalNotificationsPlugin.periodicallyShow(
    1,
    '🧠 Mood Reminder',
    'Time to check your mood history and export your report!',
    RepeatInterval.weekly,
    platformDetails,
    androidAllowWhileIdle: true,
  );
}

Future<void> handleVoiceIntent(String command) async {
  if (command.contains("schedule mood export")) {
    scheduleWeeklyMoodReminder();
    await NeuraSpeechService.speak("Got it! I'll remind you each week to export your mood history.");
    NeuraEmotionAnimator.play("calendar_confirm.json");
  }
}
