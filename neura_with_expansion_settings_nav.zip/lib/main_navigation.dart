
import 'package:flutter/material.dart';
import 'screens/settings/expansion_settings_page.dart';

class MainNavigation extends StatelessWidget {
  const MainNavigation({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Neura Companion")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton.icon(
              icon: const Icon(Icons.psychology),
              label: const Text("Expansion Settings"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ExpansionSettingsPage()),
                );
              },
            ),
            const SizedBox(height: 16),
            // Add more modules here...
          ],
        ),
      ),
    );
  }
}
