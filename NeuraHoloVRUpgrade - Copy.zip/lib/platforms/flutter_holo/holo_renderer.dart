class HoloRenderer {
  static void triggerEmotion(String emotion) {
    // Apply glow, shimmer, or animation
    print("🌈 Hologram triggered: $emotion");
    // Hook to animated Lottie or custom shaders here
  }
}