using UnityEngine;

public class VRBridge : MonoBehaviour {
    public Animator NeuraAnimator;

    public void SendEmotionCue(string emotion) {
        if (NeuraAnimator != null) {
            NeuraAnimator.SetTrigger(emotion);
            Debug.Log("🎮 VR Triggered: " + emotion);
        } else {
            Debug.LogError("NeuraAnimator not set!");
        }
    }
}