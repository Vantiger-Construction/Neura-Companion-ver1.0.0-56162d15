
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import 'neura_emotion_state.dart';
import 'neura_emotion_mapper.dart';
import 'neura_animation_engine.dart';
import 'neura_mood_memory.dart';
import 'neura_mouth_sync.dart';
import 'neura_emotion_global.dart';

class NeuraVoiceReactiveWidget extends StatefulWidget {
  const NeuraVoiceReactiveWidget({super.key});

  @override
  State<NeuraVoiceReactiveWidget> createState() => _NeuraVoiceReactiveWidgetState();
}

class _NeuraVoiceReactiveWidgetState extends State<NeuraVoiceReactiveWidget> {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  @override
  void initState() {
    super.initState();
  }

  Future<void> _handleVoiceInput() async {
    bool available = await _speech.initialize();
    if (available) {
      _speech.listen(
        onResult: (result) async {
          final spoken = result.recognizedWords;
          if (spoken.isNotEmpty) {
            final mapped = mapTextToEmotion(spoken);
            context.read<NeuraEmotionState>().update(mapped);
            await MoodMemory.logMood(mapped);
            await _tts.speak(spoken);
          }
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final emotion = context.watch<NeuraEmotionState>().emotion;
    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        NeuraAnimationEngine(emotion: emotion),
        NeuraMouthSync(tts: _tts),
        Positioned(
          bottom: 16,
          child: ElevatedButton.icon(
            onPressed: _handleVoiceInput,
            icon: const Icon(Icons.mic),
            label: const Text("Talk to Neura"),
          ),
        )
      ],
    );
  }
}
