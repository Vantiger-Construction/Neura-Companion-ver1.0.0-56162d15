
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

class NeuraMouthSync extends StatefulWidget {
  final FlutterTts tts;
  const NeuraMouthSync({super.key, required this.tts});

  @override
  State<NeuraMouthSync> createState() => _NeuraMouthSyncState();
}

class _NeuraMouthSyncState extends State<NeuraMouthSync> {
  bool speaking = false;

  @override
  void initState() {
    super.initState();
    widget.tts.setStartHandler(() => setState(() => speaking = true));
    widget.tts.setCompletionHandler(() => setState(() => speaking = false));
    widget.tts.setCancelHandler(() => setState(() => speaking = false));
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 100),
      opacity: speaking ? 1 : 0,
      child: Image.asset('assets/mouth_talk.gif', width: 64, height: 64),
    );
  }
}
