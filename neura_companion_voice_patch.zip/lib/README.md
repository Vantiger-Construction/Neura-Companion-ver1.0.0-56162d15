
# Neura Companion Voice Patch Module

Includes:
- Real-time emotion engine
- Global state using Provider
- Neura speech output + mouth animation
- Drop-in widget: `NeuraVoiceReactiveWidget`
- SharedPreferences mood memory

Add to `pubspec.yaml`:
```
dependencies:
  flutter_tts: ^3.6.3
  speech_to_text: ^5.10.0
  provider: ^6.1.2
  shared_preferences: ^2.2.2
```

Inject `ChangeNotifierProvider<NeuraEmotionState>()` at app root.
