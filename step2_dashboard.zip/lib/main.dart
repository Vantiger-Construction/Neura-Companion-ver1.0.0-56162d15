import 'package:flutter/material.dart';
import 'ui/dashboard_screen.dart';

void main() {
  runApp(NeuraApp());
}

class NeuraApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      debugShowCheckedModeBanner: false,
      home: DashboardScreen(),
    );
  }
}
