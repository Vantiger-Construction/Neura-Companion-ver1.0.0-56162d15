# Neura Companion - Step 2: Dashboard Screen

This build adds a fully functional DashboardScreen to the project.

## Files Added

- **lib/main.dart** → Boots into DashboardScreen  
- **lib/ui/dashboard_screen.dart** → Implements NeuraFaceAnimator, emotion label, Mood Check-In, and Dream Replay launcher

## Running the App

1. `flutter pub get`  
2. `flutter run`

On launch, you’ll see the Dashboard screen with Neura’s animated face, current emotion, buttons, and stats summary.
