// analytics_model.dart - TODO: implement
