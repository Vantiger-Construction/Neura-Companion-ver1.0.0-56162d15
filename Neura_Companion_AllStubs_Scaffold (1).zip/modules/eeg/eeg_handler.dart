// eeg_handler.dart - TODO: implement
