describe('Full User Flow', () => {
  it('Onboards, subscribes, receives real-time events, and navigates modules', () => {
    // Set token in localStorage
    cy.visit('/');
    cy.window().then(win => {
      win.localStorage.setItem('neura_token', 'dummy-token');
    });

    // Onboarding
    cy.visit('/onboarding');
    cy.contains('Welcome to Neura!');
    cy.get('button').contains('Subscribe').each(btn => {
      cy.wrap(btn).click();
    });

    // Dashboard
    cy.visit('/');
    cy.contains('Webhooks Dashboard');
    // Real-time events page
    cy.visit('/realtime');
    cy.contains('Real-Time Events');

    // Mood Tracker
    cy.visit('/mood');
    cy.contains('Mood Tracker');

    // Journal
    cy.visit('/journal');
    cy.contains('Journal');

    // Exercise
    cy.visit('/exercise');
    cy.contains('Guided Exercise');
  });
});
