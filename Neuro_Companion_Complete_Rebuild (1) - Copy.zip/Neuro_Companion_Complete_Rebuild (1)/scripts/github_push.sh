#!/bin/bash
git init
git remote add origin https://github.com/yourusername/neuro-companion.git
git add .
git commit -m "Initial commit of complete Neuro Companion app"
git push -u origin master