#!/bin/bash
flutter pub get
dart run build_runner build
echo "Firebase initialized!"