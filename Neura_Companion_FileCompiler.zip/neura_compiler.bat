@echo off
setlocal EnableDelayedExpansion

:: Set working directories
set SOURCE_DRIVE=Z:\
set TARGET_DIR=Z:\Neura-Companion\
set TEMP_DIR=%TARGET_DIR%_temp\
set LOG_DIR=%TARGET_DIR%logs\

:: Create directories
mkdir "%TARGET_DIR%" >nul 2>&1
mkdir "%TEMP_DIR%" >nul 2>&1
mkdir "%LOG_DIR%" >nul 2>&1

echo === Unzipping Files ===
for /R "%SOURCE_DRIVE%" %%F in (*.zip) do (
    echo Extracting: %%F
    powershell -Command "Expand-Archive -Force '%%F' '%TEMP_DIR%'"
)

echo === Copying & Organizing Files ===

:: Use robocopy to organize into correct folders (deduplicated by date/size)
robocopy "%TEMP_DIR%" "%TARGET_DIR%assets\animations" *.json /S /XO /LOG:"%LOG_DIR%animations.log"
robocopy "%TEMP_DIR%" "%TARGET_DIR%assets\images" *.png *.jpg *.jpeg *.svg /S /XO /LOG:"%LOG_DIR%images.log"
robocopy "%TEMP_DIR%" "%TARGET_DIR%assets\sounds" *.mp3 *.wav /S /XO /LOG:"%LOG_DIR%sounds.log"
robocopy "%TEMP_DIR%" "%TARGET_DIR%lib\core" *core*.dart /S /XO /LOG:"%LOG_DIR%core.log"
robocopy "%TEMP_DIR%" "%TARGET_DIR%lib\modules" *module*.dart /S /XO /LOG:"%LOG_DIR%modules.log"
robocopy "%TEMP_DIR%" "%TARGET_DIR%lib\ui" *ui*.dart *.widget /S /XO /LOG:"%LOG_DIR%ui.log"
robocopy "%TEMP_DIR%" "%TARGET_DIR%lib" main.dart /S /XO /LOG:"%LOG_DIR%main.log"
robocopy "%TEMP_DIR%" "%TARGET_DIR%" pubspec.yaml README.md /S /XO /LOG:"%LOG_DIR%rootfiles.log"

echo === Cleaning Up ===
rd /s /q "%TEMP_DIR%"

echo === Neura Companion File Merge Complete ===
pause
