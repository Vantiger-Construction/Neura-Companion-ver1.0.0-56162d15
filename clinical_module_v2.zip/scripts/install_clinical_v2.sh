#!/usr/bin/env bash
set -e
echo "Installing Clinical Module v2..."
flutter pub get
echo "✔ Clinical Module registered."
