import 'package:clinical_module/clinical_module.dart';

/// Entry point to initialize clinical features.
class ClinicalUpgrades {
  static Future<void> init() async {
    await ClinicalModule.init();
  }

  static Future<void> purchase() async {
    await ClinicalModule.purchase();
  }

  static Future<void> dispose() async {
    await ClinicalModule.dispose();
  }
}
