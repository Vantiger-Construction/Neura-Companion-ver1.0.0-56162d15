# memory_graph

## Installation
Add to your root `pubspec.yaml`:
```yaml
memory_graph:
  path: ./packages/memory_graph
```

## Usage
```dart
import 'package:memory_graph/memory_graph.dart';

await MemoryGraph.init();
```
