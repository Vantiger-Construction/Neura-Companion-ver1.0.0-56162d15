# mood_map

## Installation
Add to your root `pubspec.yaml`:
```yaml
mood_map:
  path: ./packages/mood_map
```

## Usage
```dart
import 'package:mood_map/mood_map.dart';

await MoodMap.init();
```
