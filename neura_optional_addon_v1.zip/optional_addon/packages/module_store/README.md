# module_store

## Installation
Add to your root `pubspec.yaml`:
```yaml
module_store:
  path: ./packages/module_store
```

## Usage
```dart
import 'package:module_store/module_store.dart';

await ModuleStore.init();
```
