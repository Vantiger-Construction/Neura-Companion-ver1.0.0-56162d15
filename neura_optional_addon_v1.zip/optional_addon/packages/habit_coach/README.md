# habit_coach

## Installation
Add to your root `pubspec.yaml`:
```yaml
habit_coach:
  path: ./packages/habit_coach
```

## Usage
```dart
import 'package:habit_coach/habit_coach.dart';

await HabitCoach.init();
```
