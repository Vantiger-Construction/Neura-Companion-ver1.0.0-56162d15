import 'package:community_feed/community_feed.dart';
import 'package:gamification/gamification.dart';
import 'package:habit_coach/habit_coach.dart';
import 'package:journaling/journaling.dart';
import 'package:dreamscape_visualizer/dreamscape_visualizer.dart';
import 'package:mood_map/mood_map.dart';
import 'package:wearable_integration/wearable_integration.dart';
import 'package:voice_assistant/voice_assistant.dart';
import 'package:offline_sync/offline_sync.dart';
import 'package:memory_graph/memory_graph.dart';
import 'package:module_store/module_store.dart';
import 'package:localization/localization.dart';

class OptionalModules {
  /// Initialize all optional modules
  static Future<void> initAll() async {
    await CommunityFeed.init();
    await Gamification.init();
    await HabitCoach.init();
    await Journaling.init();
    await DreamscapeVisualizer.init();
    await MoodMap.init();
    await WearableIntegration.init();
    await VoiceAssistant.init();
    await OfflineSync.init();
    await MemoryGraph.init();
    await ModuleStore.init();
    await Localization.init();
  }
}
