
Neura Companion – Press Kit

Contents:
- Emails: Launch, Vision, Upgrade
- Branding: Logos, Icon
- Screenshots: Placeholder
- PDF 1-pager: Overview of Neura's features
