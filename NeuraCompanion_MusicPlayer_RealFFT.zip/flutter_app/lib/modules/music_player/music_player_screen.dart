
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_fft/flutter_fft.dart';
import 'music_visualizer.dart';

class MusicPlayerScreen extends StatefulWidget {
  @override
  _MusicPlayerScreenState createState() => _MusicPlayerScreenState();
}

class _MusicPlayerScreenState extends State<MusicPlayerScreen> {
  final player = AudioPlayer();
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool isPlaying = false;
  double volume = 1.0;
  bool isLooping = false;
  bool isListening = false;
  String voiceCommand = "";
  String? favoriteTrack;

  final Map<String, String> moodPlaylists = {
    'Calm': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    'Focus': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    'Energy': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
  };

  String currentMood = 'Calm';

  
import 'package:flutter_fft/flutter_fft.dart';

FlutterFft flutterFft = FlutterFft();
double detectedFrequency = 0.0;

@override
void initState() {
  super.initState();
  loadFavorites();
  loadPlaylist(currentMood);
  initFFT();
}

Future<void> initFFT() async {
  await flutterFft.startRecorder();
  flutterFft.onRecorderStateChanged.listen((event) {
    if (event.containsKey("frequency")) {
      setState(() {
        detectedFrequency = event["frequency"] ?? 0.0;
        updateInstrumentType(detectedFrequency);
      });
    }
  });
}

void updateInstrumentType(double freq) {
  if (freq < 250) {
    currentInstrument = InstrumentType.bass;
  } else if (freq < 1000) {
    currentInstrument = InstrumentType.vocals;
  } else if (freq < 3000) {
    currentInstrument = InstrumentType.melody;
  } else {
    currentInstrument = InstrumentType.drums;
  }
}


  Future<void> loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => favoriteTrack = prefs.getString('favorite'));
  }

  Future<void> saveFavorite(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('favorite', url);
    setState(() => favoriteTrack = url);
  }

  void loadPlaylist(String mood) async {
    await player.setUrl(moodPlaylists[mood]!);
    player.setLoopMode(isLooping ? LoopMode.one : LoopMode.off);
    player.setVolume(volume);
    setState(() {});
  }

  void playLocalFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (result != null && result.files.single.path != null) {
      await player.setFilePath(result.files.single.path!);
      player.play();
      setState(() => isPlaying = true);
    }
  }

  void togglePlayPause() {
    if (isPlaying) {
      player.pause();
    } else {
      player.play();
    }
    setState(() {
      isPlaying = !isPlaying;
    });
  }

  void toggleLoop() {
    isLooping = !isLooping;
    player.setLoopMode(isLooping ? LoopMode.one : LoopMode.off);
    setState(() {});
  }

  void changeVolume(double value) {
    volume = value;
    player.setVolume(volume);
    setState(() {});
  }

  void changeMood(String mood) {
    currentMood = mood;
    loadPlaylist(mood);
  }

  void listenForCommand() async {
    if (!isListening) {
      bool available = await _speech.initialize(
        onStatus: (val) => print('STATUS: $val'),
        onError: (val) => print('ERROR: $val'),
      );
      if (available) {
        setState(() => isListening = true);
        _speech.listen(onResult: (val) {
          voiceCommand = val.recognizedWords.toLowerCase();
          handleVoiceCommand(voiceCommand);
        });
      }
    } else {
      _speech.stop();
      setState(() => isListening = false);
    }
  }

  void handleVoiceCommand(String command) {
    if (command.contains('pause')) togglePlayPause();
    else if (command.contains('play calm')) changeMood('Calm');
    else if (command.contains('play focus')) changeMood('Focus');
    else if (command.contains('play energy')) changeMood('Energy');
    else if (command.contains('play favorite') && favoriteTrack != null) {
      player.setUrl(favoriteTrack!);
      player.play();
      setState(() => isPlaying = true);
    }
    else if (command.contains('play')) togglePlayPause();
    else if (command.contains('loop')) toggleLoop();
    else if (command.contains('volume up')) changeVolume((volume + 0.1).clamp(0.0, 1.0));
    else if (command.contains('volume down')) changeVolume((volume - 0.1).clamp(0.0, 1.0));
    else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Neura didn’t understand.")));
    }
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  Widget buildNeuraReaction() {
    return Column(
      children: [
        Text("🎵 Neura is vibing with your $currentMood mood!", style: TextStyle(fontSize: 16)),
        Icon(Icons.face_retouching_natural, size: 80),
      ],
    );
  }

  Widget buildVoiceControl() {
    return Column(children: [
      ElevatedButton.icon(
        onPressed: listenForCommand,
        icon: Icon(isListening ? Icons.mic : Icons.mic_none),
        label: Text(isListening ? 'Listening...' : 'Voice Command'),
      ),
      if (voiceCommand.isNotEmpty) Text("🗣 "$voiceCommand""),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Neura Mood Music")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              buildNeuraReaction(),
              SizedBox(height: 16),
              buildVoiceControl(),
                          MusicVisualizer(isActive: isPlaying),
            DropdownButton<String>(
                value: currentMood,
                items: moodPlaylists.keys
                    .map((mood) => DropdownMenuItem(value: mood, child: Text("🎧 $mood")))
                    .toList(),
                onChanged: changeMood,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(onPressed: togglePlayPause, child: Text(isPlaying ? 'Pause' : 'Play')),
                  SizedBox(width: 10),
                  ElevatedButton(onPressed: toggleLoop, child: Text(isLooping ? 'Looping' : 'Loop')),
                ],
              ),
              SizedBox(height: 20),
              Text("Volume"),
              Slider(value: volume, onChanged: changeVolume),
              ElevatedButton(onPressed: playLocalFile, child: Text("📂 Pick Local File")),
              if (favoriteTrack != null) Text("⭐ Favorite Saved", style: TextStyle(color: Colors.amber)),
              ElevatedButton(onPressed: () => saveFavorite(player.audioSource?.sequence.first.tag.toString() ?? ""), child: Text("Save Current as Favorite"))
            ],
          ),
        ),
      ),
    );
  }
}
