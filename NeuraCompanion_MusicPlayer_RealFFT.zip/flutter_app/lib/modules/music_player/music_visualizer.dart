
import 'package:flutter/material.dart';
import 'dart:math';

class MusicVisualizer extends StatefulWidget {
  final bool isActive;

  const MusicVisualizer({super.key, required this.isActive});

  @override
  _MusicVisualizerState createState() => _MusicVisualizerState();
}

class _MusicVisualizerState extends State<MusicVisualizer>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  List<double> barHeights = List.generate(20, (_) => 5.0);
  Random rng = Random();

  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 300))
          ..addListener(() {
            if (widget.isActive) {
              setState(() {
                barHeights = List.generate(20, (_) => rng.nextDouble() * 60 + 10);
              });
            }
          })
          ..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: widget.isActive ? 1.0 : 0.0,
      duration: Duration(milliseconds: 300),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: barHeights.map((height) {
          return Container(
            width: 5,
            height: height,
            margin: EdgeInsets.symmetric(horizontal: 2),
            decoration: BoxDecoration(
              color: Colors.blueAccent,
              borderRadius: BorderRadius.circular(4),
            ),
          );
        }).toList(),
      ),
    );
  }
}
