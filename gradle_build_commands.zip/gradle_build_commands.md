# Option A: Flutter CLI (requires Flutter SDK on PATH)

# 0. Verify environment
flutter doctor

# 1. Clean previous builds
flutter clean

# 2. Install dependencies and fetch packages
flutter pub get

# 3. Analyze and test
flutter analyze
flutter test

# 4. Build the APK (release)
flutter build apk --release

# 5. (Optional) Build an Android App Bundle for Play Store
flutter build appbundle --release

# 6. Install on connected device/emulator
flutter install


# Option B: Gradle wrapper (no Flutter CLI needed)

# 0. Verify JDK and Android SDK are configured
java -version
sdkmanager --list

# 1. Clean previous builds
cd android
./gradlew clean

# 2. Assemble debug or release APKs using the wrapper
./gradlew assembleDebug    # produces app\build\outputs\apk\debug\app-debug.apk
./gradlew assembleRelease  # produces app\build\outputs\apk\release\app-release.apk

# 3. (Optional) Ensure signing configs in android/app/build.gradle
#    Then rebuild for a signed release:
./gradlew assembleRelease

# 4. Install on device via adb
adb install -r app\build\outputs\apk\debug\app-debug.apk
# or
adb install -r app\build\outputs\apk\release\app-release.apk

# 5. (Optional) Inspect APK size and contents
# For quick size check:
#   du -h app/build/outputs/apk/release/app-release.apk
# For full file listing:
#   unzip -l app/build/outputs/apk/release/app-release.apk
