# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added
- Observability (logging, metrics, health checks)
- Deployment manifests (Docker, Kubernetes)
- Security (refresh tokens, RBAC, rate limits, CORS)
- API Experience (Swagger UI, GraphQL, Postman, dashboard)
- Bulk & Batch operations
- SDKs (Python, TS, RN, Flutter, Go, Java, PHP)
- AI-driven error handling
- Monitoring dashboards & alert rules
- Audit logging & GDPR anonymization
- Real-time WebSocket support
- Onboarding flow
- E2E tests (Cypress, Locust, JMeter)
- Compliance & production hardening

## [1.0.0] - 2025-07-30
### Added
- Initial stable release of Neura API with full feature set.
