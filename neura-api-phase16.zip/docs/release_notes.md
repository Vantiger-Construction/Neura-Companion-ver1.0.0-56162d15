# Release Management

- Use semantic version tags: `v1.0.0`, `v1.1.0`, etc.
- Docker images are tagged as:
  - `latest`
  - matching semantic version (e.g. `v1.0.0`)
- GitHub Actions will automatically create a release from CHANGELOG.md
