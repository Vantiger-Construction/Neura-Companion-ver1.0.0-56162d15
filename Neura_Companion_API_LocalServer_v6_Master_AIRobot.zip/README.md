# Neura Companion Local API Server

## Features
- Persona memory updates
- Voice viseme/emotion input
- Journal & dream entry endpoints
- Emotion tracking and syncing
- Ready for local deployment

## Running the server
```bash
uvicorn main:app --reload
```

## Batch Run (Windows)
Double-click `run_local_server.bat`