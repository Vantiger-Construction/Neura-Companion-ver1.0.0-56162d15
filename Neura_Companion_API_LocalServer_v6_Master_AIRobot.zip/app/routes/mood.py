from fastapi import APIRouter

router = APIRouter()

@router.get("/weekly")
def get_weekly_mood():
    # Stub data for graphing moods
    return {
        "trend": [
            {"day": "Mon", "mood": "tired"},
            {"day": "Tue", "mood": "calm"},
            {"day": "Wed", "mood": "energized"},
            {"day": "Thu", "mood": "anxious"},
            {"day": "Fri", "mood": "joyful"}
        ]
    }

@router.get("/summary")
def get_mood_summary():
    return {
        "most_common": "calm",
        "spikes": {"happy": 2, "anxious": 1},
        "avg_intensity": 6.5
    }