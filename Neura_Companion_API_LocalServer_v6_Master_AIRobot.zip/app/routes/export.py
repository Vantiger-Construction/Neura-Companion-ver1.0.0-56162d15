from fastapi import APIRouter
import json
import csv
from fastapi.responses import JSONResponse, StreamingResponse
from io import StringIO

router = APIRouter()

@router.get("/json")
def export_json():
    data = {
        "journal": [{"entry": "Sample", "timestamp": "now"}],
        "emotion": [{"mood": "happy", "intensity": 7}]
    }
    return JSONResponse(content=data)

@router.get("/csv")
def export_csv():
    csv_data = StringIO()
    writer = csv.writer(csv_data)
    writer.writerow(["type", "content", "timestamp"])
    writer.writerow(["journal", "Sample", "now"])
    writer.writerow(["emotion", "happy", "now"])
    csv_data.seek(0)
    return StreamingResponse(csv_data, media_type="text/csv")