from fastapi import APIRouter, Body

router = APIRouter()

@router.post("/push")
def sync_push(data: dict = Body(...)):
    return {"status": "Data synced", "payload": data}

@router.get("/pull")
def sync_pull():
    return {"payload": {}}  # stub