from fastapi import APIRouter, Body

router = APIRouter()

@router.post("/entry")
def new_journal_entry(entry: dict = Body(...)):
    return {"status": "Journal entry saved", "entry": entry}

@router.get("/history")
def journal_history():
    return {"entries": []}  # stub