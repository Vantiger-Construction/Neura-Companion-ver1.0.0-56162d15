from fastapi import APIRouter, Body
from datetime import datetime

router = APIRouter()

@router.post("/launch")
def launch_ritual(data: dict = Body(...)):
    return {
        "status": "Ritual launched",
        "ritual_id": data.get("ritual_id"),
        "timestamp": datetime.utcnow()
    }

@router.post("/track")
def track_ritual(data: dict = Body(...)):
    return {
        "status": "Ritual tracking updated",
        "ritual_id": data.get("ritual_id"),
        "progress": data.get("progress", 0)
    }