from fastapi import APIRouter, Body

router = APIRouter()

@router.get("/state")
def get_persona_state():
    return {"persona": "curious", "mood": "happy"}

@router.post("/update")
def update_persona(data: dict = Body(...)):
    return {"status": "Persona updated", "traits": data}