from fastapi import APIRouter, Body

router = APIRouter()

@router.post("/send")
def send_webhook(data: dict = Body(...)):
    return {
        "status": "Webhook triggered",
        "target": data.get("target"),
        "event": data.get("event")
    }