from fastapi import APIRouter, Body

router = APIRouter()

@router.post("/trigger")
def trigger_lottie(data: dict = Body(...)):
    return {
        "status": "Lottie animation triggered",
        "animation": data.get("viseme"),
        "emotion": data.get("emotion")
    }