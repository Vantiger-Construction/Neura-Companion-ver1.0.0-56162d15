from fastapi import APIRouter, Body

router = APIRouter()

@router.post("/personalized")
def personalized_reflection(data: dict = Body(...)):
    name = data.get("user_name", "friend")
    mood = data.get("mood", "neutral")
    return {
        "reflection": f"Hey {name}, based on your mood '{mood}', remember: you're stronger than your struggles."
    }