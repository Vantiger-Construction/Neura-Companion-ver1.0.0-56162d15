from fastapi import APIRouter, Body, Depends
from sqlmodel import Session, select
from app.models.models import DreamEntry
from app.utils.db import get_session
from datetime import datetime

router = APIRouter()

@router.post("/entry")
def new_dream_entry(dream: dict = Body(...), session: Session = Depends(get_session)):
    entry = DreamEntry(
        user_id=dream["user_id"],
        title=dream.get("title", "Untitled Dream"),
        content=dream["content"],
        timestamp=datetime.utcnow()
    )
    session.add(entry)
    session.commit()
    session.refresh(entry)
    return {"status": "Dream saved", "dream_id": entry.id}

@router.get("/calendar")
def get_dream_calendar(session: Session = Depends(get_session)):
    return session.exec(select(DreamEntry)).all()