from fastapi import APIRouter, Body

router = APIRouter()

@router.post("/mood-scan")
def scan_mood(data: dict = Body(...)):
    return {
        "status": "MirrorMode scan received",
        "detected_emotion": data.get("emotion"),
        "source": data.get("source", "camera")
    }