from fastapi import APIRouter, Body

router = APIRouter()

@router.post("/report")
def report_emotion(emotion: dict = Body(...)):
    return {"status": "Emotion reported", "emotion": emotion}

@router.get("/history")
def emotion_history():
    return {"history": []}  # stub