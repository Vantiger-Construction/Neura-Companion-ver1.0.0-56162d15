from fastapi import APIRouter, Body

router = APIRouter()

@router.post("/input")
def handle_voice_input(data: dict = Body(...)):
    return {"status": "Voice input received", "data": data}

@router.post("/viseme")
def viseme_sync(data: dict = Body(...)):
    return {
        "status": "Viseme sync received",
        "phoneme": data.get("phoneme"),
        "emotion": data.get("emotion")
    }