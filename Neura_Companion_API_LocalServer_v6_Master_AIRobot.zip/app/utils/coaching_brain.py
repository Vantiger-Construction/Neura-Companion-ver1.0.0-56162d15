# coaching_brain.py
def generate_feedback(mood):
    responses = {
        "happy": "That's wonderful! Keep doing what brings you joy.",
        "tired": "Make sure to rest. Your energy matters.",
        "anxious": "Try a grounding exercise. Breathe deep, you’ve got this.",
        "sad": "It’s okay to feel low. Talk to someone you trust.",
        "angry": "Channel that energy into movement or creativity.",
    }
    return responses.get(mood, "I'm here for you, no matter how you're feeling.")