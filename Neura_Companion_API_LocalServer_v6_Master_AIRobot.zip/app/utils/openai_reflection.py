# openai_reflection.py
import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

def personalized_reflection(name, mood):
    prompt = f"Generate a kind, motivational reflection for {name} who feels {mood} today."
    completion = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=80
    )
    return completion.choices[0].text.strip()