# webhook_handler.py
import requests

def send_discord_message(message, webhook_url):
    data = {"content": message}
    response = requests.post(webhook_url, json=data)
    return response.status_code == 204