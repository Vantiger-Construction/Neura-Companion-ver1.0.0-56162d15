# smart_light.py (example for Philips Hue)
import requests

def set_light_color(bridge_ip, username, light_id, hue_value):
    url = f"http://{bridge_ip}/api/{username}/lights/{light_id}/state"
    payload = {"on": True, "hue": hue_value, "sat": 254, "bri": 254}
    response = requests.put(url, json=payload)
    return response.json()