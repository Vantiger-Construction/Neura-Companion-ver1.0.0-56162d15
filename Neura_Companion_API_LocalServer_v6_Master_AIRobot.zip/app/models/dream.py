from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import datetime

class DreamEntry(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: str
    title: str
    content: str
    timestamp: datetime