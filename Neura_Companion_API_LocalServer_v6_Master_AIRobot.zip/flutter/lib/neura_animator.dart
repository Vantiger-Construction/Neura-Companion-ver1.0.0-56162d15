// lib/neura_animator.dart
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class NeuraAnimator extends StatefulWidget {
  final String emotion;
  final String viseme;
  const NeuraAnimator({required this.emotion, required this.viseme});

  @override
  _NeuraAnimatorState createState() => _NeuraAnimatorState();
}

class _NeuraAnimatorState extends State<NeuraAnimator> {
  String animation = "idle";

  @override
  void initState() {
    super.initState();
    triggerAnimation(widget.emotion, widget.viseme);
  }

  void triggerAnimation(String emotion, String viseme) async {
    final response = await http.post(
      Uri.parse("http://localhost:8000/api/lottie/trigger"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"emotion": emotion, "viseme": viseme}),
    );
    final result = jsonDecode(response.body);
    setState(() {
      animation = "${result['emotion']}_${result['animation']}";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Lottie.asset("assets/lottie/\$animation.json");
  }
}