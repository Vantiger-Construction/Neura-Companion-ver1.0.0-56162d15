# archive_export.py
import json
from datetime import datetime

def export_archive():
    data = {
        "mood": [{"mood": "happy", "timestamp": str(datetime.now())}],
        "journal": [{"entry": "Feeling good", "timestamp": str(datetime.now())}],
        "rituals": [{"ritual": "calm_breathing", "timestamp": str(datetime.now())}]
    }
    with open("export.json", "w") as f:
        json.dump(data, f, indent=2)

    print("📦 Archive saved to export.json")