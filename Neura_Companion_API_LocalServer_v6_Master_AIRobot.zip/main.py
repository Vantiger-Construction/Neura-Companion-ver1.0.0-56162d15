from fastapi import FastAPI
from sqlmodel import SQLModel
from app.routes import voice, persona, journal, emotion, sync, dream, mirror, ritual, mood, reflection, lottie, export, webhook, openai
from app.utils.db import engine

app = FastAPI(title="Neura Companion API")

@app.on_event("startup")
def on_startup():
    SQLModel.metadata.create_all(engine)

app.include_router(persona.router, prefix="/api/ai/persona")
app.include_router(voice.router, prefix="/api/voice")
app.include_router(journal.router, prefix="/api/journal")
app.include_router(emotion.router, prefix="/api/emotion")
app.include_router(sync.router, prefix="/api/sync")
app.include_router(dream.router, prefix="/api/dream")
app.include_router(mirror.router, prefix="/api/mirror")
app.include_router(ritual.router, prefix="/api/ritual")
app.include_router(mood.router, prefix="/api/mood")
app.include_router(reflection.router, prefix="/api/reflection")
app.include_router(lottie.router, prefix="/api/lottie")
app.include_router(export.router, prefix="/api/export")
app.include_router(webhook.router, prefix="/api/webhook")
app.include_router(openai.router, prefix="/api/openai")

@app.get("/")
def root():
    return {"status": "Neura API: Full Feature Set Active"}