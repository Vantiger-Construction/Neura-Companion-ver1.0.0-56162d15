# Neura Companion Ultimate API

## Features

- SQLModel + SQLite persistent database
- JWT user/org/role auth
- Mood CRUD, mood streaming via WebSocket
- Event log & webhook delivery/registration
- Rate limiting (slowapi)
- Admin tools (user/org/abuse)
- Automated tests (pytest)
- GitHub Actions CI
- AI Copilot endpoint (stub)
- Swagger & Redoc docs

## Quickstart

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Log in at `/api/v1/auth/token`:
- username: tigger
- password: neura_is_best

Run tests:
```bash
pytest
```
