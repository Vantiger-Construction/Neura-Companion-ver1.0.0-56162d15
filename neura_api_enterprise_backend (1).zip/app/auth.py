from fastapi import APIRouter, HTTPException, status, Depends
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from sqlmodel import SQLModel, Field, select, Session
import jwt, datetime, os
from app.db import get_session

SECRET = os.getenv("SECRET", "super_secret")
router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

class UserAccount(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True)
    username: str = Field(index=True, unique=True)
    password: str
    role: str = "user"
    org: str = "default"

class Token(BaseModel):
    access_token: str
    token_type: str

class User(BaseModel):
    username: str
    role: str
    org: str

def authenticate_user(username: str, password: str, session: Session):
    statement = select(UserAccount).where(UserAccount.username == username)
    user = session.exec(statement).first()
    if user and user.password == password:
        return user
    return None

def create_access_token(data: dict):
    to_encode = data.copy()
    to_encode.update({"exp": datetime.datetime.utcnow() + datetime.timedelta(hours=12)})
    return jwt.encode(to_encode, SECRET, algorithm="HS256")

@router.post("/token", response_model=Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(), session: Session = Depends(get_session)):
    user = authenticate_user(form_data.username, form_data.password, session)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials.",
        )
    token = create_access_token({"sub": user.username, "role": user.role, "org": user.org})
    return {"access_token": token, "token_type": "bearer"}

def get_current_user(token: str = Depends(oauth2_scheme), session: Session = Depends(get_session)):
    try:
        payload = jwt.decode(token, SECRET, algorithms=["HS256"])
        username = payload.get("sub")
        role = payload.get("role")
        org = payload.get("org")
        if username is None or role is None:
            raise HTTPException(status_code=401, detail="Invalid token.")
        return User(username=username, role=role, org=org)
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired.")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Token invalid.")

def require_admin(user: User = Depends(get_current_user)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required.")
    return user
