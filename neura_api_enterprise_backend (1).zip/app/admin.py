from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import select, Session
from app.auth import require_admin, UserAccount
from app.mood import MoodEntry
from app.db import get_session

router = APIRouter()

@router.get("/users")
def list_users(admin=Depends(require_admin), session: Session = Depends(get_session)):
    statement = select(UserAccount)
    return session.exec(statement).all()

@router.get("/moods")
def dump_all_moods(admin=Depends(require_admin), session: Session = Depends(get_session)):
    statement = select(MoodEntry)
    return session.exec(statement).all()
