from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter
from slowapi.util import get_remote_address
from app import auth, mood, events, admin, copilot
from app.db import init_db

app = FastAPI(
    title="Neura Companion API",
    description="AI Companion platform. Real-time, persistent, event-driven.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    init_db()
    # Create demo admin if not exists
    from sqlmodel import Session, select
    from app.auth import UserAccount
    from app.db import engine
    with Session(engine) as session:
        user = session.exec(select(UserAccount).where(UserAccount.username == "tigger")).first()
        if not user:
            session.add(UserAccount(username="tigger", password="neura_is_best", role="admin"))
            session.commit()

# Routers
app.include_router(auth.router, prefix="/api/v1/auth", tags=["auth"])
app.include_router(mood.router, prefix="/api/v1/mood", tags=["mood"])
app.include_router(events.router, prefix="/api/v1/events", tags=["events"])
app.include_router(admin.router, prefix="/api/v1/admin", tags=["admin"])
app.include_router(copilot.router, prefix="/api/v1/copilot", tags=["ai"])

# Rate limiting
@app.middleware("http")
async def add_rate_limit(request, call_next):
    response = await limiter(request, call_next)
    return response
