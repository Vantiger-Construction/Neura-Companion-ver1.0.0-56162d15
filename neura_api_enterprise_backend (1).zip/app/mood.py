from fastapi import APIRouter, HTTPException, Depends, Path, WebSocket, WebSocketDisconnect
from sqlmodel import Field, SQLModel, select, Session
from pydantic import BaseModel
from typing import List, Optional
from app.auth import get_current_user, User
from app.db import get_session
import datetime
from collections import defaultdict
import asyncio

router = APIRouter()
active_connections = defaultdict(list)

class MoodEntry(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True)
    username: str
    mood: str
    note: Optional[str] = None
    timestamp: datetime.datetime = Field(default_factory=datetime.datetime.utcnow)

class MoodSubmit(BaseModel):
    mood: str
    note: Optional[str] = None

class MoodEdit(BaseModel):
    mood: Optional[str] = None
    note: Optional[str] = None

async def notify_user(username, data):
    for ws in list(active_connections.get(username, [])):
        try:
            await ws.send_json(data)
        except Exception:
            pass

@router.post("/", response_model=MoodEntry)
def submit_mood(
    mood: MoodSubmit,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session)
):
    entry = MoodEntry(
        username=user.username,
        mood=mood.mood,
        note=mood.note,
    )
    session.add(entry)
    session.commit()
    session.refresh(entry)
    asyncio.create_task(notify_user(user.username, {"type": "new", "mood": entry.dict()}))
    return entry

@router.get("/", response_model=List[MoodEntry])
def get_mood_history(
    limit: int = 20,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session)
):
    statement = select(MoodEntry).where(MoodEntry.username == user.username).order_by(MoodEntry.timestamp.desc()).limit(limit)
    return session.exec(statement).all()

@router.get("/latest", response_model=MoodEntry)
def get_latest_mood(user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    statement = select(MoodEntry).where(MoodEntry.username == user.username).order_by(MoodEntry.timestamp.desc())
    result = session.exec(statement).first()
    if not result:
        raise HTTPException(status_code=404, detail="No mood recorded yet.")
    return result

@router.put("/{mood_id}", response_model=MoodEntry)
def edit_mood(
    mood_id: int = Path(...),
    edit: MoodEdit = None,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session)
):
    entry = session.get(MoodEntry, mood_id)
    if not entry or entry.username != user.username:
        raise HTTPException(status_code=404, detail="Mood not found.")
    if edit.mood:
        entry.mood = edit.mood
    if edit.note is not None:
        entry.note = edit.note
    session.add(entry)
    session.commit()
    session.refresh(entry)
    asyncio.create_task(notify_user(user.username, {"type": "edit", "mood": entry.dict()}))
    return entry

@router.delete("/{mood_id}", response_model=MoodEntry)
def delete_mood(
    mood_id: int = Path(...),
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session)
):
    entry = session.get(MoodEntry, mood_id)
    if not entry or entry.username != user.username:
        raise HTTPException(status_code=404, detail="Mood not found.")
    session.delete(entry)
    session.commit()
    asyncio.create_task(notify_user(user.username, {"type": "delete", "id": mood_id}))
    return entry

@router.websocket("/ws")
async def mood_ws(websocket: WebSocket):
    token = websocket.query_params.get("token") or websocket.headers.get("Authorization", "").replace("Bearer ", "")
    session = next(get_session())
    try:
        user = get_current_user(token, session)
    except Exception:
        await websocket.close(code=4001)
        return
    username = user.username
    await websocket.accept()
    active_connections[username].append(websocket)
    try:
        statement = select(MoodEntry).where(MoodEntry.username == username).order_by(MoodEntry.timestamp.desc()).limit(20)
        moods = session.exec(statement).all()
        await websocket.send_json({"type": "history", "moods": [m.dict() for m in moods]})
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        if websocket in active_connections[username]:
            active_connections[username].remove(websocket)
