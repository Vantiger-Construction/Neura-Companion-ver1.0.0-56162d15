# Neuro Companion

AI-powered wellness & productivity companion built with Flutter.

## Getting Started

- Install Flutter SDK
- Run `flutter pub get`
- Launch with `flutter run`
