import 'package:flutter/material.dart';
import 'ui/home/home_screen.dart';
// import other screens...

class Routes {
  static const home = '/';
  static const ritual = '/ritual';
  static const goals = '/goals';
  static const mood = '/mood';

  static final all = <String, WidgetBuilder>{
    home: (_) => const HomeScreen(),
    // ritual: (_) => const RitualScreen(),
    // goals: (_) => const GoalsScreen(),
    // mood: (_) => const MoodScreen(),
  };
}
