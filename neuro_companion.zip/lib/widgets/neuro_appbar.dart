import 'package:flutter/material.dart';

class NeuroAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  const NeuroAppBar({required this.title, super.key});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Text(title),
      centerTitle: true,
      elevation: 0,
      actions: [
        IconButton(icon: const Icon(Icons.settings), onPressed: () {/* TODO */}),
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
