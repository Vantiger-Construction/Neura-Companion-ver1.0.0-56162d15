import 'package:flutter/material.dart';
import '../../widgets/neuro_appbar.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: NeuroAppBar(title: 'Neuro Companion'),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _FeatureTile(icon: Icons.self_improvement, label: 'Daily Ritual', route: '/ritual'),
            _FeatureTile(icon: Icons.flag, label: 'Goal Tracker', route: '/goals'),
            _FeatureTile(icon: Icons.sentiment_satisfied, label: 'Mood Analytics', route: '/mood'),
          ],
        ),
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String route;

  const _FeatureTile({
    required this.icon,
    required this.label,
    required this.route,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, size: 32),
      title: Text(label, style: const TextStyle(fontSize: 18)),
      onTap: () => Navigator.pushNamed(context, route),
    );
  }
}
