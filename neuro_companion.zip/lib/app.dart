import 'package:flutter/material.dart';
import 'routes.dart';

class NeuroCompanionApp extends StatelessWidget {
  const NeuroCompanionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neuro Companion',
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.tealAccent,
        scaffoldBackgroundColor: Colors.black,
      ),
      initialRoute: Routes.home,
      routes: Routes.all,
    );
  }
}
