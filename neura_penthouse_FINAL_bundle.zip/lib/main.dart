
import 'package:flutter/material.dart';
import 'pages/neura_penthouse_animated.dart';

void main() => runApp(const NeuraApp());

class NeuraApp extends StatelessWidget {
  const NeuraApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Neura Companion Penthouse',
      theme: ThemeData(
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSwatch().copyWith(
          primary: Colors.indigo,
          secondary: Colors.blueAccent,
        ),
        scaffoldBackgroundColor: Colors.white,
      ),
      home: NeuraPenthouseAnimatedPage(),
    );
  }
}
