
Neura Penthouse Animated UI Installed!

- All assets in /assets (swap your own art anytime)
- pubspec.yaml updated (see 'flutter assets:' section)
- lib/main.dart launches the Penthouse UI
- All code in /lib/pages and /lib/widgets
- Run 'flutter pub get' then 'flutter run'
