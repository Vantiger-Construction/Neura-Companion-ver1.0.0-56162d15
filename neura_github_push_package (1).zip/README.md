
# Neura Companion

**Neura Companion** is a cross-platform emotional AI assistant that adapts to your moods, helps manage your goals, supports mental health, and includes a fully animated personality.

## Features
- 🎨 Mood-Driven UI with Forecast Animations
- 🔊 Real-Time Voice & Emotion Sync
- 🌍 WebGL VR Room Navigation (Unity)
- 💻 Native Desktop Launchers (Windows, Linux/macOS)
- 📈 Mood History Logging + CSV/PDF Export
- 🧠 Local-first Design (No Firebase Required)

## Installation

### 🔧 Windows
1. Unzip `neura_windows_installer`
2. Run `Launch_Neura_Companion.bat`

### 🐧 Linux/macOS
1. Unzip `neura_desktop_launcher`
2. Run:
```bash
chmod +x NeuraCompanion.desktop
./NeuraCompanion.desktop
```

### 🌐 WebGL (Unity VR)
1. Export your Unity project to WebGL.
2. Place your exported `Build/` folder beside the included `index.html`
3. Open `index.html` in your browser

---

### 📦 Full Bundle
All files are included in the `neura_all_in_one_bundle.zip`.

## License
© 2025 Neura Companion by VanTiger Construction. All rights reserved.

