#!/bin/bash
echo "Neura Companion Installer"
chmod +x NeuraCompanion.desktop
./NeuraCompanion.desktop
