Add-ons in this pack
--------------------
- flutter_ui/pubspec.yaml pinned for Flutter 3.22
- android/AndroidManifest.patch.xml with permissions
- android/build.gradle + gradle-wrapper.properties + app.build.gradle (baseline)
- flutter_ui/analysis_options.yaml strong lints
- .vscode/launch.json + tasks.json for one-click dev
- setup_all.ps1 / setup_all.sh to spin up backend + Flutter in one command

How to merge
------------
- Replace or merge your pubspec.yaml with flutter_ui/pubspec.yaml
- Apply AndroidManifest.patch.xml changes to your android/app/src/main/AndroidManifest.xml
- If you have Gradle mismatch errors, align AGP 8.3.1, Kotlin 1.9.22, Gradle 8.6
- Run: Windows → .\neura_starter\smoke_test.bat  |  macOS/Linux → bash neura_starter/smoke_test.sh
