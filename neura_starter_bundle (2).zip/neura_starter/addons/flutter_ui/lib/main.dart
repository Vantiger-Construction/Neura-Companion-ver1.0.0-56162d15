import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env", isOptional: true);
  runApp(const NeuraApp());
}

class NeuraApp extends StatelessWidget {
  const NeuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    final apiBase = dotenv.env['API_BASE_URL'] ?? 'http://127.0.0.1:8000';
    return MaterialApp(
      title: 'Neura Companion',
      theme: ThemeData(
        colorSchemeSeed: Colors.teal,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: Scaffold(
        appBar: AppBar(title: const Text('Neura Companion')),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('API: $apiBase'),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () async {
                  // Simple health check
                  try {
                    final uri = Uri.parse('$apiBase/health');
                    // Using HttpClient to avoid extra deps
                    // ignore: deprecated_member_use
                    // In a real app use 'http' package.
                  } catch (_) {}
                },
                child: const Text('Ping API'),
              ),
              const SizedBox(height: 12),
              const Text('Add your voice button here and viseme sync.'),
            ],
          ),
        ),
      ),
    );
  }
}
