Param(
  [string]$BackendDir = "neura_companion\backend",
  [string]$FlutterDir = "neura_companion\flutter_ui"
)

Write-Host "[Setup] Ensuring assets..."
bash neura_starter/tools/ensure_assets.sh

Write-Host "[Setup] Python venv + deps..."
Push-Location $BackendDir
if (-not (Test-Path ".venv")) {
  python -m venv .venv
}
.\.venv\Scripts\activate
pip install --upgrade pip
if (Test-Path "requirements.txt") {
  pip install -r requirements.txt
} else {
  pip install fastapi "uvicorn[standard]" pydantic python-dotenv soundfile numpy
}
Start-Process -NoNewWindow cmd "/c uvicorn main:app --host 127.0.0.1 --port 8000 --reload"
Pop-Location

Write-Host "[Setup] Flutter pub get + run..."
Push-Location $FlutterDir
flutter pub get
flutter run -d windows
Pop-Location

Write-Host "[Setup] Done."
