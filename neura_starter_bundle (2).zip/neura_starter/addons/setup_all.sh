#!/usr/bin/env bash
set -euo pipefail

BACKEND_DIR="neura_companion/backend"
FLUTTER_DIR="neura_companion/flutter_ui"

bash neura_starter/tools/ensure_assets.sh

pushd "$BACKEND_DIR" >/dev/null
python3 -m venv .venv || true
source .venv/bin/activate
pip install --upgrade pip
if [[ -f requirements.txt ]]; then
  pip install -r requirements.txt
else
  pip install fastapi 'uvicorn[standard]' pydantic python-dotenv soundfile numpy
fi
uvicorn main:app --host 127.0.0.1 --port 8000 --reload &
API_PID=$!
popd >/dev/null

pushd "$FLUTTER_DIR" >/dev/null
flutter pub get
DEVICE=""
if flutter devices | grep -qi "macos"; then DEVICE="macos"; elif flutter devices | grep -qi "linux"; then DEVICE="linux"; else DEVICE="chrome"; fi
flutter run -d "$DEVICE"
popd >/dev/null

kill $API_PID || true
