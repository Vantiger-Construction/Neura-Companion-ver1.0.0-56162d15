#!/bin/bash
echo "🚀 Deploying Neura Companion to GitHub Pages..."
git init
git checkout -b gh-pages
git add .
git commit -m "Deploy Neura Companion to GitHub Pages"
git remote add origin https://github.com/Vantiger1/neura-companion.git
git push -f origin gh-pages