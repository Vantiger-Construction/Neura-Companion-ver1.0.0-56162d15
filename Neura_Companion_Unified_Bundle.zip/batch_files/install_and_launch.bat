@echo off
echo 🚀 Launching Neura Companion Unified Installer...
cd flutter_app
call flutter pub get
call flutter build apk
cd ..
cd unity_vr
echo 🎮 Open Unity Project and build VR scene manually or via CLI.
pause