#!/usr/bin/env bash
set -e
echo "Installing monetization & expansion modules..."
flutter pub get
echo "✔ Modules registered."
