import 'package:gamification/gamification.dart';
import 'package:coach_marketplace/coach_marketplace.dart';
import 'package:in_app_marketplace/in_app_marketplace.dart';
import 'package:localization/localization.dart';

/// Initialize all monetization & expansion modules
class MonetizationUpgrades {
  static Future<void> initAll() async {
    await GamificationModule.init();
    await CoachMarketplaceModule.init();
    await InAppMarketplaceModule.init();
    await LocalizationModule.init();
  }
}