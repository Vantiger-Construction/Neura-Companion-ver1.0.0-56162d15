# LocalizationModule

## Installation
Add to your root `pubspec.yaml`:
```yaml
localization:
  path: ./packages/localization
```

## Usage
```dart
import 'package:localization/localization.dart';

await LocalizationModule.init();
// Example:
await LocalizationModule.exampleUsage();
```
