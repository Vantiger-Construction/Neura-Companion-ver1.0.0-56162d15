"""SQLModel models for Neura API with pagination schemas"""

from typing import Optional, List
from sqlmodel import SQLModel, Field, Relationship
import datetime

class Resource(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str

class PageInfo(SQLModel):
    nextCursor: Optional[int]
    prevCursor: Optional[int]

class PaginatedResources(SQLModel):
    items: List[Resource]
    pageInfo: PageInfo

class Subscription(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    url: str
    eventType: str
    deliveries: List["DeliveryRecord"] = Relationship(back_populates="subscription")

class DeliveryRecord(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    timestamp: datetime.datetime
    statusCode: int
    subscription_id: Optional[int] = Field(default=None, foreign_key="subscription.id")
    subscription: Optional[Subscription] = Relationship(back_populates="deliveries")
