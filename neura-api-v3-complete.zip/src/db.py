"""Database configuration and session utilities with seeding"""

from sqlmodel import SQLModel, create_engine, Session
from sqlalchemy.orm import sessionmaker
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./neura.db")
engine = create_engine(DATABASE_URL, echo=False)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def init_db():
    SQLModel.metadata.create_all(engine)
    # Seed default resources if empty
    with Session(engine) as session:
        count = session.exec("SELECT COUNT(*) FROM resource").one()
        if count == 0:
            for i in range(1, 101):
                session.exec(f"INSERT INTO resource (name) VALUES ('Resource {i}')")
            session.commit()

def get_session():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
