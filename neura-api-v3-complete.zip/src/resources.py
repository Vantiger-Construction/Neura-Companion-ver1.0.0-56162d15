"""Resource listing with database-backed storage and pagination schema"""

from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import select
from src.models import Resource, PageInfo, PaginatedResources
from src.db import get_session
from slowapi import limiter

router = APIRouter()

@router.get("/", response_model=PaginatedResources)
@limiter.limit("100/minute")
async def list_resources(cursor: int = 0, limit: int = 50, session=Depends(get_session)):
    offset = cursor
    resources = session.exec(select(Resource).offset(offset).limit(limit)).all()
    next_cursor = offset + limit if len(resources) == limit else None
    prev_cursor = offset - limit if offset - limit >= 0 else None
    return PaginatedResources(
        items=resources,
        pageInfo=PageInfo(nextCursor=next_cursor, prevCursor=prev_cursor)
    )
