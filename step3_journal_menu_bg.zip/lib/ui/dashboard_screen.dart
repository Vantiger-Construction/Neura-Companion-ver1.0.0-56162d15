import 'package:flutter/material.dart';
import '../core/neura_manager.dart';
import '../services/neura_emotion_engine.dart';
import 'neura_face_animator.dart';
import '../dream/dream_replay_launcher_widget.dart';
import 'journal_screen.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final manager = NeuraManager();
  final emotionEngine = NeuraEmotionEngine();

  @override
  void initState() {
    super.initState();
    manager.init().then((_) => setState(() {}));
  }

  @override
  Widget build(BuildContext context) {
    final emotion = emotionEngine.currentEmotion;
    final isHappy = emotion == NeuraEmotion.happy;
    return Scaffold(
      appBar: AppBar(title: Text('Dashboard')),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            NeuraFaceAnimator(reacting: false, happy: isHappy),
            SizedBox(height: 8),
            Text('Emotion: \${emotionEngine.getEmotionLabel()}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 16),
            ElevatedButton(onPressed: _handleMoodCheckIn, child: Text('Mood Check-In')),
            SizedBox(height: 8),
            ElevatedButton(onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) =>
                  DreamReplayLauncherWidget(entries: [])));
              }, child: Text('Play Dream Replay')),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => JournalScreen()));
              },
              child: Text('Open Journal'),
            ),
            SizedBox(height: 16),
            Text(manager.getGrowthSummary(), style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }

  void _handleMoodCheckIn() {
    NeuraMood selected = NeuraMood.calm;
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text('Select your mood'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: NeuraMood.values.map((m) {
                  return RadioListTile<NeuraMood>(
                    title: Text(m.toString().split('.').last),
                    value: m,
                    groupValue: selected,
                    onChanged: (value) {
                      setState(() { selected = value!; });
                    },
                  );
                }).toList(),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context), child: Text('Cancel')),
                TextButton(onPressed: () {
                  manager.logMood(selected);
                  emotionEngine.updateEmotion(NeuraEmotion.values[selected.index]);
                  Navigator.pop(context);
                  setState(() {});
                }, child: Text('OK')),
              ],
            );
          }
        );
      }
    );
  }
}
