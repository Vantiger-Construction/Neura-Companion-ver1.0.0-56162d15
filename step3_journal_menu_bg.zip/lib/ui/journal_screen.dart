
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/neura_emotion_engine.dart';
import 'neura_face_animator.dart';

class JournalScreen extends StatefulWidget {
  @override
  _JournalScreenState createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  final _controller = TextEditingController();
  List<String> _entries = [];
  final emotionEngine = NeuraEmotionEngine();

  @override
  void initState() {
    super.initState();
    _loadEntries();
    Future.microtask(_showAIPrompt);
  }

  void _showAIPrompt() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Journal Prompt'),
        content: Text('Reflect on something positive that happened today.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('OK'))
        ],
      ),
    );
  }

  Future<void> _loadEntries() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _entries = prefs.getStringList('journal_entries') ?? [];
    });
  }

  Future<void> _saveEntry() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    _entries.add(text);
    await prefs.setStringList('journal_entries', _entries);
    setState(() {
      _controller.clear();
    });
  }

  LinearGradient _overlayGradient() {
    final emotion = emotionEngine.currentEmotion;
    switch (emotion) {
      case NeuraEmotion.happy:
        return LinearGradient(colors: [Colors.yellow.withOpacity(0.3), Colors.orange.withOpacity(0.3)]);
      case NeuraEmotion.calm:
        return LinearGradient(colors: [Colors.blue.withOpacity(0.3), Colors.teal.withOpacity(0.3)]);
      case NeuraEmotion.excited:
        return LinearGradient(colors: [Colors.purple.withOpacity(0.3), Colors.pink.withOpacity(0.3)]);
      case NeuraEmotion.angry:
        return LinearGradient(colors: [Colors.red.withOpacity(0.3), Colors.red.shade700.withOpacity(0.3)]);
      case NeuraEmotion.sad:
      default:
        return LinearGradient(colors: [Colors.grey.withOpacity(0.3), Colors.blueGrey.shade700.withOpacity(0.3)]);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text('Journal'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/journal_menu_background.png',
              fit: BoxFit.cover,
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(gradient: _overlayGradient()),
            ),
          ),
          // Neura avatar spot
          Positioned(
            top: MediaQuery.of(context).padding.top + 16,
            right: 16,
            child: NeuraFaceAnimator(reacting: false, happy: false),
          ),
          Padding(
            padding: EdgeInsets.only(top: kToolbarHeight + 16, left: 16, right: 16),
            child: Column(
              children: [
                Expanded(
                  child: _entries.isEmpty
                      ? Center(
                          child: Text(
                            'No entries yet',
                            style: TextStyle(color: Colors.white70, fontSize: 18),
                          ),
                        )
                      : ListView.separated(
                          itemCount: _entries.length,
                          separatorBuilder: (_, __) => Divider(color: Colors.white30),
                          itemBuilder: (context, index) => ListTile(
                            title: Text(
                              _entries[index],
                              style: TextStyle(color: Colors.white),
                            ),
                            leading: Icon(Icons.article, color: Colors.white70),
                          ),
                        ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: TextField(
                    controller: _controller,
                    style: TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Write here...',
                      hintStyle: TextStyle(color: Colors.white54),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    ),
                    maxLines: 3,
                  ),
                ),
                SizedBox(height: 12),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Colors.white30,
                    onPrimary: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  onPressed: _saveEntry,
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    child: Text('Save Entry', style: TextStyle(fontSize: 16)),
                  ),
                ),
                SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
