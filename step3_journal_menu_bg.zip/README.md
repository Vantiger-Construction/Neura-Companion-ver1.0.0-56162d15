# Neura Companion - Step 3: Mood Tracking & Journaling

This build adds:

- A "Journal" button on the Dashboard screen  
- A dedicated JournalScreen for writing and saving entries  
- AI-generated journal prompt on screen open  
- Local persistence of journal entries via SharedPreferences

## Files Added/Updated

- **lib/ui/dashboard_screen.dart** → Added navigation to JournalScreen  
- **lib/ui/journal_screen.dart** → New screen implementation  
- **pubspec.yaml** → Bumped version and description  

## Running the App

1. `flutter pub get`  
2. `flutter run`  

On launch, tap **Open Journal** to access the Journal screen.
