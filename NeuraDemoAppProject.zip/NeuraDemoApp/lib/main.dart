import 'package:flutter/material.dart';
import 'core/self_heal/neura_error_recovery.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  NeuraErrorMonitor.init();
  runApp(NeuraCompanionDemo());
}

class NeuraCompanionDemo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion Demo',
      home: NeuraDemoHomePage(),
    );
  }
}

class NeuraDemoHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Neura Error Healing Demo")),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Trigger a deliberate error to show auto healing
            dynamic x;
            print(x.foo); // Will throw
          },
          child: Text("Cause Error"),
        ),
      ),
    );
  }
}