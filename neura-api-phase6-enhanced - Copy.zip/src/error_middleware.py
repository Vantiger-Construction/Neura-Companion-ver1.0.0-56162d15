from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi import HTTPException
from src.ai_error_handler import ai_autofix

async def global_exception_handler(request: Request, exc: Exception):
    # For HTTPExceptions and others
    result = await ai_autofix(exc, request)
    if isinstance(exc, HTTPException):
        status = exc.status_code
        detail = exc.detail
    else:
        status = 500
        detail = str(exc)
    response = {"error": detail}
    response.update(result)
    return JSONResponse(status_code=status, content=response)
