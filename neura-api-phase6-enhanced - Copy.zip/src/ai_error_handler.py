import traceback
import os
import re
from fastapi import Request
from openai import OpenAI
from functools import lru_cache

# Initialize OpenAI client
openai_api_key = os.getenv("OPENAI_API_KEY")
ai_client = OpenAI(api_key=openai_api_key) if openai_api_key else None

def extract_code_context(tb: str, context_lines: int = 5) -> str:
    # Extract file and line from last traceback entry
    match = re.search(r'File "(.+)", line (\d+)', tb)
    if not match:
        return ""
    fname, lineno = match.group(1), int(match.group(2))
    try:
        with open(fname) as f:
            lines = f.readlines()
        start = max(0, lineno - context_lines - 1)
        end = min(len(lines), lineno + context_lines)
        snippet = "".join(lines[start:end])
        return f"File: {fname}, Line: {lineno}\n```\n{snippet}\n```"
    except Exception:
        return ""

@lru_cache(maxsize=128)
def classify_severity(exc_type: str, message: str) -> str:
    if not ai_client:
        return "unknown"
    prompt = (
        f"Classify the severity of this exception into one of: critical, warning, info.\n"
        f"Exception type: {exc_type}\nMessage: {message}"
    )
    try:
        resp = ai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role":"user","content":prompt}],
        )
        sev = resp.choices[0].message.content.strip().lower()
        for level in ["critical","warning","info"]:
            if level in sev:
                return level
    except Exception:
        pass
    return "info"

@lru_cache(maxsize=128)
async def ai_autofix(exc: Exception, request: Request) -> dict:
    tb = traceback.format_exc()
    severity = classify_severity(type(exc).__name__, str(exc))
    context = extract_code_context(tb)
    prompt = (
        f"You are an AI assistant for code debugging.\n"
        f"Exception occurred: {exc}\n"
        f"Severity: {severity}\n"
        f"Stack trace:\n{tb}\n"
    )
    if context:
        prompt += f"Relevant code context:\n{context}\n"
    prompt += "Provide a concise code diff patch suggestion in unified diff format."
    suggestion = None
    diff = None
    try:
        resp = await ai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role":"user","content":prompt}],
        )
        content = resp.choices[0].message.content.strip()
        # Split diff and suggestion if contained
        diff = content
        suggestion = "See diff for fix"
    except Exception as e:
        suggestion = f"Error obtaining AI suggestion: {e}"
    return {"severity": severity, "suggestion": suggestion, "diff": diff}
