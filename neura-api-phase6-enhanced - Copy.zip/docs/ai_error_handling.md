# AI-Driven Error Handling (Enhanced)

## Overview
The AI error handler now includes:
1. **Severity Classification**: Errors are labeled `critical`, `warning`, or `info`.
2. **Code Context**: Snippet around the error location is included in the prompt.
3. **Unified Diff Suggestion**: AI returns a patch diff to apply a fix.
4. **Caching**: Recent errors are cached to reduce API usage.

### Response Format
```json
{
  "error": "division by zero",
  "severity": "critical",
  "suggestion": "See diff for fix",
  "diff": "```diff\n--- a/src/compute.py\n+++ b/src/compute.py\n@@ -10,7 +10,8 @@ def compute(x,y):\n-    return x/y\n+    if y == 0:\n+        return None\n+    return x/y\n```"
}
```

## Configuration
- **OPENAI_API_KEY**: API key for OpenAI.  
- Ensure the AI client is configured and connected.
