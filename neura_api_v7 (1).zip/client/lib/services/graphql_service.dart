import 'package:graphql_flutter/graphql_flutter.dart';

class GraphQLService {
  late GraphQLClient client;

  void init(String httpUri, String websocketUri) {
    final httpLink = HttpLink(httpUri);
    final wsLink = WebSocketLink(websocketUri);
    client = GraphQLClient(
      link: Link.split((op) => op.isSubscription, wsLink, httpLink),
      cache: GraphQLCache(),
    );
  }

  Stream<QueryResult> subscribeMemory(String userId) {
    return client.subscribe(SubscriptionOptions(
      document: gql(r'''
        subscription MemoryAdded($userId: ID!) {
          memoryAdded(userId: $userId) { id data }
        }
      '''),
      variables: {'userId': userId},
    ));
  }
}
