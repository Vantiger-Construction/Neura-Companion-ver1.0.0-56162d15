import 'package:graphql_flutter/graphql_flutter.dart';

class OfflineQueue {
  final List<Operation> _queue = [];

  void enqueue(Operation op) {
    _queue.add(op);
  }

  Future<void> flush(GraphQLClient client) async {
    for (var op in List.from(_queue)) {
      try {
        await client.query(QueryOptions(document: op.document, variables: op.variables));
        _queue.remove(op);
      } catch (_) {
        // keep in queue
      }
    }
  }
}

class Operation {
  final String document;
  final Map<String, dynamic>? variables;
  Operation({required this.document, this.variables});
}
