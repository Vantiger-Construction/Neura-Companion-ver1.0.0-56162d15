import 'package:socket_io_client/socket_io_client.dart';

class WebSocketService {
  late Socket socket;

  void connect(String uri, String token) {
    socket = io(uri, OptionBuilder()
      .setTransports(['websocket'])
      .setExtraHeaders({'Authorization': 'Bearer $token'})
      .build());
  }

  void onMemoryAdded(void Function(dynamic) callback) {
    socket.on('memoryAdded', callback);
  }
}
