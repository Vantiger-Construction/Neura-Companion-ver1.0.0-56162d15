import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override String toString() => 'ApiException: $message';
}

class NeuraApiService {
  final String baseUrl;
  final FlutterSecureStorage storage;
  String? _token;

  NeuraApiService({required this.baseUrl, required this.storage});

  Future<void> login(String email, String password) async {
    final res = await http.post(Uri.parse('\$baseUrl/api/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}));
    if (res.statusCode != 200) throw ApiException('Login failed: ${res.body}');
    final body = jsonDecode(res.body);
    _token = body['token'];
    await storage.write(key: 'jwt', value: _token!);
  }

  Future<void> register(String email, String password) async {
    final res = await http.post(Uri.parse('\$baseUrl/api/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}));
    if (res.statusCode != 200) throw ApiException('Registration failed: ${res.body}');
  }

  Future<List<dynamic>> fetchShopProducts() => _get('/shop/products');

  Future<void> purchaseProduct(String productId) => _post('/shop/purchase', {'productId': productId});

  Future<List<dynamic>> fetchOrderHistory() => _get('/orders');

  Future<Map<String, dynamic>> getSubscriptionStatus() => _get('/subscriptions/status');

  Future<Map<String, dynamic>> createSubscription(String priceId) => _post('/subscriptions/create', {'priceId': priceId});

  Future<List<dynamic>> _get(String path) async {
    await _loadToken();
    final res = await http.get(Uri.parse('\$baseUrl/api\$path'),
      headers: {'Authorization': 'Bearer \$_token'});
    if (res.statusCode != 200) throw ApiException('GET $path failed: ${res.body}');
    return jsonDecode(res.body);
  }

  Future<dynamic> _post(String path, Map<String, dynamic> body) async {
    await _loadToken();
    final res = await http.post(Uri.parse('\$baseUrl/api\$path'),
      headers: {'Content-Type':'application/json', 'Authorization': 'Bearer \$_token'},
      body: jsonEncode(body));
    if (res.statusCode != 200) throw ApiException('POST $path failed: ${res.body}');
    return jsonDecode(res.body);
  }

  Future<void> _loadToken() async {
    _token ??= await storage.read(key: 'jwt');
    if (_token == null) throw ApiException('Not authenticated');
  }
}
