import 'package:get_it/get_it.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'neura_api_service.dart';
import 'graphql_service.dart';

final sl = GetIt.instance;

Future<void> setupServiceLocator(String httpUri, String wsUri) async {
  final storage = FlutterSecureStorage();
  final gqlService = GraphQLService(httpUri, wsUri, storage);
  await gqlService.initialize();
  sl.registerSingleton<GraphQLService>(gqlService);
  final apiService = NeuraApiService(gqlService, storage);
  sl.registerSingleton<NeuraApiService>(apiService);
}
