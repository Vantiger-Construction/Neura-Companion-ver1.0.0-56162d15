#!/usr/bin/env bash
set -e
echo "Installing Neura API v4..."
cd backend && npm install
