#!/usr/bin/env bash
set -e
echo "Installing Neura API v3 with auth, roles & shop..."
cd backend && npm install
