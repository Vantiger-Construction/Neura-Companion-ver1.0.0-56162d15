#!/usr/bin/env bash
set -e
echo "Installing Neura API v7 with directives and socket events..."
cd backend && npm install
