#!/usr/bin/env bash
set -e
echo "Installing Neura API v6 with GraphQL and WebSockets..."
cd backend && npm install
