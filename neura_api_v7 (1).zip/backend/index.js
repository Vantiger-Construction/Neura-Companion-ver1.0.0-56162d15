require('dotenv').config();
const express = require('express');
const http = require('http');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const { typeDefs, resolvers } = require('./routes/graphql');
const socketEvents = require('./routes/socket_events');
const { ApolloServer } = require('apollo-server-express');
const { Server } = require('socket.io');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');

const auth = require('./routes/auth');
const jokes = require('./routes/jokes');
const dreams = require('./routes/dreams');
const settings = require('./routes/settings');
const memory = require('./routes/memory');


const app = express();
const httpServer = http.createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });
io.on('connection', socket => console.log('Socket connected:', socket.id));
app.use('/api/socket', socketEvents(io));

// Apollo GraphQL setup
async function startApollo() {
  const server = new ApolloServer({ typeDefs, resolvers, context: ({req}) => ({ user: req.user }) });
  await server.start();
  server.applyMiddleware({ app, path: '/api/graphql' });
}
startApollo();
