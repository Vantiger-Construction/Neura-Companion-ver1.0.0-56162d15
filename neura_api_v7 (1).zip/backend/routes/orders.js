const express = require('express');
const router = express.Router();
const { authMiddleware } = require('./auth');
const Order = require('../models/Order');

router.use(authMiddleware);

// GET user orders
router.get('/', async (req, res, next) => {
  try {
    const orders = await Order.find({ userId: req.userId });
    res.json(orders);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
