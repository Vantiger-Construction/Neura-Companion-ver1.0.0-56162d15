const express = require('express');
const router = express.Router();
const { authMiddleware } = require('./auth');
const { roleMiddleware } = require('./roleMiddleware');

// Sample products
const products = [
  { id: 'clinic_dashboard', name: 'Clinician Dashboard Access', priceCents: 4999 },
  { id: 'analytics_pack', name: 'Advanced Analytics Pack', priceCents: 2999 }
];

// All shop routes require authentication
router.use(authMiddleware);

// GET available products (doctor & admin only)
router.get('/products', roleMiddleware(['doctor','admin']), (req, res) => {
  res.json(products);
});

// POST purchase a product
router.post('/purchase', roleMiddleware(['doctor','admin']), (req, res) => {
  const { productId } = req.body;
  // Record order
  const Order = require('../models/Order');
  const product = products.find(p => p.id === productId);
  const order = new Order({ userId: req.userId, productId, priceCents: product.priceCents });
  await order.save();
  res.json({ success: true, productId });
});

module.exports = router;
