const express = require('express');
const router = express.Router();
const { authMiddleware } = require('./auth');
const Subscription = require('../models/Subscription');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

router.use(authMiddleware);

// POST create subscription
router.post('/create', async (req, res, next) => {
  try {
    const { priceId } = req.body;
    const customer = await stripe.customers.create({ metadata: { userId: req.userId } });
    const subscription = await stripe.subscriptions.create({
      customer: customer.id,
      items: [{ price: priceId }]
    });
    const subDoc = new Subscription({
      userId: req.userId,
      stripeSubscriptionId: subscription.id,
      status: subscription.status,
      currentPeriodEnd: new Date(subscription.current_period_end * 1000)
    });
    await subDoc.save();
    res.json(subDoc);
  } catch (err) {
    next(err);
  }
});

// GET subscription status
router.get('/status', async (req, res, next) => {
  try {
    const sub = await Subscription.findOne({ userId: req.userId }).sort({ createdAt: -1 });
    res.json(sub || {});
  } catch (err) {
    next(err);
  }
});

module.exports = router;
