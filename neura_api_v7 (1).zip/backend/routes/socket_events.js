const express = require('express');
const router = express.Router();

module.exports = (io) => {
  // broadcast a ping to all clients
  router.post('/ping', (req, res) => {
    io.emit('ping', { timestamp: Date.now() });
    res.json({ success: true });
  });
  return router;
};
