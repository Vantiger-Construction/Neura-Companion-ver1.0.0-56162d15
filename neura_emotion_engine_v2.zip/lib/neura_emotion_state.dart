
const Map<String, String> emotionToAnimation = {
  'happy': 'assets/peace_sign_cheer.json',
  'calm': 'assets/idle_breathing_glow.json',
  'sad': 'assets/sad_reflective_look.json',
  'anxious': 'assets/hug_open_arms.json',
  'surprised': 'assets/surprised_blink.json',
  'confident': 'assets/confident_gaze.json',
  'playful': 'assets/cheeky_wink.json',
  'tired': 'assets/yawn_sleepy.json',
  'frustrated': 'assets/annoyed_puff.json',
  'curious': 'assets/smirk_sideways.json',
  'neutral': 'assets/idle_breathing_glow.json',
};
