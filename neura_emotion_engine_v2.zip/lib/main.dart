
import 'package:flutter/material.dart';
import 'neura_animation_engine.dart';
import 'neura_emotion_mapper.dart';
import 'neura_mood_memory.dart';
import 'neura_voice_input.dart';

void main() => runApp(const NeuraEmotionApp());

class NeuraEmotionApp extends StatefulWidget {
  const NeuraEmotionApp({super.key});

  @override
  State<NeuraEmotionApp> createState() => _NeuraEmotionAppState();
}

class _NeuraEmotionAppState extends State<NeuraEmotionApp> {
  String currentEmotion = 'calm';
  List<String> history = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  void _loadHistory() async {
    history = await MoodMemory.getMoodHistory();
    setState(() {});
  }

  void _handleInput(String input) async {
    final mood = mapTextToEmotion(input);
    setState(() => currentEmotion = mood);
    await MoodMemory.logMood(mood);
    _loadHistory();
  }

  void _handleVoiceInput() async {
    final spokenText = await transcribeVoiceToText();
    _handleInput(spokenText);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(title: const Text('Neura Real-Time Emotion Engine')),
        body: Column(
          children: [
            Expanded(child: NeuraAnimationEngine(emotion: currentEmotion)),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Type how you feel...',
                  hintStyle: TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: Colors.white12,
                ),
                onSubmitted: _handleInput,
              ),
            ),
            ElevatedButton(
              onPressed: _handleVoiceInput,
              child: const Text("🎤 Speak Emotion"),
            ),
            const SizedBox(height: 10),
            Text("🧠 Mood Memory", style: const TextStyle(color: Colors.white)),
            for (var h in history)
              Text("• $h", style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}
