
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'neura_emotion_state.dart';

class NeuraAnimationEngine extends StatefulWidget {
  final String emotion;
  const NeuraAnimationEngine({Key? key, required this.emotion}) : super(key: key);

  @override
  State<NeuraAnimationEngine> createState() => _NeuraAnimationEngineState();
}

class _NeuraAnimationEngineState extends State<NeuraAnimationEngine> {
  late String animationPath;

  @override
  void initState() {
    super.initState();
    animationPath = emotionToAnimation[widget.emotion] ?? 'assets/idle_breathing_glow.json';
  }

  @override
  void didUpdateWidget(covariant NeuraAnimationEngine oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.emotion != widget.emotion) {
      setState(() {
        animationPath = emotionToAnimation[widget.emotion] ?? 'assets/idle_breathing_glow.json';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Lottie.asset(animationPath);
  }
}
