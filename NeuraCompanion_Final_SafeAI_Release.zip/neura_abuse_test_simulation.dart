
// 🧪 Neura Abuse Filter Test Simulation
void runTest() {
  var guardian = NeuraGuardian();

  print("Simulating abuse input...");
  guardian.handleInput("shut up Neura");

  print("Simulating apology...");
  if (guardian.userStrikeCount > 0) {
    print("User: I'm sorry");
    print("Neura: Thanks for understanding. Let's reset our mood.");
  }
}
