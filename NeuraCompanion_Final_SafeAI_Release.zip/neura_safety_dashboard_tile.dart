
// 🎯 Neura Safety Dashboard Tile
class NeuraSafetyTile extends StatelessWidget {
  final int strikes;
  final bool forgiven;
  final String lastIncident;

  const NeuraSafetyTile({required this.strikes, required this.forgiven, required this.lastIncident});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: forgiven ? Colors.green[50] : Colors.red[50],
      child: ListTile(
        leading: Icon(Icons.shield, color: forgiven ? Colors.green : Colors.red),
        title: Text("Behavior Status"),
        subtitle: Text("Strikes: \$strikes\nLast: \$lastIncident"),
        trailing: forgiven ? Icon(Icons.favorite, color: Colors.green) : Icon(Icons.warning, color: Colors.red),
      ),
    );
  }
}
