import 'package:flutter/material.dart';

class DreamCalendarScreen extends StatelessWidget {
  final Map<DateTime, String> dreamEntries;

  const DreamCalendarScreen({super.key, required this.dreamEntries});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Dream Timeline')),
      body: ListView(
        children: dreamEntries.entries.map((entry) {
          return ListTile(
            title: Text(entry.key.toString().split(' ')[0]),
            subtitle: Text(entry.value),
          );
        }).toList(),
      ),
    );
  }
}