import 'package:flutter/material.dart';

class NeuraPersona extends ChangeNotifier {
  String dominantTrait = 'loyal';
  String affinity = 'calm';

  void updateTrait(String trait) {
    dominantTrait = trait;
    notifyListeners();
  }

  void updateAffinity(String newAffinity) {
    affinity = newAffinity;
    notifyListeners();
  }

  String describePersona() {
    return "Trait: \$dominantTrait, Affinity: \$affinity";
  }
}