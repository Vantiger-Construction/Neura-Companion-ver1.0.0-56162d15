import 'package:flutter/material.dart';

class DreamVisualizerEngine {
  static String generateVisualPrompt(String dreamText) {
    return "AI art of: " + dreamText;
  }

  static String summarizeDream(String dreamText) {
    return "Summary: " + dreamText.substring(0, dreamText.length > 60 ? 60 : dreamText.length) + "...";
  }
}