import 'package:flutter/material.dart';
import '../../lib/engine/NeuraVoiceSyncEngine.dart';
import '../../lib/widgets/NeuraVisemeFace.dart';
import '../../lib/widgets/NeuraEyeOverlay.dart';
import '../../lib/mood/NeuraMoodManager.dart';
import 'package:provider/provider.dart';

class NeuraLiveTestScreen extends StatelessWidget {
  const NeuraLiveTestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final mood = Provider.of<NeuraMoodManager>(context).currentMood;

    return Scaffold(
      appBar: AppBar(title: Text('Neura Live Test')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              children: [
                NeuraVisemeFace(),
                NeuraEyeOverlay(mood: mood),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                NeuraVoiceSyncEngine.instance.speak(
                  "Hello, I'm Neura. Let's dream something beautiful together.",
                  context,
                );
              },
              child: Text("Speak Test"),
            ),
          ],
        ),
      ),
    );
  }
}