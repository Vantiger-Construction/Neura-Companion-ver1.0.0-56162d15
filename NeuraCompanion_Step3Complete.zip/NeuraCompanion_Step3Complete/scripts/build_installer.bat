@echo off
REM Build Windows release and package installer
echo Building Windows release...
flutter build windows --release
echo Packaging installer...
REM TODO: Add packaging steps here
pause
