
import 'package:flutter/material.dart';
import 'modules/clinical/clinical_dashboard.dart';
import 'modules/clinical/vitals_monitor.dart';
import 'modules/clinical/emergency_checklist.dart';
import 'modules/clinical/medication_tracker.dart';
import 'modules/dream/dream_engine.dart';
import 'modules/journal/journal_router.dart';
import 'modules/memory/neura_memory.dart';
import 'modules/personality/persona_trait_engine.dart';
import 'modules/emotion/emotion_processor.dart';
import 'modules/voice/viseme_controller.dart';
import 'modules/vr/neura_vr_interface.dart';
import 'widgets/neura_voice_reactive_widget.dart';
import 'modules/feed/public_ritual_feed.dart';
import 'modules/mood/global_mood_map.dart';

final Map<String, WidgetBuilder> appRoutes = {
  '/clinical': (context) => ClinicalDashboardPage(),
  '/clinical/vitals': (context) => VitalsMonitorPage(),
  '/clinical/emergency': (context) => EmergencyChecklistPage(),
  '/clinical/medications': (context) => MedicationTrackerPage(),
  '/journal': (context) => JournalRouter.resolvePage(RouteSettings(name: '/journal'))!,
  '/dream': (context) => DreamEngine().animateDream(),
  '/feed': (context) => PublicRitualFeedPage(),
  '/moodmap': (context) => GlobalMoodMapPage(),
};
