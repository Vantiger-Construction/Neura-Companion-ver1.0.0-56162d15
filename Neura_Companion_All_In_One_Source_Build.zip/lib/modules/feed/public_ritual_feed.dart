
import 'package:flutter/material.dart';

class PublicRitualFeedPage extends StatelessWidget {
  final List<Map<String, String>> rituals = [
    {'user': 'ZenWolf', 'ritual': 'Morning breathwork + gratitude'},
    {'user': 'SkyDreamer', 'ritual': 'Cold shower + mantra'},
    {'user': 'NeuraFan', 'ritual': 'Coffee ritual with focus song'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Public Ritual Feed')),
      body: ListView.builder(
        itemCount: rituals.length,
        itemBuilder: (_, i) {
          final r = rituals[i];
          return ListTile(
            leading: Icon(Icons.self_improvement),
            title: Text('@${r['user']}'),
            subtitle: Text(r['ritual'] ?? ''),
            trailing: Icon(Icons.favorite_border),
          );
        },
      ),
    );
  }
}
