
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:crypto/crypto.dart';

class SecureMemoryMode {
  final FlutterSecureStorage _storage = FlutterSecureStorage();
  final String _keyPrefix = 'secure_memory_';

  Future<void> saveEncrypted(String id, String content, String passphrase) async {
    final key = _deriveKey(passphrase);
    final encoded = base64Encode(_xorWithKey(utf8.encode(content), key));
    await _storage.write(key: '\$_keyPrefix\$id', value: encoded);
  }

  Future<String?> readDecrypted(String id, String passphrase) async {
    final key = _deriveKey(passphrase);
    final encrypted = await _storage.read(key: '\$_keyPrefix\$id');
    if (encrypted == null) return null;
    try {
      final bytes = base64Decode(encrypted);
      return utf8.decode(_xorWithKey(bytes, key));
    } catch (_) {
      return null; // decryption failed
    }
  }

  List<int> _deriveKey(String passphrase) {
    final hash = sha256.convert(utf8.encode(passphrase));
    return hash.bytes.sublist(0, 32);
  }

  List<int> _xorWithKey(List<int> data, List<int> key) {
    final keyLen = key.length;
    return List.generate(data.length, (i) => data[i] ^ key[i % keyLen]);
  }

  Future<void> clearAll() async {
    final all = await _storage.readAll();
    for (final k in all.keys) {
      if (k.startsWith(_keyPrefix)) {
        await _storage.delete(key: k);
      }
    }
  }
}
