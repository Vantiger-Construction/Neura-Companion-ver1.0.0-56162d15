
import 'dart:async';

class VisemeFrame {
  final String viseme; // e.g., "A", "E", "O", "U", "L", "M", "etc"
  final Duration timestamp;

  VisemeFrame(this.viseme, this.timestamp);
}

class VisemeController {
  final List<VisemeFrame> _visemeQueue = [];

  void syncToTTS(String spokenText) {
    _visemeQueue.clear();

    final durationPerChar = Duration(milliseconds: 120); // basic pacing
    Duration currentTime = Duration.zero;

    for (int i = 0; i < spokenText.length; i++) {
      final char = spokenText[i].toLowerCase();
      final viseme = _mapCharToViseme(char);
      if (viseme != null) {
        _visemeQueue.add(VisemeFrame(viseme, currentTime));
        currentTime += durationPerChar;
      }
    }

    print("Viseme frames created: \${_visemeQueue.length}");
  }

  String? _mapCharToViseme(String char) {
    const mouthMap = {
      'a': 'A',
      'e': 'E',
      'i': 'E',
      'o': 'O',
      'u': 'U',
      'm': 'M',
      'b': 'M',
      'p': 'M',
      'l': 'L',
      's': 'S',
      't': 'T',
      'k': 'K',
      'g': 'G',
      'n': 'N',
      'd': 'D',
      'h': 'H',
    };
    return mouthMap[char];
  }

  Stream<VisemeFrame> getVisemeStream() async* {
    for (final frame in _visemeQueue) {
      await Future.delayed(frame.timestamp);
      yield frame;
    }
  }
}
