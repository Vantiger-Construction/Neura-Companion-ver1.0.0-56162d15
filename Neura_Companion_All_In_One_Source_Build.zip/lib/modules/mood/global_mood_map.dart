
import 'package:flutter/material.dart';
import 'dart:math';

class GlobalMoodMapPage extends StatelessWidget {
  final List<String> moods = ['happy', 'sad', 'anxious', 'calm', 'excited'];

  Color _getMoodColor(String mood) {
    switch (mood) {
      case 'happy': return Colors.yellowAccent;
      case 'sad': return Colors.blueGrey;
      case 'anxious': return Colors.redAccent;
      case 'calm': return Colors.lightBlue;
      case 'excited': return Colors.orangeAccent;
      default: return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final random = Random();
    return Scaffold(
      appBar: AppBar(title: Text('Global Mood Map')),
      body: GridView.builder(
        padding: EdgeInsets.all(16),
        itemCount: 100,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 10,
          crossAxisSpacing: 4,
          mainAxisSpacing: 4,
        ),
        itemBuilder: (_, i) {
          final mood = moods[random.nextInt(moods.length)];
          return Tooltip(
            message: mood,
            child: Container(
              color: _getMoodColor(mood),
            ),
          );
        },
      ),
    );
  }
}
