# CI/CD Integration

A GitHub Actions workflow is included at `.github/workflows/ci.yml`:

```yaml
name: CI
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: subosito/flutter-action@v2
      - run: flutter pub get
      - run: flutter test --coverage
      - name: Upload coverage
        uses: codecov/codecov-action@v3
```
This runs unit tests and publishes code coverage to Codecov.
