# Quick Start

After installation, use the Module in your app:

```dart
// Purchase handling
try {
  final module = await ClinicalUpgradesV4.initModule(
    fhirServerUrl: 'https://your.fhir.server',
    apiKey: 'API_KEY',
  );
} catch (e) {
  // If not subscribed:
  await ClinicalUpgradesV4.purchase();
}

// Fetch a patient record
final patient = await module.fetchPatient('patient-id');

// Send a heart rate observation
final obs = Observation(
  status: ObservationStatus.final_,
  code: CodeableConcept(
    coding: [Coding(system: 'http://loinc.org', code: '8867-4', display: 'Heart rate')]
  ),
  subject: Reference(reference: 'Patient/patient-id'),
  effectiveDateTime: FhirDateTime.now(),
  valueQuantity: Quantity(value: 72, unit: 'beats/min'),
);
await module.sendObservation(obs);

// Flush any queued observations
await module.flushQueue();
