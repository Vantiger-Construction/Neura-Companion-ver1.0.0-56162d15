# Installation

Add the Clinical Module to your Flutter project:

1. Unzip the add-on into your project root:
   ```
   unzip clinical_module_v4.zip
   ```
2. In your `pubspec.yaml`, add:
   ```yaml
   clinical_module:
     path: ./packages/clinical_module
   ```
3. Run the installer script:
   ```bash
   ./scripts/install_clinical_v4.sh
   ```
4. In `main.dart`, initialize:
   ```dart
   import 'package:clinical_module/clincal_upgrades_v4.dart';
   
   void main() async {
     WidgetsFlutterBinding.ensureInitialized();
     final module = await ClinicalUpgradesV4.initModule(
       fhirServerUrl: 'https://your.fhir.server',
       apiKey: 'API_KEY',
     );
     runApp(MyApp(module: module));
   }
   ```
