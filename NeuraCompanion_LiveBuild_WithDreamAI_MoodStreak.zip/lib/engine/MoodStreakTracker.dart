import 'package:flutter/material.dart';

class MoodStreakTracker extends ChangeNotifier {
  int currentStreak = 0;
  DateTime? lastEntry;

  void registerCheckIn(DateTime now) {
    if (lastEntry != null) {
      final diff = now.difference(lastEntry!).inDays;
      if (diff == 1) {
        currentStreak += 1;
      } else if (diff > 1) {
        currentStreak = 1;
      }
    } else {
      currentStreak = 1;
    }
    lastEntry = now;
    notifyListeners();
  }

  int get streak => currentStreak;
}