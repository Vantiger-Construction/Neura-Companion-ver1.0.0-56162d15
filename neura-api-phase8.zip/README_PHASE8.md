# Phase 8: End-to-End Testing & Load Validation

This package includes scripts to validate performance and reliability under load.

## Locust

### Requirements
```bash
pip install locust
```

### Running Load Test

```bash
export WEBHOOK_SECRET=secretkey
locust -f locustfile.py --host=http://localhost:8000
```

Open http://localhost:8089 to configure users and start the test.

## JMeter

### Requirements
- Apache JMeter installed

### Running Test Plan

1. Open `jmeter_test_plan.jmx` in JMeter GUI.  
2. Configure Thread Group and HTTP Requests.  
3. Run and analyze results via Listeners.
