from locust import HttpUser, TaskSet, task, between
import json, time, hmac, hashlib, os

class WebhookTasks(TaskSet):
    def on_start(self):
        # Authenticate
        resp = self.client.post("/v1/auth/token", data={"username": "alice", "password": "secret"})
        token = resp.json().get("access_token")
        self.headers = {"Authorization": f"Bearer {token}"}
        # Subscribe a test webhook
        resp = self.client.post("/v1/webhooks/subscribe", json={"url": "http://localhost/test", "eventType": "load"}, headers=self.headers)
        self.sub_id = resp.json().get("id")

    @task(3)
    def list_resources(self):
        self.client.get("/v1/resources", headers=self.headers)

    @task(2)
    def list_subscriptions(self):
        self.client.get("/v1/webhooks/subscriptions", headers=self.headers)

    @task(1)
    def send_event(self):
        body = json.dumps({"load": "test"}).encode()
        ts = str(int(time.time()))
        sig = hmac.new(os.getenv("WEBHOOK_SECRET","secretkey").encode(), body, hashlib.sha256).hexdigest()
        self.client.post("/v1/webhooks/receive", data=body, headers={**self.headers, "X-Timestamp": ts, "X-Signature": sig})

class NeuraUser(HttpUser):
    tasks = [WebhookTasks]
    wait_time = between(1, 3)
