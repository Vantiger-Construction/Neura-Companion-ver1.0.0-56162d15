from fastapi import FastAPI
from sqlmodel import SQLModel
from app.routes import voice, persona, journal, emotion, sync, dream, mirror
from app.utils.db import engine

app = FastAPI(title="Neura Companion API")

@app.on_event("startup")
def on_startup():
    SQLModel.metadata.create_all(engine)

app.include_router(persona.router, prefix="/api/ai/persona")
app.include_router(voice.router, prefix="/api/voice")
app.include_router(journal.router, prefix="/api/journal")
app.include_router(emotion.router, prefix="/api/emotion")
app.include_router(sync.router, prefix="/api/sync")
app.include_router(dream.router, prefix="/api/dream")
app.include_router(mirror.router, prefix="/api/mirror")

@app.get("/")
def root():
    return {"status": "Neura API is fully active"}