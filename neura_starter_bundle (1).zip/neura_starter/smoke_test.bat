@echo off
setlocal ENABLEDELAYEDEXPANSION

REM === Neura Companion Smoke Test (Windows) ===
REM Usage: place this file at repo root, then run it.
REM It will try to start backend and the Flutter app.

REM --- Locate project paths (adjust if your structure differs) ---
set BACKEND_DIR=neura_companion\backend
set FLUTTER_DIR=neura_companion\flutter_ui

IF NOT EXIST "%BACKEND_DIR%" (
  echo [ERROR] Backend dir not found: %BACKEND_DIR%
  echo Create the structure or edit BACKEND_DIR in this script.
  exit /b 1
)

IF NOT EXIST "%FLUTTER_DIR%" (
  echo [ERROR] Flutter dir not found: %FLUTTER_DIR%
  echo Create the structure or edit FLUTTER_DIR in this script.
  exit /b 1
)

REM --- Check Python ---
where python >nul 2>nul
IF ERRORLEVEL 1 (
  echo [ERROR] Python not found on PATH.
  echo Install Python 3.11+ and re-run.
  exit /b 1
)

REM --- Set up venv & install backend requirements ---
pushd "%BACKEND_DIR%"
if not exist .venv (
  echo [INFO] Creating Python venv...
  python -m venv .venv
)
call .venv\Scripts\activate.bat
if exist requirements.txt (
  echo [INFO] Installing backend requirements...
  pip install --upgrade pip
  pip install -r requirements.txt
) else (
  echo [WARN] requirements.txt not found. Using minimal default set.
  pip install fastapi uvicorn[standard] pydantic python-dotenv soundfile numpy
)

REM --- Start backend (new window) ---
echo [INFO] Launching backend on http://127.0.0.1:8000
start "Neura API" cmd /k "cd /d %CD% & uvicorn main:app --host 127.0.0.1 --port 8000 --reload"

popd

REM --- Check Flutter ---
where flutter >nul 2>nul
IF ERRORLEVEL 1 (
  echo [ERROR] Flutter not found on PATH.
  echo Install Flutter and run: flutter doctor
  exit /b 1
)

REM --- Flutter get & run ---
pushd "%FLUTTER_DIR%"
echo [INFO] Running flutter pub get...
flutter pub get

echo.
echo [INFO] Starting Flutter app (Windows desktop if available, else Chrome)
for /f "delims=" %%i in ('flutter devices') do (
  echo %%i | findstr /i "windows" >nul && set DEVICE=windows
)

if defined DEVICE (
  echo [INFO] Detected Windows device. Launching...
  flutter run -d windows
) else (
  echo [INFO] Launching in Chrome...
  flutter run -d chrome
)

popd
echo [DONE] Smoke test complete.
