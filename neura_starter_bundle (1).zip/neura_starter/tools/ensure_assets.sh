#!/usr/bin/env bash
set -euo pipefail

# Creates missing asset directories so pubspec asset paths won't fail.
A_ROOT="neura_companion/flutter_ui/assets"
mkdir -p "$A_ROOT/audio/voices"          "$A_ROOT/lottie"          "$A_ROOT/visemes"          "$A_ROOT/unity_webgl/Build"          "$A_ROOT/unity_webgl/StreamingAssets"          "$A_ROOT/images"

# Touch placeholder files so Flutter can package folders cleanly
touch "$A_ROOT/audio/voices/.keep"
touch "$A_ROOT/lottie/.keep"
touch "$A_ROOT/visemes/.keep"
touch "$A_ROOT/unity_webgl/Build/.keep"
touch "$A_ROOT/unity_webgl/StreamingAssets/.keep"
touch "$A_ROOT/images/.keep"

echo "[ensure_assets] Verified asset tree under $A_ROOT"
