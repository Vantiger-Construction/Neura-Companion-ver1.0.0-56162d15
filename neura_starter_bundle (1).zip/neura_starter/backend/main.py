import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv()

def _origins():
    raw = os.getenv("ALLOWED_ORIGINS", "")
    vals = [v.strip() for v in raw.split(",") if v.strip()]
    return vals if vals else ["*"]

app = FastAPI(title="Neura Companion API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
from routers.health import router as health_router  # noqa: E402
app.include_router(health_router)
