Neura Companion — Minimal Runnable Starter Drop
===============================================

What this contains
------------------
- backend/requirements.txt            → baseline deps for FastAPI
- backend/.env.example                → copy to backend/.env and fill keys
- backend/routers/health.py           → adds GET /health (returns {"ok": true})
- backend/main.py                     → minimal FastAPI app with CORS + health router
- flutter_ui/pubspec_assets_snippet.yaml → paste into your pubspec.yaml under `flutter:`
- flutter_ui/.env.example             → copy to flutter_ui/.env
- smoke_test.bat                      → Windows one-click: start API + run Flutter

Quick start
-----------
1) Copy this whole folder into your repo root (or merge files into the matching places).
2) Duplicate `.env.example` → `.env` in both backend/ and flutter_ui/ and edit values.
3) From repo root, run: `smoke_test.bat`
   - Opens API on http://127.0.0.1:8000
   - Launches Flutter on Windows (or Chrome fallback)

Notes
-----
- If you already have a backend `main.py`, you can import the router instead:
    from routers.health import router as health_router
    app.include_router(health_router)

- Ensure your pubspec has the asset paths you actually use.
- Android builds need INTERNET + RECORD_AUDIO permissions in AndroidManifest.xml.
