#!/usr/bin/env bash
set -euo pipefail

# === Neura Companion Smoke Test (macOS/Linux) ===
# Place at repo root and run: bash smoke_test.sh
# Starts FastAPI backend and launches Flutter (Linux/macOS/Chrome).

BACKEND_DIR="neura_companion/backend"
FLUTTER_DIR="neura_companion/flutter_ui"

red()   { printf "\033[31m%s\033[0m\n" "$*"; }
green() { printf "\033[32m%s\033[0m\n" "$*"; }
yellow(){ printf "\033[33m%s\033[0m\n" "$*"; }

if [[ ! -d "$BACKEND_DIR" ]]; then
  red "[ERROR] Backend dir not found: $BACKEND_DIR"
  exit 1
fi

if [[ ! -d "$FLUTTER_DIR" ]]; then
  red "[ERROR] Flutter dir not found: $FLUTTER_DIR"
  exit 1
fi

# Ensure asset folders exist to avoid pubspec asset errors
bash ./tools/ensure_assets.sh || true

# --- Python/venv ---
if ! command -v python3 >/dev/null 2>&1; then
  red "[ERROR] python3 not found. Install Python 3.11+ and retry."
  exit 1
fi

pushd "$BACKEND_DIR" >/dev/null

if [[ ! -d ".venv" ]]; then
  green "[INFO] Creating Python venv..."
  python3 -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate

if [[ -f "requirements.txt" ]]; then
  green "[INFO] Installing backend requirements..."
  pip install --upgrade pip
  pip install -r requirements.txt
else
  yellow "[WARN] requirements.txt not found. Installing minimal baseline..."
  pip install fastapi 'uvicorn[standard]' pydantic python-dotenv soundfile numpy
fi

green "[INFO] Launching backend at http://127.0.0.1:8000"
# Start in background
uvicorn main:app --host 127.0.0.1 --port 8000 --reload &
API_PID=$!
popd >/dev/null

# --- Flutter ---
if ! command -v flutter >/dev/null 2>&1; then
  red "[ERROR] Flutter not found. Install Flutter and run flutter doctor."
  kill $API_PID || true
  exit 1
fi

pushd "$FLUTTER_DIR" >/dev/null
green "[INFO] flutter pub get..."
flutter pub get

DEVICE=""
if flutter devices | grep -qi "macos"; then
  DEVICE="macos"
elif flutter devices | grep -qi "linux"; then
  DEVICE="linux"
elif flutter devices | grep -qi "chrome"; then
  DEVICE="chrome"
fi

if [[ -z "$DEVICE" ]]; then
  yellow "[WARN] No desktop/web device detected; defaulting to Chrome."
  DEVICE="chrome"
fi

green "[INFO] Launching Flutter on: $DEVICE"
flutter run -d "$DEVICE"

# Cleanup backend when Flutter exits
kill $API_PID || true
popd >/dev/null

green "[DONE] Smoke test finished."
