#!/bin/bash
# Neura Companion GitHub Pages Deployment Script
REPO_URL="git@github.com:Vantiger1/Neura-Companion-ver1.0.0-56162d14.git"
DEPLOY_BRANCH="gh-pages"
LOCAL_DIR="$(pwd)"

git init
git remote add origin $REPO_URL || true
git checkout -B $DEPLOY_BRANCH
git add .
git commit -m "Deploy Neura Companion Microsite update with AI error handling and preload"
git push -f origin $DEPLOY_BRANCH

echo "✅ Deployed to GitHub Pages on branch $DEPLOY_BRANCH"
