# API Reference

(Define all endpoints, params, and usage here as you build)
