# Upgrade Protocol

Define the protocol for action/talent/outfit upgrades here.
