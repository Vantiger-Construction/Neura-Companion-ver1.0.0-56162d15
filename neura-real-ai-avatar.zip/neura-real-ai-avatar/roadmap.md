
# Roadmap

**Phase 1 (Now):**
- Repo structure, documentation, and project vision
- Neura base 3D model, texture, and basic animation set
- Unity project and Bit AI action API prototype

**Phase 2:**
- Behavior/Emotion tree integration
- User data pipeline (personalization, mood/ritual mapping)
- Upgrade protocol for new gestures, outfits, skills

**Phase 3:**
- Cross-platform deployment (Flutter, Web, AR/VR)
- Talent/action store and self-upgrading logic
- Public demo and first customer integrations

**Phase 4:**
- Advanced emotion/gesture AI, real-time voice/face sync
- AR/VR smart home integration, holographic demo
- Licensing, partnerships, and global rollout
