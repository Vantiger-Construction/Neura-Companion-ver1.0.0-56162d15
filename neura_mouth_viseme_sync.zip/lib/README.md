
# Neura Mouth Viseme Sync

Visually syncs Neura's mouth to voice using image frames for visemes:
- `viseme_0_rest.png`
- `viseme_1_a_e.png`
- `viseme_2_o_u.png`
- `viseme_3_m.png`
- `viseme_4_l.png`

Drop into your widget tree inside a Stack:

```
Stack(
  children: [
    NeuraAnimationEngine(emotion: emotion),
    MouthVisemeController(speaking: isSpeaking),
  ],
)
```

Requires:
- Set speaking = true during TTS
- Image assets in /assets
