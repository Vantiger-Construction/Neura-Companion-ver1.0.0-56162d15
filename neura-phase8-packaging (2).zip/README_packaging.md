# Packaging & Distribution

## Electron Desktop App
Package Neura Portal into a desktop app.

```bash
cd electron-app
npm install
npm run package
```

## CLI Tool
Install and use the Neura CLI.

```bash
cd cli-tool
pip install -e .
neura status
```

## Helm Chart Repository
Deploy Neura via Helm:

```bash
helm repo add neura https://your-repo-url/charts
helm install neura-api neura/neura-api
```
