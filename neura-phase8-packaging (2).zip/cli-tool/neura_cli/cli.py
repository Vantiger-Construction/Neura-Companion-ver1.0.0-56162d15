import requests, sys

API_URL = "https://api.neura.app"

def main():
    if len(sys.argv) < 2:
        print("Usage: neura <command>")
        return
    cmd = sys.argv[1]
    if cmd == "status":
        r = requests.get(f"{API_URL}/healthz")
        print(f"API Status: {r.status_code}")
    else:
        print("Unknown command")

if __name__ == "__main__":
    main()
