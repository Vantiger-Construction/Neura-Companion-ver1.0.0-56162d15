from setuptools import setup

setup(
    name='neura-cli',
    version='0.1.0',
    packages=['neura_cli'],
    entry_points={'console_scripts': ['neura=neura_cli.cli:main']},
    install_requires=['requests']
)
