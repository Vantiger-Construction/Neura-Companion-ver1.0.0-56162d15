from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import List, Optional
from src.pagination import paginate_list
from slowapi import limiter

router = APIRouter()
_resources = [{"id": str(i), "name": f"Resource {i}"} for i in range(1,101)]

class Resource(BaseModel):
    id: str
    name: str

class PageInfo(BaseModel):
    nextCursor: Optional[str]
    prevCursor: Optional[str]

class PaginatedResources(BaseModel):
    items: List[Resource]
    pageInfo: PageInfo

@router.get("/", response_model=PaginatedResources)
@limiter.limit("100/minute")
async def list_resources(cursor: Optional[str] = None, limit: int = 50, token: str = Depends()):
    return paginate_list(_resources, cursor, limit)
