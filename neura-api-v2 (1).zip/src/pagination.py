def paginate_list(items, cursor=None, limit=50):
    start = int(cursor) if cursor else 0
    end = start + limit
    return {
        "items": items[start:end],
        "pageInfo": {
            "nextCursor": str(end) if end < len(items) else None,
            "prevCursor": str(start-limit) if start-limit >= 0 else None
        }
    }
