import hmac
import hashlib
import os
import time

def sign_payload(secret: str, payload: bytes, algorithm: str = 'sha256') -> str:
    hash_func = getattr(hashlib, algorithm)
    return hmac.new(secret.encode(), payload, hash_func).hexdigest()

def verify_replay(timestamp: str, window: int = 300) -> bool:
    try:
        ts = int(timestamp)
    except ValueError:
        return False
    return abs(time.time() - ts) <= window
