from fastapi import HTTPException

error_catalog = {
    "SUB_NOT_FOUND": {"status": 404, "message": "Subscription not found"},
    "HISTORY_NOT_FOUND": {"status": 404, "message": "History not found"},
    "INVALID_SIGNATURE": {"status": 401, "message": "Signature verification failed"},
    "RATE_LIMIT": {"status": 429, "message": "Too Many Requests"},
    "AUTH_FAILURE": {"status": 401, "message": "Authentication Failed"}
}
