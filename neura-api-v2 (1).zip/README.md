# Neura API v2

Authenticate:
```bash
curl -X POST /v1/auth/token -d "username=alice&password=secret"
```

List Subscriptions:
```bash
curl -H "Authorization: Bearer $TOKEN" GET /v1/webhooks/subscriptions
```

Unsubscribe:
```bash
curl -X DELETE -H "Authorization: Bearer $TOKEN" /v1/webhooks/subscriptions/sub123
```

Receive Event:
```bash
curl -X POST /v1/webhooks/receive -H "X-Timestamp: $(date +%s)" -H "X-Signature: $SIG" -d '{"foo":"bar"}'
```
