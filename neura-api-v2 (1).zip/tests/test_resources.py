from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_resources_default():
    resp = client.get("/v1/resources")
    assert resp.status_code == 200
    assert len(resp.json()["items"]) == 50
