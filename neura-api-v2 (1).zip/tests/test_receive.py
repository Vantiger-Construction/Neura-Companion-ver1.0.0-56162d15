import hmac, hashlib, time
from fastapi.testclient import TestClient
import os

from src.main import app
client = TestClient(app)

def test_receive_success(monkeypatch):
    secret = "secretkey"
    monkeypatch.setenv("WEBHOOK_SECRET", secret)
    body = b'{"foo":"bar"}'
    ts = str(int(time.time()))
    sig = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    resp = client.post("/v1/webhooks/receive", data=body, headers={"X-Timestamp":ts,"X-Signature":sig})
    assert resp.status_code == 200
