from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_history_404():
    resp = client.get("/v1/webhooks/subscriptions/nonexist/history")
    assert resp.status_code == 404
