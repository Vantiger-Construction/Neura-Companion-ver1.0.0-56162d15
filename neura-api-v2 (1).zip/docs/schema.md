# Neura API v2 Schema

## Subscription Management

- POST /v1/webhooks/subscribe
- GET /v1/webhooks/subscriptions
- DELETE /v1/webhooks/subscriptions/{id}
- GET /v1/webhooks/subscriptions/{id}/history
