import 'package:flutter/material.dart';
import '../../lib/widgets/NeuraVisemeFace.dart';
import '../../lib/widgets/NeuraEyeOverlay.dart';
import '../../lib/engine/NeuraVoiceSyncEngine.dart';

class NeuraLiveTestScreen extends StatelessWidget {
  const NeuraLiveTestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final mood = 'happy';

    return Scaffold(
      appBar: AppBar(title: Text("Neura Live Face + Voice Test")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                NeuraVisemeFace(),
                NeuraEyeOverlay(mood: mood),
              ],
            ),
            ElevatedButton(
              onPressed: () {
                NeuraVoiceSyncEngine.instance.speak(
                    "This is a full system sync test. Hello, world!", context);
              },
              child: Text("Run Test"),
            )
          ],
        ),
      ),
    );
  }
}