import 'package:flutter/material.dart';

class DreamCalendarScreen extends StatelessWidget {
  const DreamCalendarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Dream Calendar')),
      body: GridView.builder(
        padding: EdgeInsets.all(12),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
        itemCount: 30,
        itemBuilder: (context, index) {
          return Card(
            child: Center(child: Text("Day ${index + 1}")),
          );
        },
      ),
    );
  }
}