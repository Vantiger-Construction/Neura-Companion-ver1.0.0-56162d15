import 'package:flutter/material.dart';
import '../engine/NeuraVoiceSyncEngine.dart';

class DreamNarratorWidget extends StatelessWidget {
  final String dreamText;

  const DreamNarratorWidget({super.key, required this.dreamText});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ElevatedButton(
          onPressed: () {
            NeuraVoiceSyncEngine.instance.speak(dreamText, context);
          },
          child: Text("Narrate Dream"),
        )
      ],
    );
  }
}