import 'package:flutter/material.dart';

class NeuraAnimatorWidget extends StatefulWidget {
  final Widget child;
  const NeuraAnimatorWidget({super.key, required this.child});

  @override
  State<NeuraAnimatorWidget> createState() => _NeuraAnimatorWidgetState();
}

class _NeuraAnimatorWidgetState extends State<NeuraAnimatorWidget> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: Duration(seconds: 2))
      ..repeat(reverse: true);
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween(begin: 0.8, end: 1.0).animate(_controller),
      child: widget.child,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}