class NeuraPersona {
  String dominantTrait = "playful";

  String generateReplyTone(String mood) {
    if (mood == 'happy' && dominantTrait == 'playful') return 'cheerful';
    if (mood == 'sad' && dominantTrait == 'loyal') return 'gentle';
    return 'neutral';
  }
}