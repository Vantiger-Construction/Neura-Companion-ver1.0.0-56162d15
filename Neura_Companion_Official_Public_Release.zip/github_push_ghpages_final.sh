
#!/bin/bash
# Final GitHub Pages Deployment Script for Neura Companion

echo "📁 Cloning repository..."
git clone https://github.com/Vantiger1/Neura-Companion-ver1.0.0-56162d14.git
cd Neura-Companion-ver1.0.0-56162d14

echo "📄 Copying press site index.html..."
cp ../index.html .

git checkout -B gh-pages
git add index.html
git commit -m "🌐 Deploy Neura Press Site to GitHub Pages"
git push origin gh-pages --force

echo "✅ GitHub Pages deployment complete!"
