const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.voiceAssistantHook = functions.https.onRequest(async (req, res) => {
  const intent = req.body.intent || "";
  const uid = req.body.uid || null;
  const mood = req.body.mood || "";
  const ritual = req.body.ritual || "";

  if (!uid) {
    res.status(400).send("Missing user ID.");
    return;
  }

  const db = admin.firestore();

  if (intent === "logMood") {
    await db.collection("moods").add({
      uid,
      mood,
      timestamp: new Date(),
      source: "voice",
    });
    res.json({ speech: `Mood "${mood}" logged successfully.` });
  } else if (intent === "logRitual") {
    await db.collection("ritual_checkins").add({
      uid,
      mood: "n/a",
      motivation: "n/a",
      timestamp: new Date(),
      source: "voice",
      label: ritual,
    });
    res.json({ speech: `Ritual "${ritual}" marked as done.` });
  } else if (intent === "getSummary") {
    const ref = db.collection("moods").where("uid", "==", uid).orderBy("timestamp", "desc").limit(5);
    const snap = await ref.get();
    const moods = snap.docs.map(d => d.data().mood);
    const summary = moods.join(", ");
    res.json({ speech: `Your last moods were: ${summary}` });
  } else {
    res.json({ speech: "Intent not recognized." });
  }
});