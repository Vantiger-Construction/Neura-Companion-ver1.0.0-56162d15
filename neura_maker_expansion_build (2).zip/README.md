
# Neura Companion - Maker Expansion Build

✅ Voice reactive widget (stub)  
✅ Room navigation: Reflection Bay, Joy Lounge, Mood Den  
✅ Ready for Maker voice sample integration  
✅ Randomized mood triggers (ambient, time, convo-based)

## To Run:
flutter pub get  
flutter run lib/main.dart
