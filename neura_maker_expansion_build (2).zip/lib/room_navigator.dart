
import 'package:flutter/material.dart';

class RoomNavigator extends StatefulWidget {
  const RoomNavigator({super.key});

  @override
  State<RoomNavigator> createState() => _RoomNavigatorState();
}

class _RoomNavigatorState extends State<RoomNavigator> {
  int _currentIndex = 0;

  final List<Widget> _rooms = [
    const Center(child: Text("Reflection Bay")),
    const Center(child: Text("Joy Lounge")),
    const Center(child: Text("Mood Den")),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Neura Room Nav')),
      body: _rooms[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.book), label: 'Reflect'),
          BottomNavigationBarItem(icon: Icon(Icons.music_note), label: 'Joy'),
          BottomNavigationBarItem(icon: Icon(Icons.cloud), label: 'Mood'),
        ],
      ),
    );
  }
}
