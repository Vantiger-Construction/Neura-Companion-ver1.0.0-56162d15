// Hook for Maker voice input and future TTS
