
import 'package:flutter/material.dart';
import 'neura_voice_reactive_widget.dart';
import 'room_navigator.dart';
import 'neura_persona.dart';
import 'maker_voice_engine.dart';

void main() {
  runApp(const NeuraMakerApp());
}

class NeuraMakerApp extends StatelessWidget {
  const NeuraMakerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion - Maker Mode',
      theme: ThemeData.dark(),
      home: const RoomNavigator(),
    );
  }
}
