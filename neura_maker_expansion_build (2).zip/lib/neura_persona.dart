// Personality traits + mood logic placeholder
