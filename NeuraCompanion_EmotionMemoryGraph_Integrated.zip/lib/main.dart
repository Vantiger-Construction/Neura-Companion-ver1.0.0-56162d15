
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'modules/mood/mood_log.dart';
import 'modules/journal/journal_screen.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => MoodLog(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: JournalScreen(),
    );
  }
}
