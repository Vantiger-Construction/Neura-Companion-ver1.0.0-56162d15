"""create initial tables

Revision ID: 0001_create_tables
Revises: 
Create Date: 2025-07-29 00:00:00.000000

"""

from alembic import op
import sqlalchemy as sa
from src.models import SQLModel

# revision identifiers, used by Alembic.
revision = '0001_create_tables'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    bind = op.get_bind()
    SQLModel.metadata.create_all(bind=bind)

def downgrade():
    bind = op.get_bind()
    SQLModel.metadata.drop_all(bind=bind)
