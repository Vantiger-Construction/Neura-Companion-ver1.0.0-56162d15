"""Webhook management and event handling with persistence"""

import os
import hmac
import datetime
import httpx
from fastapi import APIRouter, Request, HTTPException, Depends
from sqlmodel import select
from src.security import verify_replay, sign_payload
from src.db import get_session
from src.models import Subscription, DeliveryRecord
from slowapi import limiter

router = APIRouter()

@router.post("/subscribe")
@limiter.limit("50/minute")
def subscribe(body: dict, session=Depends(get_session)):
    sub = Subscription(url=body["url"], eventType=body["eventType"])
    session.add(sub); session.commit(); session.refresh(sub)
    return sub

@router.get("/subscriptions")
@limiter.limit("50/minute")
def list_subscriptions(session=Depends(get_session)):
    subs = session.exec(select(Subscription)).all()
    return subs

@router.delete("/subscriptions/{id}", status_code=204)
@limiter.limit("20/minute")
def unsubscribe(id: int, session=Depends(get_session)):
    sub = session.get(Subscription, id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    session.delete(sub); session.commit()

@router.get("/subscriptions/{id}/history")
@limiter.limit("50/minute")
def get_history(id: int, session=Depends(get_session)):
    sub = session.get(Subscription, id)
    if not sub:
        raise HTTPException(status_code=404, detail="History not found")
    history = session.exec(select(DeliveryRecord).where(DeliveryRecord.subscription_id == id)).all()
    return history

@router.post("/receive")
@limiter.limit("100/minute")
async def receive_event(request: Request, session=Depends(get_session)):
    ts = request.headers.get("X-Timestamp")
    sig = request.headers.get("X-Signature")
    body = await request.body()
    if not ts or not sig or not verify_replay(ts):
        raise HTTPException(status_code=400, detail="Invalid or missing signature/timestamp")
    expected = sign_payload(os.getenv("WEBHOOK_SECRET", "secretkey"), body)
    if not hmac.compare_digest(expected, sig):
        raise HTTPException(status_code=401, detail="Signature verification failed")
    event = await request.json()
    subs = session.exec(select(Subscription)).all()
    results = []
    for sub in subs:
        try:
            resp = await httpx.post(sub.url, json=event)
            code = resp.status_code
        except:
            code = 500
        record = DeliveryRecord(timestamp=datetime.datetime.utcnow(), statusCode=code, subscription_id=sub.id)
        session.add(record); session.commit()
        results.append({"id": sub.id, "status": code})
    return {"dispatched": results}

@router.post("/legacy")
@limiter.limit("30/minute")
def legacy_trigger(body: dict, session=Depends(get_session)):
    event = {"type": body.get("legacyEventName"), **body.get("payload", {})}
    subs = session.exec(select(Subscription)).all()
    results = []
    for sub in subs:
        try:
            resp = httpx.post(sub.url, json=event)
            code = resp.status_code
        except:
            code = 500
        record = DeliveryRecord(timestamp=datetime.datetime.utcnow(), statusCode=code, subscription_id=sub.id)
        session.add(record); session.commit()
        results.append({"id": sub.id, "status": code})
    return {"dispatched": results}
