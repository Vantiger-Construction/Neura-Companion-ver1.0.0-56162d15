"""Resource listing with database-backed storage"""

from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import select
from src.models import Resource
from src.db import get_session
from src.pagination import paginate_list
from slowapi import limiter

router = APIRouter()

@router.get("/", response_model=list[Resource])
@limiter.limit("100/minute")
def list_resources(cursor: int = 0, limit: int = 50, session=Depends(get_session)):
    offset = cursor
    resources = session.exec(select(Resource).offset(offset).limit(limit)).all()
    next_cursor = offset + limit if len(resources) == limit else None
    return resources
