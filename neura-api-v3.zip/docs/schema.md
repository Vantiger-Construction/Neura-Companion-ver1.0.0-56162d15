# Neura API v3 Schema

## Resources
- GET /v1/resources?cursor=0&limit=50

## Subscriptions
- POST /v1/webhooks/subscribe
- GET /v1/webhooks/subscriptions
- DELETE /v1/webhooks/subscriptions/{id}
- GET /v1/webhooks/subscriptions/{id}/history

## Events
- POST /v1/webhooks/receive
- POST /v1/webhooks/legacy
