from fastapi.testclient import TestClient
from src.main import app
from src.db import engine
from src.models import SQLModel

client = TestClient(app)

def test_db_tables_created():
    # Ensure tables exist by reflecting metadata
    SQLModel.metadata.create_all(engine)
    # If no errors, pass
    assert True

def test_subscribe_persistence():
    resp = client.post("/v1/webhooks/subscribe", json={"url":"http://x","eventType":"foo"})
    assert resp.status_code == 200
    data = resp.json()
    assert "id" in data

def test_history_after_receive(monkeypatch):
    # Setup subscription
    resp = client.post("/v1/webhooks/subscribe", json={"url":"http://x","eventType":"foo"})
    sub_id = resp.json()["id"]
    # Simulate event receive
    import hmac, hashlib, time
    secret = "secretkey"
    monkeypatch.setenv("WEBHOOK_SECRET", secret)
    body = b'{"foo":"bar"}'
    ts = str(int(time.time()))
    sig = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    client.post("/v1/webhooks/receive", data=body, headers={"X-Timestamp":ts,"X-Signature":sig})
    # Check history
    history_resp = client.get(f"/v1/webhooks/subscriptions/{sub_id}/history")
    assert history_resp.status_code == 200
    assert isinstance(history_resp.json(), list)
