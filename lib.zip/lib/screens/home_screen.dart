// Full home_screen.dart with navigation grid
