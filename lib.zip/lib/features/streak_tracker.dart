// Full Streak Tracker implementation
