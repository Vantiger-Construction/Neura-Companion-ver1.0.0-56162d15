// Full AI Companion implementation
