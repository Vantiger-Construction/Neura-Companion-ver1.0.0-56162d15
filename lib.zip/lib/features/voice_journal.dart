// Full Voice Journal implementation
