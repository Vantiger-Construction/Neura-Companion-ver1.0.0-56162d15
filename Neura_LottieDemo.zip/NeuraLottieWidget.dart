import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class NeuraLottieWidget extends StatelessWidget {
  const NeuraLottieWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Neura Lottie Demo")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.asset('animations/face_blink.json'),
            Lottie.asset('animations/mouth_speak_loop.json'),
            Lottie.asset('animations/glow_pulse.json'),
          ],
        ),
      ),
    );
  }
}