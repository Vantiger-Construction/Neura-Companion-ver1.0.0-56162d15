
class RitualCuratorController {
  List<Map<String, String>> generateQuests() {
    return [
      {
        "title": "⚡ Ignite Motivation",
        "description": "Start your morning with a 5-min stretch and set 1 key goal for today."
      },
      {
        "title": "🧘 Mindful Reset",
        "description": "Take 10 minutes to meditate, then journal one thing you're grateful for."
      },
      {
        "title": "🔥 Energy Reboot",
        "description": "Go for a brisk walk and hydrate. Your body fuels your mind."
      },
    ];
  }
}
