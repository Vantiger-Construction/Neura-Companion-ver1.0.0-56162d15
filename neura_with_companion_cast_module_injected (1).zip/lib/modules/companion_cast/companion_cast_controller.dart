
class CompanionCastController {
  List<Map<String, String>> getCast() {
    return [
      {
        "name": "Neura",
        "emoji": "🤖",
        "personality": "Warm, nurturing, intuitive AI companion."
      },
      {
        "name": "Neuro",
        "emoji": "🧠",
        "personality": "Logical, focused, goal-driven motivator."
      },
      {
        "name": "Luma",
        "emoji": "🌟",
        "personality": "Dreamy, creative, supports vision-building."
      }
    ];
  }
}
