
class RitualPortalController {
  Map<String, String> getPortalAssets(String mood) {
    final assets = {
      "focus": "assets/lottie/portal_focus.json",
      "relax": "assets/lottie/portal_relax.json",
      "joy": "assets/lottie/portal_joy.json",
    };
    return {"animation": assets[mood] ?? assets["focus"]!};
  }
}
