Place your Unity WebGL exported 'Build' folder next to this index.html file.
Then open index.html in a browser to view the Neura VR WebGL preview.