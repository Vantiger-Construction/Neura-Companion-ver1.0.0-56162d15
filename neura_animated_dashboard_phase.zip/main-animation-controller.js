// JS: Neura room transition + idle state handler
