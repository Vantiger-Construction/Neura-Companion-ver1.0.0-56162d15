@echo off
REM --- Neura Companion Launch Blast Batch File ---

REM Top investors (email and LinkedIn)
start "" "https://mail.google.com/mail/?view=cm&fs=1&to=howard@bcapgroup.com&su=Introducing%20Neura%20Companion:%20AI%20Wellness%20Platform&body=Hi%20Howard%2C%0D%0A%0D%0AI%E2%80%99m%20contacting%20you%20on%20behalf%20of%20Neura%20Team%20about%20our%20AI-powered%20wellness%20platform%20in%20stealth.%20We%E2%80%99d%20love%20to%20share%20a%20deck%2C%20demo%2C%20and%20see%20if%20you%20might%20help%20fuel%20our%20next%20stage.%0D%0A%0D%0ASee%20attached%20for%20details.%20Please%20reply%20to%20neuracompanion@gmail.com.%0D%0A%0D%0ABest%2C%0D%0ANeura%20Team"
start "" "https://www.linkedin.com/in/howard-morgan-417/"

REM Gaingels main contact
start "" "https://www.gaingels.com/contact"
REM Patron VC
start "" "https://www.patron.xyz/contact"

REM Growth Hackers (contact page)
start "" "https://growthhackers.com/contact"
REM Activated Scale
start "" "https://www.activatedscale.com/contact"
REM Sales Talent Agency
start "" "https://www.salestalentagency.com/contact-us"

REM Upwork to post BDR/agent job
start "" "https://www.upwork.com/hire/corporate-and-business-development-freelancers/us/"

REM Product Hunt Upcoming
start "" "https://www.producthunt.com/upcoming"
REM Betalist
start "" "https://betalist.com/submit"
REM Indie Hackers
start "" "https://www.indiehackers.com/startups"
REM Hacker News Show
start "" "https://news.ycombinator.com/submitlink"

REM Reddit startup and SaaS subs
start "" "https://www.reddit.com/r/startups/submit"
start "" "https://www.reddit.com/r/SaaS/submit"
REM Twitter sign-up (brand account)
start "" "https://twitter.com/i/flow/signup"
REM LinkedIn create company page
start "" "https://www.linkedin.com/company/setup/new/"

REM Pause for user
echo.
echo All major investor, agent, and PR/contact windows are open!
echo Paste your prepared Neura Team email/post in each.
pause
