@echo off
SETLOCAL

echo ===================================================
echo        Neura Companion Windows Installer
echo ===================================================
echo.

REM --- Change to your project directory ---
cd /d "Z:\Neura Companion\Neura-Companion"

REM --- Download Flutter dependencies ---
echo Running: flutter pub get
flutter pub get
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Flutter pub get failed. Please check your Flutter installation.
    pause
    exit /b
)

REM --- Build Windows app ---
echo Running: flutter build windows
flutter build windows
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Flutter build failed. Please check your Flutter setup and try again.
    pause
    exit /b
)

REM --- Define install location ---
SET TARGET="C:\Program Files\Neura Companion"

REM --- Create target folder if it doesn't exist ---
IF NOT EXIST %TARGET% (
    mkdir %TARGET%
)

REM --- Copy built files to Program Files ---
echo Copying build output to %TARGET%
xcopy /y /e "build\windows\runner\Release\*" %TARGET%\

REM --- (Optional) Create Desktop Shortcut ---
SET SHORTCUT="%USERPROFILE%\Desktop\Neura Companion.lnk"
SET EXEPATH=%TARGET%\Neura Companion.exe

if exist %EXEPATH% (
    echo Creating desktop shortcut...
    powershell "$s=(New-Object -COM WScript.Shell).CreateShortcut('%SHORTCUT%');$s.TargetPath='%EXEPATH%';$s.Save()"
) else (
    echo [WARNING] App exe not found at %EXEPATH%. Shortcut not created.
)

echo.
echo ===================================================
echo   Installation complete!
echo   You can launch Neura Companion from:
echo   %TARGET%
echo.
echo   A desktop shortcut was created if possible.
echo ===================================================
pause

ENDLOCAL
