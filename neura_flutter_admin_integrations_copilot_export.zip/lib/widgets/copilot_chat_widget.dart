import 'package:flutter/material.dart';
import '../api.dart';

class CopilotChatWidget extends StatefulWidget {
  @override
  _CopilotChatWidgetState createState() => _CopilotChatWidgetState();
}

class _CopilotChatWidgetState extends State<CopilotChatWidget> {
  final _ctrl = TextEditingController();
  final List<String> _history = [];
  bool _loading = false;

  void _askCopilot() async {
    setState(() { _loading = true; });
    final resp = await NeuraApi.askCopilot(_ctrl.text);
    setState(() {
      _history.add("You: " + _ctrl.text);
      _history.add("Copilot: " + resp);
      _ctrl.clear();
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView(
            children: _history.map((line) => Padding(
              padding: EdgeInsets.all(4),
              child: Text(line),
            )).toList(),
          ),
        ),
        Row(
          children: [
            Expanded(child: TextField(controller: _ctrl, decoration: InputDecoration(labelText: "Ask anything..."))),
            _loading
                ? CircularProgressIndicator()
                : IconButton(icon: Icon(Icons.send), onPressed: _askCopilot)
          ],
        )
      ],
    );
  }
}
