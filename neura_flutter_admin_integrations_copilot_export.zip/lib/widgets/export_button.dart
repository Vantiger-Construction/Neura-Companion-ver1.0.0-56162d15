import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ExportButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      icon: Icon(Icons.download),
      label: Text("Download Mood CSV"),
      onPressed: () {
        launchUrl(Uri.parse("http://localhost:8000/api/v1/export/moods/csv"));
      },
    );
  }
}
