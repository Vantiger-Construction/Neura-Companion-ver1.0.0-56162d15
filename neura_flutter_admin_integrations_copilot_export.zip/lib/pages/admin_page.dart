import 'package:flutter/material.dart';

class AdminPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // In a real app, pull user/team list from backend
    return Scaffold(
      appBar: AppBar(title: Text("Admin Panel")),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(padding: EdgeInsets.all(12), child: Text("Users & Teams", style: TextStyle(fontWeight: FontWeight.bold))),
          ListTile(title: Text("tigger"), subtitle: Text("Admin")),
          ListTile(title: Text("demo"), subtitle: Text("User")),
          Padding(padding: EdgeInsets.all(12), child: Text("System Info", style: TextStyle(fontWeight: FontWeight.bold))),
          ListTile(title: Text("Version: 1.0.0")),
          ListTile(title: Text("Org: Neura HQ")),
        ],
      ),
    );
  }
}
