import 'package:flutter/material.dart';
import '../widgets/copilot_chat_widget.dart';

class CopilotPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("AI Copilot")),
      body: CopilotChatWidget(),
    );
  }
}
