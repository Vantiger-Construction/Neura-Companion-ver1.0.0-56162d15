import 'package:flutter/material.dart';
import '../widgets/export_button.dart';

class ExportPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Export Data")),
      body: Center(
        child: ExportButton(),
      ),
    );
  }
}
