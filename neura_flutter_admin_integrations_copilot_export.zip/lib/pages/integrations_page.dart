import 'package:flutter/material.dart';
import '../api.dart';

class IntegrationsPage extends StatelessWidget {
  final _slackCtrl = TextEditingController();
  final _smsPhoneCtrl = TextEditingController();
  final _smsMsgCtrl = TextEditingController();
  final _zapierCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Integrations")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Slack", style: TextStyle(fontWeight: FontWeight.bold)),
            Row(
              children: [
                Expanded(child: TextField(controller: _slackCtrl, decoration: InputDecoration(labelText: "Slack message"))),
                ElevatedButton(onPressed: () => NeuraApi.sendSlack(_slackCtrl.text), child: Text("Send"))
              ],
            ),
            SizedBox(height: 24),
            Text("Zapier", style: TextStyle(fontWeight: FontWeight.bold)),
            Row(
              children: [
                Expanded(child: TextField(controller: _zapierCtrl, decoration: InputDecoration(labelText: "Event text"))),
                ElevatedButton(onPressed: () => NeuraApi.sendZapier(_zapierCtrl.text), child: Text("Send"))
              ],
            ),
            SizedBox(height: 24),
            Text("SMS", style: TextStyle(fontWeight: FontWeight.bold)),
            Row(
              children: [
                Expanded(child: TextField(controller: _smsPhoneCtrl, decoration: InputDecoration(labelText: "Phone"))),
                Expanded(child: TextField(controller: _smsMsgCtrl, decoration: InputDecoration(labelText: "Message"))),
                ElevatedButton(onPressed: () => NeuraApi.sendSms(_smsPhoneCtrl.text, _smsMsgCtrl.text), child: Text("Send"))
              ],
            ),
            SizedBox(height: 32),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/copilot'),
              child: Text("Open AI Copilot Chat"),
            ),
          ],
        ),
      ),
    );
  }
}
