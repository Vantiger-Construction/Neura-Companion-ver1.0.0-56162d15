#!/bin/bash
echo "🚀 Installing Neura Companion WebGL..."
mkdir -p ~/NeuraCompanion
cp -r * ~/NeuraCompanion/
echo "✅ Installed to ~/NeuraCompanion"
