
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      home: FirebaseHomePage(),
    );
  }
}

class FirebaseHomePage extends StatelessWidget {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Firebase Integration')),
      body: Center(
        child: ElevatedButton(
          child: Text("Test Save Mood"),
          onPressed: () async {
            final user = _auth.currentUser;
            if (user != null) {
              await _db.collection("mood_logs").add({
                "uid": user.uid,
                "mood": "happy",
                "timestamp": DateTime.now().toIso8601String()
              });
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text("Mood saved to Firebase"),
              ));
            }
          },
        ),
      ),
    );
  }
}
