Place Unity WebGL Build in 'webvr/Build/' folder.
This template will embed the game using an iframe.