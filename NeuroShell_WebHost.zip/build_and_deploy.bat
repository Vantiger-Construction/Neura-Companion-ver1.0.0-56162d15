@echo off
REM Batch script to build Flutter web and integrate into Android shell project

REM Set paths (modify these as needed)
set FLUTTER_PROJECT_DIR=%~dp0flutter_project
set SHELL_PROJECT_DIR=%~dp0neuroshell_project

echo Building Flutter web...
cd "%FLUTTER_PROJECT_DIR%"
flutter build web

if errorlevel 1 (
  echo Flutter web build failed.
  pause
  exit /b 1
)

echo Copying web build to Android shell project...
xcopy /E /I /Y "%FLUTTER_PROJECT_DIR%\build\web" "%SHELL_PROJECT_DIR%\app\src\main\assets\flutter_web"

echo Building Android shell APK...
cd "%SHELL_PROJECT_DIR%"
call gradlew clean assembleDebug

if errorlevel 1 (
  echo Android build failed.
  pause
  exit /b 1
)

echo Build complete. APK located at:
echo %SHELL_PROJECT_DIR%\app\build\outputs\apk\debug\app-debug.apk
pause
