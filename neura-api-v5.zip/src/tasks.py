import httpx
from celery.exceptions import MaxRetriesExceededError
from celery_app import celery_app
from src.db import get_session
from src.models import DeliveryRecord, Subscription
from datetime import datetime

@celery_app.task(bind=True, max_retries=3)
def dispatch_event(self, subscription_id, event):
    session = next(get_session())
    sub = session.get(Subscription, subscription_id)
    try:
        resp = httpx.post(sub.url, json=event, timeout=10)
        status = resp.status_code
    except Exception as exc:
        try:
            self.retry(exc=exc)
        except MaxRetriesExceededError:
            status = 500
    record = DeliveryRecord(timestamp=datetime.utcnow(), statusCode=status, subscription_id=subscription_id)
    session.add(record)
    session.commit()
    session.close()
