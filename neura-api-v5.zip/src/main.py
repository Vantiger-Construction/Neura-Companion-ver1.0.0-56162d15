from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from src.db import init_db
from src.auth import router as auth_router
from src.resources import router as resources_router
from src.webhooks import router as webhooks_router
from src.rate_limit import init_rate_limiter

app = FastAPI()

# CORS settings
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-frontend.example.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

init_rate_limiter(app)
init_db()

app.include_router(auth_router, prefix="/v1/auth", tags=["auth"])
app.include_router(resources_router, prefix="/v1/resources", tags=["resources"])
app.include_router(webhooks_router, prefix="/v1/webhooks", tags=["webhooks"])

# Health and metrics imports
from src.health import router as health_router
from src.logging_config import configure_logging
from src.metrics import metrics_endpoint, record_metrics

configure_logging()
app.include_router(health_router, include_in_schema=False)
app.add_api_route('/metrics', metrics_endpoint, include_in_schema=False)

# Instrumentation middleware
from time import time
@app.middleware('http')
async def metrics_middleware(request, call_next):
    start = time()
    response = await call_next(request)
    process_time = time() - start
    record_metrics(request.method, request.url.path, str(response.status_code), process_time)
    return response

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
