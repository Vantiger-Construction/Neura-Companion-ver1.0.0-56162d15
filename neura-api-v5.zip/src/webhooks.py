import os
import hmac
import time
import datetime
from fastapi import APIRouter, Request, Depends
from typing import List, Dict, Any
from sqlmodel import select
from src.db import get_session
from src.models import Subscription
from src.schemas import SubscriptionCreate, LegacyTrigger
from src.errors import APIError
from src.tasks import dispatch_event
from slowapi import limiter

router = APIRouter()

@router.post("/subscribe", response_model=Subscription, status_code=201)
@limiter.limit("50/minute")
def subscribe(sub: SubscriptionCreate, session=Depends(get_session)):
    subscription = Subscription(url=sub.url, eventType=sub.eventType)
    session.add(subscription); session.commit(); session.refresh(subscription)
    return subscription

@router.post("/receive", status_code=200)
@limiter.limit("100/minute")
async def receive_event(request: Request, session=Depends(get_session)):
    ts = request.headers.get("X-Timestamp")
    sig = request.headers.get("X-Signature")
    body = await request.body()
    if not ts or not sig or abs(time.time() - int(ts)) > 300:
        raise APIError("INVALID_SIGNATURE")
    expected = hmac.new(os.getenv("WEBHOOK_SECRET","secretkey").encode(), body, getattr(__import__('hashlib'),'sha256')).hexdigest()
    if not hmac.compare_digest(expected, sig):
        raise APIError("INVALID_SIGNATURE")
    event = await request.json()
    subs = session.exec(select(Subscription)).all()
    for sub in subs:
        dispatch_event.delay(sub.id, event)
    return {"dispatched": len(subs)}

@router.post("/legacy", response_model=List[Dict[str,Any]])
@limiter.limit("30/minute")
def legacy_trigger(trigger: LegacyTrigger, session=Depends(get_session)):
    event = {"type": trigger.legacyEventName, **trigger.payload}
    subs = session.exec(select(Subscription)).all()
    for sub in subs:
        dispatch_event.delay(sub.id, event)
    return [{"id": sub.id} for sub in subs]
