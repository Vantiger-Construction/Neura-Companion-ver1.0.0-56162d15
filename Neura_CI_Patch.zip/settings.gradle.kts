// settings.gradle.kts

pluginManagement {
    repositories {
        gradlePluginPortal()
        google()
        mavenCentral()
    }
}

rootProject.name = "Neura-AI-Companion"
include(":app")

// Fix for Flutter plugin loader
val flutterRoot = System.getenv("FLUTTER_ROOT") ?: "/opt/flutter"
includeBuild("$flutterRoot/packages/flutter_tools/gradle")
