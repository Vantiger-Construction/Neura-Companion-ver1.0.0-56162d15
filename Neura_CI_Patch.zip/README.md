This patch adds CI execution permissions and fixes the settings.gradle.kts include.

- .github/workflows/ci.yml: Adds chmod +x for gradlew and Flutter setup.
- settings.gradle.kts: Replaces absolute Windows path with FLUTTER_ROOT-based include.

Apply these changes to your repository before pushing.
