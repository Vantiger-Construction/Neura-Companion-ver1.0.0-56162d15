# Mobile & Third-Party SDKs

## React Native SDK
```bash
cd react-native-sdk
npm install
# Import createNeuraClient from index.js
```

## Flutter Plugin
```bash
cd flutter_sdk
flutter pub get
# Import package: neura_flutter_sdk/neura_flutter_sdk.dart
```

## Go SDK
```bash
cd go-sdk
go mod tidy
# Import github.com/neura/sdk-go
```

## Java SDK
```bash
cd java-sdk
mvn install
# Import com.neura.NeuraClient
```

## PHP SDK
```bash
cd php-sdk
composer install
# Use Neura\Sdk\NeuraClient
```
