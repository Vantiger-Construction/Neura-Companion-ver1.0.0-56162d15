package neura

import (
    "github.com/go-resty/resty/v2"
)

type Client struct {
    rest *resty.Client
}

func NewClient(baseURL, token string) *Client {
    r := resty.New().SetBaseURL(baseURL).SetAuthToken(token)
    return &Client{rest: r}
}

func (c *Client) ListResources(cursor, limit int) (*resty.Response, error) {
    return c.rest.R().SetQueryParams(map[string]string{
        "cursor": fmt.Sprint(cursor),
        "limit":  fmt.Sprint(limit),
    }).Get("/v1/resources")
}

func (c *Client) Subscribe(url, eventType string) (*resty.Response, error) {
    return c.rest.R().SetBody(map[string]string{
        "url":       url,
        "eventType": eventType,
    }).Post("/v1/webhooks/subscribe")
}
