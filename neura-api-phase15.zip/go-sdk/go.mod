module github.com/neura/sdk-go

go 1.18

require (
    github.com/go-resty/resty/v2 v2.7.0
)
