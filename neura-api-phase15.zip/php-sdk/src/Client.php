<?php
namespace Neura\Sdk;

use GuzzleHttp\Client;

class NeuraClient {
    private $client;
    public function __construct($baseUrl, $token) {
        $this->client = new Client([
            'base_uri' => $baseUrl,
            'headers' => ['Authorization' => 'Bearer ' . $token]
        ]);
    }

    public function listResources($cursor = 0, $limit = 50) {
        $response = $this->client->get('/v1/resources', [
            'query' => ['cursor' => $cursor, 'limit' => $limit]
        ]);
        return json_decode($response->getBody(), true);
    }
}
