import 'dart:convert';
import 'package:http/http.dart' as http;

class NeuraClient {
  final String baseUrl;
  final String token;
  NeuraClient(this.baseUrl, this.token);

  Future<Map<String, dynamic>> listResources({int cursor = 0, int limit = 50}) async {
    final res = await http.get(
      Uri.parse('$baseUrl/v1/resources?cursor=$cursor&limit=$limit'),
      headers: {'Authorization': 'Bearer $token'},
    );
    return jsonDecode(res.body);
  }

  Future<Map<String, dynamic>> subscribe(String url, String eventType) async {
    final res = await http.post(
      Uri.parse('$baseUrl/v1/webhooks/subscribe'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'url': url, 'eventType': eventType}),
    );
    return jsonDecode(res.body);
  }
}
