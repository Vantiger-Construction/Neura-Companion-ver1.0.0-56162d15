package com.neura;

import okhttp3.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;

public class NeuraClient {
    private final OkHttpClient client = new OkHttpClient();
    private final String baseUrl;
    private final String token;
    private final ObjectMapper mapper = new ObjectMapper();

    public NeuraClient(String baseUrl, String token) {
        this.baseUrl = baseUrl;
        this.token = token;
    }

    public String listResources(int cursor, int limit) throws IOException {
        HttpUrl url = HttpUrl.parse(baseUrl + "/v1/resources")
            .newBuilder()
            .addQueryParameter("cursor", String.valueOf(cursor))
            .addQueryParameter("limit", String.valueOf(limit))
            .build();
        Request req = new Request.Builder().url(url)
            .header("Authorization", "Bearer " + token).build();
        Response res = client.newCall(req).execute();
        return res.body().string();
    }
}
