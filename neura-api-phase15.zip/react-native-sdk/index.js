import axios from 'axios';

export function createNeuraClient(baseUrl, token) {
  const client = axios.create({
    baseURL: baseUrl,
    headers: { Authorization: `Bearer ${token}` },
  });
  return {
    listResources: (cursor=0, limit=50) => client.get('/v1/resources', { params: { cursor, limit } }),
    subscribe: (url, eventType) => client.post('/v1/webhooks/subscribe', { url, eventType }),
    // Add other methods as needed
  };
}
