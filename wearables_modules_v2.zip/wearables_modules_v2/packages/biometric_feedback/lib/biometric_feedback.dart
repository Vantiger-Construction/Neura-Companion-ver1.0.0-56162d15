library biometric_feedback;

import 'package:health/health.dart';

class BiometricFeedback {
  static final _health = HealthFactory();

  /// Init Health permissions
  static Future<void> init() async {
    final types = [HealthDataType.HEART_RATE, HealthDataType.HEART_RATE_VARIABILITY];
    await _health.requestAuthorization(types);
  }

  /// Fetch average HRV between times
  static Future<double?> fetchAverageHrv(DateTime start, DateTime end) async {
    final data = await _health.getHealthDataFromTypes(start, end, [HealthDataType.HEART_RATE_VARIABILITY]);
    if (data.isEmpty) return null;
    final values = data.map((e) => e.value as double).toList();
    return values.reduce((a, b) => a + b) / values.length;
  }
}