library activity_posture;

import 'package:sensors_plus/sensors_plus.dart';

class ActivityPosture {
  /// Listen to accelerometer for posture detection
  static Stream<AccelerometerEvent> get accelerometerStream => accelerometerEvents;

  /// Simple posture check: e.g., slouch if x-axis tilt beyond threshold
  static bool isSlouch(AccelerometerEvent e) {
    return e.x.abs() > 7; // arbitrary threshold
  }
}