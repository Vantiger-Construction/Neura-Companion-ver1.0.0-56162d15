
import 'dart:async';
import 'package:flutter/material.dart';
import 'dart:math';

class NeuraDancer extends StatefulWidget {
  final bool isActive;
  final InstrumentType instrument;

  const NeuraDancer({super.key, required this.isActive, required this.instrument});

  @override
  _NeuraDancerState createState() => _NeuraDancerState();
}

class _NeuraDancerState extends State<NeuraDancer> with SingleTickerProviderStateMixin {
  double _offsetY = 0;
  Timer? _danceTimer;
  String _aiComment = "🎶 Let's groove!";
  final List<String> _comments = [
    "🎵 This sounds jazzy!",
    "💤 Chill vibe detected.",
    "🔥 Epic energy here!",
    "🧠 Brainwave synced.",
    "🎧 Mood = Elevated.",
    "🌈 I love this part!",
    "⚡ Feel that beat!",
    "🪩 Neura is vibing hard!",
  ];

  @override
  void initState() {
    super.initState();
    _startDancing();
  }

  void _startDancing() {
    _danceTimer = Timer.periodic(Duration(milliseconds: 500), (_) {
      if (widget.isActive) {
        setState(() {
          _offsetY = Random().nextBool() ? 4.0 : -4.0;
          _aiComment = _comments[Random().nextInt(_comments.length)];
        });
      }
    });
  }

  @override
  void dispose() {
    _danceTimer?.cancel();
    super.dispose();
  }

  IconData _getExpression() {
    switch (widget.instrument) {
      case InstrumentType.vocals:
        return Icons.record_voice_over;
      case InstrumentType.melody:
        return Icons.auto_awesome;
      case InstrumentType.bass:
        return Icons.bolt;
      case InstrumentType.drums:
        return Icons.music_video;
    }
  }

  Color _getColor() {
    switch (widget.instrument) {
      case InstrumentType.vocals:
        return Colors.orangeAccent;
      case InstrumentType.melody:
        return Colors.purpleAccent;
      case InstrumentType.bass:
        return Colors.greenAccent;
      case InstrumentType.drums:
        return Colors.redAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        AnimatedContainer(
          duration: Duration(milliseconds: 300),
          transform: Matrix4.translationValues(0, _offsetY, 0),
          child: Icon(
            _getExpression(),
            size: 80,
            color: _getColor(),
          ),
        ),
        AnimatedSwitcher(
          duration: Duration(milliseconds: 500),
          child: Text(
            _aiComment,
            key: ValueKey(_aiComment),
            style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }
}
