@echo off
echo Building Windows desktop app...
flutter build windows --release
echo Build complete. Check build\windows\runner\Release
pause