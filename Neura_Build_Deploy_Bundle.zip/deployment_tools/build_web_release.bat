@echo off
echo Building Flutter web app...
flutter build web
echo Web build complete. Check build\web
pause