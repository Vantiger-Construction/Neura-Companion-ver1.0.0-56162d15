@echo off
echo Deploying to GitHub Pages...
cd build\web
git init
git remote add origin https://github.com/Vantiger1/Neura-Companion-Live.git
git checkout -b gh-pages
git add .
git commit -m "Deploy Neura Companion Web"
git push -f origin gh-pages
echo Deployed! Visit: https://vantiger1.github.io/Neura-Companion-Live
pause