# PowerShell script to compile modules and create JAR files

# Create output directories
New-Item -ItemType Directory -Force -Path "modules\output\timer\com\neura\companion\modules\timer"
New-Item -ItemType Directory -Force -Path "modules\output\calculator\com\neura\companion\modules\calculator"
New-Item -ItemType Directory -Force -Path "modules\output\weather\com\neura\companion\modules\weather"
New-Item -ItemType Directory -Force -Path "modules\output\notes\com\neura\companion\modules\notes"
New-Item -ItemType Directory -Force -Path "modules\output\timer\META-INF"
New-Item -ItemType Directory -Force -Path "modules\output\calculator\META-INF"
New-Item -ItemType Directory -Force -Path "modules\output\weather\META-INF"
New-Item -ItemType Directory -Force -Path "modules\output\notes\META-INF"
New-Item -ItemType Directory -Force -Path "modules\output\timer\com\neura\companion\util"
New-Item -ItemType Directory -Force -Path "modules\output\calculator\com\neura\companion\util"
New-Item -ItemType Directory -Force -Path "modules\output\weather\com\neura\companion\util"
New-Item -ItemType Directory -Force -Path "modules\output\notes\com\neura\companion\util"
New-Item -ItemType Directory -Force -Path "modules\output\timer\com\neura\companion\model"
New-Item -ItemType Directory -Force -Path "modules\output\calculator\com\neura\companion\model"
New-Item -ItemType Directory -Force -Path "modules\output\weather\com\neura\companion\model"
New-Item -ItemType Directory -Force -Path "modules\output\notes\com\neura\companion\model"

# Copy manifest files
Copy-Item "modules\timer\META-INF\MANIFEST.MF" -Destination "modules\output\timer\META-INF\"
Copy-Item "modules\calculator\META-INF\MANIFEST.MF" -Destination "modules\output\calculator\META-INF\"
Copy-Item "modules\weather\META-INF\MANIFEST.MF" -Destination "modules\output\weather\META-INF\"
Copy-Item "modules\notes\META-INF\MANIFEST.MF" -Destination "modules\output\notes\META-INF\"

# Copy simplified StringUtils and Feature to each module
Copy-Item "modules\common\com\neura\companion\util\StringUtils.java" -Destination "modules\output\timer\com\neura\companion\util\"
Copy-Item "modules\common\com\neura\companion\util\StringUtils.java" -Destination "modules\output\calculator\com\neura\companion\util\"
Copy-Item "modules\common\com\neura\companion\util\StringUtils.java" -Destination "modules\output\weather\com\neura\companion\util\"
Copy-Item "modules\common\com\neura\companion\util\StringUtils.java" -Destination "modules\output\notes\com\neura\companion\util\"

Copy-Item "modules\common\com\neura\companion\model\Feature.java" -Destination "modules\output\timer\com\neura\companion\model\"
Copy-Item "modules\common\com\neura\companion\model\Feature.java" -Destination "modules\output\calculator\com\neura\companion\model\"
Copy-Item "modules\common\com\neura\companion\model\Feature.java" -Destination "modules\output\weather\com\neura\companion\model\"
Copy-Item "modules\common\com\neura\companion\model\Feature.java" -Destination "modules\output\notes\com\neura\companion\model\"

# Compile Java files
# Timer module
javac -source 1.8 -target 1.8 -d "modules\output\timer" "modules\output\timer\com\neura\companion\util\StringUtils.java"
javac -source 1.8 -target 1.8 -d "modules\output\timer" "modules\output\timer\com\neura\companion\model\Feature.java"
javac -source 1.8 -target 1.8 -cp "modules\output\timer" -d "modules\output\timer" "modules\timer\com\neura\companion\modules\timer\TimerFeature.java"

# Calculator module
javac -source 1.8 -target 1.8 -d "modules\output\calculator" "modules\output\calculator\com\neura\companion\util\StringUtils.java"
javac -source 1.8 -target 1.8 -d "modules\output\calculator" "modules\output\calculator\com\neura\companion\model\Feature.java"
javac -source 1.8 -target 1.8 -cp "modules\output\calculator" -d "modules\output\calculator" "modules\calculator\com\neura\companion\modules\calculator\CalculatorFeature.java"

# Weather module
javac -source 1.8 -target 1.8 -d "modules\output\weather" "modules\output\weather\com\neura\companion\util\StringUtils.java"
javac -source 1.8 -target 1.8 -d "modules\output\weather" "modules\output\weather\com\neura\companion\model\Feature.java"
javac -source 1.8 -target 1.8 -cp "modules\output\weather" -d "modules\output\weather" "modules\weather\com\neura\companion\modules\weather\WeatherFeature.java"

# Notes module
javac -source 1.8 -target 1.8 -d "modules\output\notes" "modules\output\notes\com\neura\companion\util\StringUtils.java"
javac -source 1.8 -target 1.8 -d "modules\output\notes" "modules\output\notes\com\neura\companion\model\Feature.java"
javac -source 1.8 -target 1.8 -cp "modules\output\notes" -d "modules\output\notes" "modules\notes\com\neura\companion\modules\notes\NotesFeature.java"

# Create JAR files
jar cfm "modules\timer.jar" "modules\output\timer\META-INF\MANIFEST.MF" -C "modules\output\timer" .
jar cfm "modules\calculator.jar" "modules\output\calculator\META-INF\MANIFEST.MF" -C "modules\output\calculator" .
jar cfm "modules\weather.jar" "modules\output\weather\META-INF\MANIFEST.MF" -C "modules\output\weather" .
jar cfm "modules\notes.jar" "modules\output\notes\META-INF\MANIFEST.MF" -C "modules\output\notes" .

# Clean up output directories
Remove-Item -Recurse -Force "modules\output"

Write-Host "Module JAR files created successfully."
