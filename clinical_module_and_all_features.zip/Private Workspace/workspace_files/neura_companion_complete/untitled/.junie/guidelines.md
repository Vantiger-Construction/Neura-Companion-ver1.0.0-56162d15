# Project Guidelines

This document provides essential information for developing and maintaining the Neura Companion project.

## Project Structure

The project follows a standard Java project structure:

- `src/` - Contains the main source code
- `test/` - Contains test classes
- `.idea/` - IntelliJ IDEA configuration files
- `Neura Companion.iml` - IntelliJ IDEA module file

## Build and Configuration Instructions

### Setting up the Project

1. **IDE Setup**: This project is configured for IntelliJ IDEA. Open the project by selecting the root directory.

2. **Java Version**: The project uses Java 8 or higher. Ensure your JDK is properly configured in IntelliJ IDEA.

3. **Manual Compilation**:
   ```
   javac src/*.java
   ```

4. **Running the Application**:
   ```
   java -cp src Main
   ```

## Testing Information

### Test Structure

Tests are located in the `test/` directory. The project supports two testing approaches:

1. **Simple Testing**: Basic tests without external dependencies (current implementation)
2. **JUnit Testing**: For more complex test scenarios (configuration included in the .iml file)

### Running Tests

#### Simple Tests

1. **Compile both source and test classes**:
   ```
   javac src/*.java test/*.java
   ```

2. **Run the test**:
   ```
   java -cp ".;src;test" MainTest
   ```
   Note: On PowerShell, the classpath separator must be enclosed in quotes.
   On Unix-based systems, use: `java -cp ".:src:test" MainTest`

#### JUnit Tests (if implemented)

1. Ensure JUnit 5 is properly configured in your IDE or build path
2. Run tests through IDE or using:
   ```
   java -cp ".;src;test;path/to/junit/jars/*" org.junit.platform.console.ConsoleLauncher --scan-classpath
   ```

### Adding New Tests

1. Create a new test class in the `test/` directory
2. For simple tests:
   - Include a `main` method to run the test
   - Use clear output messages for test results
3. For JUnit tests:
   - Use `@Test` annotations
   - Use appropriate assertions

### Example Test

The project includes a sample test (`MainTest.java`) that demonstrates:
- Capturing and testing console output
- Basic assertion logic
- Clear result reporting

## Code Style and Development Guidelines

1. **Naming Conventions**:
   - Classes: PascalCase (e.g., `MainTest`)
   - Methods and variables: camelCase (e.g., `testMainOutput`)
   - Constants: UPPER_SNAKE_CASE

2. **Documentation**:
   - Include JavaDoc comments for all public classes and methods
   - Add inline comments for complex logic

3. **Error Handling**:
   - Use try-catch blocks for expected exceptions
   - Provide meaningful error messages

4. **Testing**:
   - Write tests for all new functionality
   - Ensure tests are independent and repeatable

## Additional Development Information

- The project is a simple Java application with a main class that prints messages to the console
- When extending functionality, maintain backward compatibility with existing tests
- Consider adding a build system like Maven or Gradle for more complex development needs
