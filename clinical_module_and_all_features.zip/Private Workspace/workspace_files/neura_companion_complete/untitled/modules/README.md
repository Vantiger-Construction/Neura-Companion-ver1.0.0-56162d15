# Neura Companion Modules

This folder contains modules and upgrades for the Neura Companion application.

## Adding Modules

To add a module to Neura Companion, follow these steps:

1. Create a JAR file containing your module classes
2. Add a manifest to the JAR file with the `Feature-Class` attribute set to the fully qualified name of your feature class
3. Place the JAR file in this folder
4. Restart the application

## Module Structure

A module JAR file should contain:

1. A class that extends the `com.neura.companion.model.Feature` abstract class
2. A manifest file with the `Feature-Class` attribute

### Example Manifest

```
Manifest-Version: 1.0
Feature-Class: com.example.MyFeature
```

### Example Feature Class

```java
package com.example;

import com.neura.companion.model.Feature;

public class MyFeature extends Feature {
    
    public MyFeature() {
        super("myfeature", "My Feature", "This is my custom feature", true);
    }
    
    @Override
    public String execute() {
        return "Hello from my custom feature!";
    }
}
```

## Creating a Module JAR

To create a module JAR file:

1. Compile your feature class:
   ```
   javac -cp path/to/neura-companion.jar com/example/MyFeature.java
   ```

2. Create a manifest file (manifest.txt):
   ```
   Manifest-Version: 1.0
   Feature-Class: com.example.MyFeature
   ```

3. Create the JAR file:
   ```
   jar cfm myfeature.jar manifest.txt com/example/MyFeature.class
   ```

4. Place the JAR file in the modules folder

## Upgrades

Upgrades are JAR files that replace existing features with new versions. To create an upgrade:

1. Create a feature class with the same ID as the feature you want to upgrade
2. Package it as a JAR file as described above
3. Place the JAR file in this folder
4. Restart the application

The new version of the feature will replace the old version.