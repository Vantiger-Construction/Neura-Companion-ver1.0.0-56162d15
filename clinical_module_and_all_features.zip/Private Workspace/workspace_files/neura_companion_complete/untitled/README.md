# Neura Companion

A simple Java application that serves as a companion for users, providing basic functionality through a command-line interface.

## Features

- Interactive command-line interface
- Configuration file support
- Command-line argument parsing
- Basic information display
- Internationalization support
- Colorized console output
- Template-based help system
- ASCII art banner display
- SLF4J/Logback logging system
- Utility classes for common operations
- Exception hierarchy for proper error handling
- Module loading system for extensibility
- Support for feature upgrades

## Getting Started

### Prerequisites

- Java 8 or higher
- IntelliJ IDEA (recommended) or any Java IDE

### Installation

1. Clone the repository
2. Open the project in IntelliJ IDEA or your preferred IDE
3. Build the project

### Running the Application

#### From IDE

Run the `com.neura.companion.Main` class from your IDE.

#### From Command Line

```
# Compile the code
javac -d out src/com/neura/companion/Main.java

# Run the application
java -cp out com.neura.companion.Main
```

### Command Line Arguments

- `--help`: Display help information
- `--non-interactive`: Run in non-interactive mode (no user input)

## Configuration

The application can be configured using the `config.properties` file. If this file is not found, default settings will be used.

Example configuration:

```properties
# Application settings
welcome.message=Welcome to Neura Companion - Your AI Assistant!
app.version=1.0.0
app.name=Neura Companion

# User interface settings
ui.prompt=Command> 
ui.color.enabled=true
```

### Color Support

The application supports colorized console output for better readability. This can be enabled or disabled in the configuration file:

```properties
# Enable colorized output
ui.color.enabled=true

# Or disable it
# ui.color.enabled=false
```

When enabled, different colors are used for different types of messages:
- Blue: Headers, prompts, and banners
- Green: Normal messages and command descriptions
- Yellow: Warnings and exit messages

### Internationalization

The application supports internationalization through resource bundles. Messages are loaded from:

```
src/main/resources/i18n/messages_en.properties
```

You can add support for other languages by creating additional resource bundles with the appropriate locale suffix (e.g., `messages_fr.properties` for French).

### Template-Based Help

The application uses a template-based help system. The help template is loaded from:

```
src/main/resources/templates/help_template.txt
```

This template contains placeholders that are replaced with actual values at runtime:
- `${app.version}`: The application version
- `${command.help}`: The description of the help command
- `${command.info}`: The description of the info command
- `${command.count}`: The description of the count command
- `${command.exit}`: The description of the exit command

### ASCII Art Banner

The application displays an ASCII art banner at startup in interactive mode. The banner is loaded from:

```
src/main/resources/static/banner.txt
```

This adds a visual element to the application and makes it more user-friendly.

### Logging System

The application uses SLF4J with Logback for logging. Logs are written to both the console and a file in the `logs` directory. The logging configuration can be modified in the `src/main/resources/logback.xml` file.

Log levels:
- ERROR: Critical errors that prevent the application from functioning
- WARN: Warning messages that indicate potential issues
- INFO: Informational messages about application state
- DEBUG: Detailed information for debugging purposes

### Utility Classes

The application includes utility classes for common operations:

- `StringUtils`: String manipulation and validation methods
  - `isEmpty(String)`: Check if a string is null or empty
  - `defaultIfEmpty(String, String)`: Return a default value if a string is empty
  - `truncate(String, int)`: Truncate a string to a maximum length
  - `capitalize(String)`: Capitalize the first letter of a string
  - `removeWhitespace(String)`: Remove all whitespace from a string

- `FileUtils`: File operations
  - `readFileToString(String)`: Read a file to a string
  - `readFileToLines(String)`: Read a file to a list of lines
  - `writeStringToFile(String, String)`: Write a string to a file
  - `writeLinesToFile(String, List<String>)`: Write lines to a file
  - `createDirectoryIfNotExists(String)`: Create a directory if it doesn't exist
  - `loadProperties(String)`: Load properties from a file
  - `saveProperties(Properties, String, String)`: Save properties to a file
  - `readResourceToString(String)`: Read a resource file from the classpath

### Exception Handling

The application includes a hierarchy of exceptions for proper error handling:

- `NeuraException`: Base exception class for all application-specific exceptions
- `ConfigurationException`: Exception for configuration-related errors

## Interactive Commands

When running in interactive mode, the following commands are available:

- `help`: Display available commands
- `info`: Display application information
- `count`: Run a simple counting loop
- `exit`: Exit the application
- Additional commands from loaded modules

## Modules and Upgrades

The application supports loading additional features from JAR files placed in the `modules` folder. This allows for extending the functionality of the application without modifying the core code.

### Adding Modules

To add a module to Neura Companion:

1. Create a JAR file containing your module classes
2. Add a manifest to the JAR file with the `Feature-Class` attribute set to the fully qualified name of your feature class
3. Place the JAR file in the `modules` folder
4. Restart the application

### Module Structure

A module JAR file should contain:

1. A class that extends the `com.neura.companion.model.Feature` abstract class
2. A manifest file with the `Feature-Class` attribute

For detailed instructions on creating modules, see the README.md file in the `modules` folder.

### Upgrades

Upgrades are JAR files that replace existing features with new versions. To create an upgrade:

1. Create a feature class with the same ID as the feature you want to upgrade
2. Package it as a JAR file as described above
3. Place the JAR file in the `modules` folder
4. Restart the application

The new version of the feature will replace the old version.

### Available Bonus Modules

Neura Companion supports a variety of bonus modules that extend its functionality. These modules are located in the external modules folder and can be enabled by placing their JAR files in the `modules` folder.

#### Clinical Modules

- **Clinical Module v2**: Advanced clinical data processing and analysis tools for healthcare professionals. Includes patient data management, clinical decision support, and medical record integration.

- **Clinical Module Addon v1**: An extension to the Clinical Module that adds specialized features for specific medical specialties, including cardiology, neurology, and oncology.

#### Wearables Modules

- **Wearables Modules v2**: Integration with fitness trackers, smartwatches, and other wearable devices. Collects and analyzes data such as heart rate, steps, sleep patterns, and activity levels.

- **Wearables Modules v3**: Enhanced version of the Wearables Module with support for newer devices and additional metrics such as blood oxygen levels, ECG readings, and stress monitoring.

- **Neura Wearables Addon v1**: Specialized add-on that provides AI-powered insights and recommendations based on wearable device data, including personalized fitness plans and health alerts.

#### Neura Feature Modules

- **Neura Feature Addon v1**: Core AI capabilities including natural language processing, sentiment analysis, and personalized recommendations based on user behavior and preferences.

- **Neura Optional Addon v1**: Additional AI features such as voice recognition, image analysis, and advanced data visualization tools.

#### Monetization Module

- **Monetization Addon v1**: Tools for implementing subscription services, in-app purchases, and usage tracking for commercial applications built on the Neura Companion platform.

To use any of these modules, you need to:

1. Obtain the module JAR file from the appropriate source
2. Place it in the `modules` folder of your Neura Companion installation
3. Restart the application
4. Access the new features through the interactive command interface

Each module adds new commands that can be discovered by using the `help` or `features` command after installation.

## Testing

Run the tests using:

```
javac -cp src test/MainTest.java
java -cp ".;src;test" MainTest
```

Note: On Unix-based systems, use `:` instead of `;` in the classpath.

## Project Structure

```
neura-companion/
├── src/
│   ├── com/
│   │   └── neura/
│   │       └── companion/
│   │           └── Main.java
│   └── main/
│       ├── java/
│       │   └── com/
│       │       └── neura/
│       │           └── companion/
│       │               ├── exception/
│       │               │   ├── ConfigurationException.java
│       │               │   └── NeuraException.java
│       │               ├── model/
│       │               │   ├── CountingFeature.java
│       │               │   ├── Feature.java
│       │               │   ├── FeatureManager.java
│       │               │   ├── HelpFeature.java
│       │               │   ├── InfoFeature.java
│       │               │   └── ModuleLoader.java
│       │               ├── util/
│       │               │   ├── FileUtils.java
│       │               │   └── StringUtils.java
│       │               └── Main.java
│       └── resources/
│           ├── config/
│           │   └── config.properties
│           ├── i18n/
│           │   └── messages_en.properties
│           ├── static/
│           │   └── banner.txt
│           ├── templates/
│           │   └── help_template.txt
│           └── logback.xml
├── test/
│   └── MainTest.java
├── src/test/java/com/neura/companion/
│   └── MainTest.java
├── config.properties
├── logs/
├── modules/
│   └── README.md
├── README.md
└── docs/
    ├── plan.md
    └── tasks.md
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Thanks to all contributors who have helped with the development of this project.
