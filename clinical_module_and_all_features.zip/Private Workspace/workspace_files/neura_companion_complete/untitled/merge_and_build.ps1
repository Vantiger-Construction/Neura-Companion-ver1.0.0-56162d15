# Neura Companion - Merge and Build Script
# This PowerShell script merges source files, compiles the project, and runs tests

Write-Host "Neura Companion - Merge and Build Script" -ForegroundColor Cyan
Write-Host "----------------------------------------" -ForegroundColor Cyan

# Step 1: Create directories if they don't exist
Write-Host "`nStep 1: Creating necessary directories..." -ForegroundColor Green
if (-not (Test-Path -Path "out")) {
    New-Item -ItemType Directory -Path "out" | Out-Null
    Write-Host "Created 'out' directory."
} else {
    Write-Host "'out' directory already exists."
}

if (-not (Test-Path -Path "out\com\neura\companion")) {
    New-Item -ItemType Directory -Path "out\com\neura\companion" -Force | Out-Null
    Write-Host "Created 'out\com\neura\companion' directory structure."
} else {
    Write-Host "'out\com\neura\companion' directory structure already exists."
}

# Step 2: Check for Main.java files and handle them
Write-Host "`nStep 2: Checking for Main.java files..." -ForegroundColor Green
$mainJavaExists = Test-Path -Path "src\Main.java"
$packageMainJavaExists = Test-Path -Path "src\com\neura\companion\Main.java"
$mavenMainJavaExists = Test-Path -Path "src\main\java\com\neura\companion\Main.java"

if ($mainJavaExists) {
    Write-Host "Found Main.java in src directory. This is not the correct location." -ForegroundColor Yellow
    Write-Host "Moving src\Main.java to src\Main.java.bak for reference."

    # Backup the redundant Main.java
    if (Test-Path -Path "src\Main.java.bak") {
        Remove-Item -Path "src\Main.java.bak" -Force
    }
    Rename-Item -Path "src\Main.java" -NewName "Main.java.bak"
}

if ($packageMainJavaExists -and $mavenMainJavaExists) {
    Write-Host "Found Main.java in both traditional and Maven package structures." -ForegroundColor Yellow
    Write-Host "The Maven structure (src\main\java\com\neura\companion\Main.java) will be used."
} elseif ($packageMainJavaExists) {
    Write-Host "Found Main.java only in traditional package structure. This is not the preferred location." -ForegroundColor Yellow
} elseif ($mavenMainJavaExists) {
    Write-Host "Found Main.java in Maven package structure. This is the correct location." -ForegroundColor Green
} else {
    Write-Host "No Main.java files found! Build will likely fail." -ForegroundColor Red
}

# Step 3: Build modules with Java 8 compatibility
Write-Host "`nStep 3: Building modules with Java 8 compatibility..." -ForegroundColor Green
& .\build_modules.ps1
if ($LASTEXITCODE -ne 0) {
    Write-Host "Module build failed with exit code $LASTEXITCODE." -ForegroundColor Red
    exit $LASTEXITCODE
} else {
    Write-Host "Modules built successfully with Java 8 compatibility." -ForegroundColor Green
}

# Step 4: Compile the source code using Maven
Write-Host "`nStep 4: Compiling source code using Maven..." -ForegroundColor Green

# Check if Maven is installed
try {
    $mvnVersion = mvn -version
    Write-Host "Maven is installed. Using Maven to build the project." -ForegroundColor Green
} catch {
    Write-Host "Maven is not installed or not in the PATH. Please install Maven and try again." -ForegroundColor Red
    exit 1
}

# Build the project with Maven
Write-Host "Building the project with Maven..." -ForegroundColor Green
mvn clean package -DskipTests

if ($LASTEXITCODE -eq 0) {
    Write-Host "Maven build successful." -ForegroundColor Green

    # Copy the JAR file to the out directory
    if (Test-Path -Path "target\neura-companion-1.0.0.jar") {
        if (-not (Test-Path -Path "out")) {
            New-Item -ItemType Directory -Path "out" | Out-Null
        }
        Copy-Item -Path "target\neura-companion-1.0.0.jar" -Destination "out\neura-companion.jar" -Force
        Write-Host "Copied JAR file to out\neura-companion.jar" -ForegroundColor Green
    } else {
        Write-Host "JAR file not found in target directory." -ForegroundColor Yellow
    }
} else {
    Write-Host "Maven build failed with exit code $LASTEXITCODE." -ForegroundColor Red
    exit $LASTEXITCODE
}

# Step 5: Run the tests with Maven
Write-Host "`nStep 5: Running tests with Maven..." -ForegroundColor Green
mvn test

if ($LASTEXITCODE -eq 0) {
    Write-Host "Maven tests completed successfully." -ForegroundColor Green
} else {
    Write-Host "Maven tests failed with exit code $LASTEXITCODE." -ForegroundColor Yellow
    Write-Host "This may be expected if the tests are not updated for the Maven structure." -ForegroundColor Yellow

    # Try running the traditional tests as a fallback
    Write-Host "`nAttempting to run traditional tests as fallback..." -ForegroundColor Yellow
    if (Test-Path -Path "test\MainTest.java") {
        # Compile the test file with the Maven-built JAR in the classpath
        javac -cp ".;out\neura-companion.jar" -d out test\MainTest.java

        if ($LASTEXITCODE -eq 0) {
            Write-Host "Traditional test compilation successful." -ForegroundColor Green

            # Run the test
            java -cp ".;out;out\neura-companion.jar" MainTest

            if ($LASTEXITCODE -eq 0) {
                Write-Host "Traditional tests completed successfully." -ForegroundColor Green
            } else {
                Write-Host "Traditional tests failed with exit code $LASTEXITCODE." -ForegroundColor Red
                # Don't exit with error, as this is just a fallback
            }
        } else {
            Write-Host "Traditional test compilation failed with exit code $LASTEXITCODE." -ForegroundColor Red
            # Don't exit with error, as this is just a fallback
        }
    } else {
        Write-Host "Traditional test file not found. Skipping fallback tests." -ForegroundColor Yellow
    }
}

# Step 6: Final status
Write-Host "`nBuild and test process completed." -ForegroundColor Cyan
Write-Host "You can run the application with: java -jar out\neura-companion.jar" -ForegroundColor Cyan
Write-Host "Or with Maven: mvn exec:java" -ForegroundColor Cyan
