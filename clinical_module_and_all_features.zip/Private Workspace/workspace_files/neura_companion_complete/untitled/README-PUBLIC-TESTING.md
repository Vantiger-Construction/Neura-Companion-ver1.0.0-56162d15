# Neura Companion - Public Testing Release

This document provides information about the Neura Companion application and instructions for building and running it for public testing.

## Overview

Neura Companion is a simple Java application that provides various features through a modular architecture. The application can be run in both interactive and non-interactive modes.

## Changes Made for Public Testing

The following changes have been made to prepare the application for public testing:

1. **Logging Configuration**: Changed the application-specific logging level from DEBUG to INFO to reduce log verbosity.
2. **Build Process**: Updated the build script to prioritize the Maven-style directory structure.
3. **Project Cleanup**: Created a cleanup script to remove compiled files and backup files from source directories.

## Building the Application

### Prerequisites

- Java 8 or higher
- Maven 3.6 or higher
- PowerShell (for Windows users)

### Build Instructions

1. **Clean the project** (recommended before building):
   ```
   .\cleanup.ps1
   ```

2. **Build the modules** (optional, only needed if you want to use the modules):
   ```
   .\build_modules.ps1
   ```

3. **Build the main application**:
   ```
   .\merge_and_build.ps1
   ```

   This script will automatically use Maven to build the project, which handles all dependencies correctly.

### Direct Maven Build

You can also build directly with Maven:

```
mvn clean package
```

## Running the Application

### Interactive Mode

To run the application in interactive mode:

```
java -cp out com.neura.companion.Main
```

Or if you built with Maven:

```
java -jar target/neura-companion-1.0.0.jar
```

### Non-Interactive Mode

To run the application in non-interactive mode:

```
java -cp out com.neura.companion.Main --non-interactive
```

## Available Features

The application includes the following built-in features:

- **help**: Displays help information about available commands
- **info**: Provides information about the application
- **counting**: Counts from 1 to a specified maximum value

Additional features are available through modules:

- **calculator**: Performs basic arithmetic operations
- **timer**: Provides timing functionality
- **weather**: Displays weather information
- **notes**: Allows creating and managing notes

## Project Structure

The project follows a Maven-style directory structure:

- `src/main/java`: Contains the main source code
- `src/main/resources`: Contains configuration files and resources
- `src/test/java`: Contains test classes
- `modules/`: Contains module JAR files and source code

## Testing

To run the tests:

```
.\merge_and_build.ps1
```

This will compile and run the tests automatically.

## Troubleshooting

If you encounter any issues:

1. Make sure Java is properly installed and in your PATH
2. Check the logs in the `logs/` directory
3. Ensure all dependencies are available

## Feedback

Please provide feedback on any issues encountered during testing.
