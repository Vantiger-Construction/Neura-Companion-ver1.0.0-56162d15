# Neura Companion - Cleanup Script
# This PowerShell script cleans up the project by removing compiled files and backup files from source directories

Write-Host "Neura Companion - Cleanup Script" -ForegroundColor Cyan
Write-Host "--------------------------------" -ForegroundColor Cyan

# Step 1: Remove compiled files from source directories
Write-Host "`nStep 1: Removing compiled files from source directories..." -ForegroundColor Green

# Find and remove .class files in src directory
$classFiles = Get-ChildItem -Path "src" -Filter "*.class" -Recurse
if ($classFiles.Count -gt 0) {
    Write-Host "Found $($classFiles.Count) compiled class files in source directories."
    foreach ($file in $classFiles) {
        Remove-Item -Path $file.FullName -Force
        Write-Host "Removed: $($file.FullName)"
    }
} else {
    Write-Host "No compiled class files found in source directories."
}

# Step 2: Remove backup files from source directories
Write-Host "`nStep 2: Removing backup files from source directories..." -ForegroundColor Green

# Find and remove .bak files in src directory
$bakFiles = Get-ChildItem -Path "src" -Filter "*.bak" -Recurse
if ($bakFiles.Count -gt 0) {
    Write-Host "Found $($bakFiles.Count) backup files in source directories."
    foreach ($file in $bakFiles) {
        Remove-Item -Path $file.FullName -Force
        Write-Host "Removed: $($file.FullName)"
    }
} else {
    Write-Host "No backup files found in source directories."
}

# Step 3: Final status
Write-Host "`nCleanup process completed." -ForegroundColor Cyan
Write-Host "The project is now ready for public testing." -ForegroundColor Cyan