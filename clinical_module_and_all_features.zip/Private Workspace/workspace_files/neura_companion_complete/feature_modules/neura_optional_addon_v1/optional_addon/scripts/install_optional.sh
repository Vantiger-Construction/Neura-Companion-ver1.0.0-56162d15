#!/usr/bin/env bash
set -e
echo "Installing optional Neura Companion modules..."
flutter pub get
echo "✔ Optional modules registered."
