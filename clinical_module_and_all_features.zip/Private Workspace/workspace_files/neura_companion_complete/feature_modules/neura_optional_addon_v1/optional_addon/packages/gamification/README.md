# gamification

## Installation
Add to your root `pubspec.yaml`:
```yaml
gamification:
  path: ./packages/gamification
```

## Usage
```dart
import 'package:gamification/gamification.dart';

await Gamification.init();
```
