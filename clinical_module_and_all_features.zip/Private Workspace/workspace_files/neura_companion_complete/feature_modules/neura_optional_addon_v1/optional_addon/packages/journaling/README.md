# journaling

## Installation
Add to your root `pubspec.yaml`:
```yaml
journaling:
  path: ./packages/journaling
```

## Usage
```dart
import 'package:journaling/journaling.dart';

await Journaling.init();
```
