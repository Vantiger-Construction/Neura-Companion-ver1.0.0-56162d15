# wearable_integration

## Installation
Add to your root `pubspec.yaml`:
```yaml
wearable_integration:
  path: ./packages/wearable_integration
```

## Usage
```dart
import 'package:wearable_integration/wearable_integration.dart';

await WearableIntegration.init();
```
