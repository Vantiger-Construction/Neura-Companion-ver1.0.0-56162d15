# dreamscape_visualizer

## Installation
Add to your root `pubspec.yaml`:
```yaml
dreamscape_visualizer:
  path: ./packages/dreamscape_visualizer
```

## Usage
```dart
import 'package:dreamscape_visualizer/dreamscape_visualizer.dart';

await DreamscapeVisualizer.init();
```
