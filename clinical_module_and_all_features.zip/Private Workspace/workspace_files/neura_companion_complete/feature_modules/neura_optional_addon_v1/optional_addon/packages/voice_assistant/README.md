# voice_assistant

## Installation
Add to your root `pubspec.yaml`:
```yaml
voice_assistant:
  path: ./packages/voice_assistant
```

## Usage
```dart
import 'package:voice_assistant/voice_assistant.dart';

await VoiceAssistant.init();
```
