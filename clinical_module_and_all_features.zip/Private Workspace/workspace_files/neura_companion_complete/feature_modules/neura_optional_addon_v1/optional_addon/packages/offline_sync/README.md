# offline_sync

## Installation
Add to your root `pubspec.yaml`:
```yaml
offline_sync:
  path: ./packages/offline_sync
```

## Usage
```dart
import 'package:offline_sync/offline_sync.dart';

await OfflineSync.init();
```
