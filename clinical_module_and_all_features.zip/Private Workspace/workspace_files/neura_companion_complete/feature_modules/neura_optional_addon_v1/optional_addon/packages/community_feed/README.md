# community_feed

## Installation
Add to your root `pubspec.yaml`:
```yaml
community_feed:
  path: ./packages/community_feed
```

## Usage
```dart
import 'package:community_feed/community_feed.dart';

await CommunityFeed.init();
```
