import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:clinical_module/clinical_module.dart';
import 'dart:convert';

class MockIAP extends Mock implements InAppPurchasePlatform {}
class MockClient extends Mock implements http.Client {}
class MockStorage extends Mock implements FlutterSecureStorage {}

void main() {
  late MockIAP mockIap;
  late MockClient mockHttp;
  late MockStorage mockStorage;
  late ClinicalModule module;
  final patientJson = jsonEncode({'resourceType':'Patient','id':'123'});

  setUp(() {
    mockIap = MockIAP();
    mockHttp = MockClient();
    mockStorage = MockStorage();
    when(mockIap.isAvailable()).thenAnswer((_) async => true);
    when(mockIap.queryProductDetails({'clinical_module_pro'}))
        .thenAnswer((_) async => ProductDetailsResponse(
          productDetails: [ProductDetails(id: 'clinical_module_pro', title: '', description: '', price: '', rawPrice: 0.0, currencyCode: '')],
          notFoundIDs: {},
        ));
    when(mockIap.queryPastPurchases())
        .thenAnswer((_) async => QueryPurchaseDetailsResponse(
            pastPurchases: [PurchaseDetails(productID: 'clinical_module_pro', status: PurchaseStatus.purchased)]));
    module = ClinicalModule(
      iap: mockIap,
      httpClient: mockHttp,
      storage: mockStorage,
      fhirServerUrl: 'https://fhir.test',
      apiKey: 'key',
    );
  });

  test('fetchPatient caches and returns data', () async {
    when(mockHttp.get(Uri.parse('https://fhir.test/Patient/123'), headers:anyNamed('headers')))
        .thenAnswer((_) async => http.Response(patientJson, 200));
    when(mockStorage.write(key: anyNamed('key'), value: anyNamed('value')))
        .thenAnswer((_) async {});
    await module.init();
    final p = await module.fetchPatient('123');
    expect(p.id?.value, '123');
    verify(mockStorage.write(key: 'patient_123', value: patientJson)).called(1);
  });

  test('fetchPatient returns cached on error', () async {
    when(mockHttp.get(any, headers:anyNamed('headers')))
        .thenThrow(Exception('network'));
    when(mockStorage.read(key: 'patient_123')).thenAnswer((_) async => patientJson);
    await module.init();
    final p = await module.fetchPatient('123');
    expect(p.id?.value, '123');
  });

  test('sendObservation queues on failure', () async {
    final obs = Observation(status: ObservationStatus.final_, code: CodeableConcept(coding: [Coding(system: '', code: '')]));
    // simulate failure
    when(mockHttp.post(any, headers:anyNamed('headers'), body:anyNamed('body')))
        .thenThrow(Exception('network'));
    when(mockStorage.read(key: 'obs_queue')).thenAnswer((_) async => null);
    when(mockStorage.write(key: 'obs_queue', value: anyNamed('value')))
        .thenAnswer((_) async {});
    await module.init();
    await module.sendObservation(obs);
    verify(mockStorage.write(key: 'obs_queue', value: anyThat(contains('"resourceType":"Observation"')))).called(1);
  });
}
