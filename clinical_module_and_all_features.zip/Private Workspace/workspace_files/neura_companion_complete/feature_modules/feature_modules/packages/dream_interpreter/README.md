# dream_interpreter

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'dream_interpreter/dream_interpreter.dart';

await DreamInterpreter.init();
```