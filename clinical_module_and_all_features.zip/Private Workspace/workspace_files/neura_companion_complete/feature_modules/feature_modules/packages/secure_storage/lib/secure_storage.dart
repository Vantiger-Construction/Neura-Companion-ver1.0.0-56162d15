library secure_storage;

import 'package:flutter/material.dart';

class SecureStorage {
  static Future<void> init() async {
    // TODO: implement init logic for secure_storage
  }
}