# secure_storage

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'secure_storage/secure_storage.dart';

await SecureStorage.init();
```