library analytics_dashboard;

import 'package:flutter/material.dart';

class AnalyticsDashboard {
  static Future<void> init() async {
    // TODO: implement init logic for analytics_dashboard
  }
}