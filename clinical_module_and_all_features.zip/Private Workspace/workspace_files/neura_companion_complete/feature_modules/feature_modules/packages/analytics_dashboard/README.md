# analytics_dashboard

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'analytics_dashboard/analytics_dashboard.dart';

await AnalyticsDashboard.init();
```