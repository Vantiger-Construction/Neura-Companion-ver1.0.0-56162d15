# voice_personas

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'voice_personas/voice_personas.dart';

await VoicePersonas.init();
```