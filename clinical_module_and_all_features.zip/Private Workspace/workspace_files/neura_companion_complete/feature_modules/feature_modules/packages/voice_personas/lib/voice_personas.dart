library voice_personas;

import 'package:flutter/material.dart';

class VoicePersonas {
  static Future<void> init() async {
    // TODO: implement init logic for voice_personas
  }
}