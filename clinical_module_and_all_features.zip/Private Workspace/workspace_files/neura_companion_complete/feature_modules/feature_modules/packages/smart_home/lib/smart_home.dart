library smart_home;

import 'package:flutter/material.dart';

class SmartHome {
  static Future<void> init() async {
    // TODO: implement init logic for smart_home
  }
}