# smart_home

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'smart_home/smart_home.dart';

await SmartHome.init();
```