# dynamic_theme

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'dynamic_theme/dynamic_theme.dart';

await DynamicTheme.init();
```