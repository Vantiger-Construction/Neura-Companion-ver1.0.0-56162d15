library dynamic_theme;

import 'package:flutter/material.dart';

class DynamicTheme {
  static Future<void> init() async {
    // TODO: implement init logic for dynamic_theme
  }
}