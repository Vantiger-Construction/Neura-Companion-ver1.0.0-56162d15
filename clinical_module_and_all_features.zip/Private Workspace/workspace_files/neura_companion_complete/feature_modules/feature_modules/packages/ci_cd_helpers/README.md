# ci_cd_helpers

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'ci_cd_helpers/ci_cd_helpers.dart';

await CiCdHelpers.init();
```