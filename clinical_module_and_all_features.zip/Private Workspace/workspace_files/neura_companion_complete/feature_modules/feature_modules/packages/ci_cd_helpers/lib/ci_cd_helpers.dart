library ci_cd_helpers;

import 'package:flutter/material.dart';

class CiCdHelpers {
  static Future<void> init() async {
    // TODO: implement init logic for ci_cd_helpers
  }
}