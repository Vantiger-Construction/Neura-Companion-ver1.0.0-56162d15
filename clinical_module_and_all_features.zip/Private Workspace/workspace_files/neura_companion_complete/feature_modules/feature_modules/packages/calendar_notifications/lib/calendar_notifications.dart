library calendar_notifications;

import 'package:flutter/material.dart';

class CalendarNotifications {
  static Future<void> init() async {
    // TODO: implement init logic for calendar_notifications
  }
}