# calendar_notifications

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'calendar_notifications/calendar_notifications.dart';

await CalendarNotifications.init();
```