# accessibility

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'accessibility/accessibility.dart';

await Accessibility.init();
```