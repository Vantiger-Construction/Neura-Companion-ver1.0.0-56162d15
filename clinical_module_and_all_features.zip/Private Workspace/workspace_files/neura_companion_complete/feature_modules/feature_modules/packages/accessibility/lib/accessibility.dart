library accessibility;

import 'package:flutter/material.dart';

class Accessibility {
  static Future<void> init() async {
    // TODO: implement init logic for accessibility
  }
}