library consent_manager;

import 'package:flutter/material.dart';

class ConsentManager {
  static Future<void> init() async {
    // TODO: implement init logic for consent_manager
  }
}