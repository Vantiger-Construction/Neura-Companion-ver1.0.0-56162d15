# consent_manager

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'consent_manager/consent_manager.dart';

await ConsentManager.init();
```