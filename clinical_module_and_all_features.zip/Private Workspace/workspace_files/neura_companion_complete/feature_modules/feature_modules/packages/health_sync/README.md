# health_sync

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'health_sync/health_sync.dart';

await HealthSync.init();
```