library health_sync;

import 'package:flutter/material.dart';

class HealthSync {
  static Future<void> init() async {
    // TODO: implement init logic for health_sync
  }
}