# state_di

## Installation
Path dependency already declared in your main `pubspec.yaml`.

## Usage
Import and call:
```dart
import 'state_di/state_di.dart';

await StateDi.init();
```