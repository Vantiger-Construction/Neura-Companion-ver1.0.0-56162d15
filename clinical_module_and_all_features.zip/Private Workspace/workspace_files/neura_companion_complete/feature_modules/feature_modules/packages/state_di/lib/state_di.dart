library state_di;

import 'package:flutter/material.dart';

class StateDi {
  static Future<void> init() async {
    // TODO: implement init logic for state_di
  }
}