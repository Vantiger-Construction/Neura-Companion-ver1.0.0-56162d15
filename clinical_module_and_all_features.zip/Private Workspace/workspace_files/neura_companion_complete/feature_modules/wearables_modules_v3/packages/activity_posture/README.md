# ActivityPosture

## Installation
Add to root `pubspec.yaml`:
```yaml
activity_posture:
  path: ./packages/activity_posture
```

## Usage
```dart
import 'package:activity_posture/activity_posture.dart';

// Initialize
final module = await ActivityPosture.init(HealthApiImpl()); // or pass mock for tests

// Example
final hrv = await module.fetchAverageHrv(DateTime.now().subtract(Duration(hours:1)), DateTime.now());
```
