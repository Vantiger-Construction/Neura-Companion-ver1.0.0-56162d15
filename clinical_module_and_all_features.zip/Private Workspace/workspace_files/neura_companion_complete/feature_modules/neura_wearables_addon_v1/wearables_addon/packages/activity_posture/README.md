# ActivityPosture

## Installation
Add to your root `pubspec.yaml`:
```yaml
activity_posture:
  path: ./packages/activity_posture
```

## Usage
```dart
import 'package:activity_posture/activity_posture.dart';

await ActivityPosture.init();
// Use example method:
ActivityPosture.example();
```
