# InAppMarketplaceModule

## Installation
Add to your root `pubspec.yaml`:
```yaml
in_app_marketplace:
  path: ./packages/in_app_marketplace
```

## Usage
```dart
import 'package:in_app_marketplace/in_app_marketplace.dart';

await InAppMarketplaceModule.init();
// Example:
await InAppMarketplaceModule.exampleUsage();
```
