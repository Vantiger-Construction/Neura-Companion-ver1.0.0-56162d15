# CoachMarketplaceModule

## Installation
Add to your root `pubspec.yaml`:
```yaml
coach_marketplace:
  path: ./packages/coach_marketplace
```

## Usage
```dart
import 'package:coach_marketplace/coach_marketplace.dart';

await CoachMarketplaceModule.init();
// Example:
await CoachMarketplaceModule.exampleUsage();
```
