# Clinical Module v2

## Installation
Add to your root `pubspec.yaml`:
```yaml
clinical_module:
  path: ./packages/clinical_module
```

## In-App Purchase Setup

### Google Play Console
1. In **Monetize > Products > Subscriptions**, create a new subscription:
   - **Product ID:** `clinical_module_pro`
   - **Name & Description:** Professional Module Access
   - **Pricing & Free Trial:** configure as needed.

2. Upload and publish your app with a **draft** subscription to test.

3. In app, call `ClinicalModule.init()` to verify active subscription.

### App Store Connect
1. In **Features > In-App Purchases**, add a Subscription:
   - **Reference Name:** Clinical Module Pro
   - **Product ID:** `clinical_module_pro`
2. Upload your build with StoreKit configuration and test in Sandbox.

## Usage
```dart
import 'package:clinical_module/clinical_module.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await ClinicalModule.init();
  } catch (e) {
    // Prompt user to purchase
    await ClinicalModule.purchase();
  }

  // Fetch patient example
  final patient = await ClinicalModule.fetchPatient(
    'patient-id', 'https://fhir.example.com', 'API_KEY'
  );
  print(patient.toJson());

  // Send heart rate observation
  final obs = Observation(
    status: ObservationStatus.final_,
    code: CodeableConcept(
      coding: [Coding(system: 'http://loinc.org', code: '8867-4', display: 'Heart rate')]
    ),
    subject: Reference(reference: 'Patient/patient-id'),
    effectiveDateTime: FhirDateTime.now(),
    valueQuantity: Quantity(value: 72, unit: 'beats/min')
  );
  await ClinicalModule.sendObservation(obs, 'https://fhir.example.com', 'API_KEY');
}
```
