# Testing

Unit tests are provided using Mockito:

- **fetchPatient**  
  - Verifies caching and fallback behavior.  
- **sendObservation**  
  - Verifies queuing on network failure.

Run all tests with:
```bash
flutter test --coverage
```
