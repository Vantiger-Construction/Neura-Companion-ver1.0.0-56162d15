# API Reference

## ClinicalModule Constructor
```dart
ClinicalModule({
  required InAppPurchasePlatform iap,
  required Client httpClient,
  required FlutterSecureStorage storage,
  required String fhirServerUrl,
  required String apiKey,
  String subscriptionId = 'clinical_module_pro',
});
```
Instantiate and provide dependencies for IAP, HTTP, and secure storage.

### Methods

- **init()**  
  Initializes and verifies subscription. Throws if not available or unsubscribed.  

- **purchase()**  
  Launches in-app purchase flow for the professional subscription.  

- **fetchPatient(String patientId)**  
  Fetches and caches a `Patient` resource from the FHIR server. Falls back to cache if offline.  

- **sendObservation(Observation obs)**  
  Sends an `Observation` resource to the FHIR server or queues it if offline.  

- **flushQueue()**  
  Attempts to resend any queued observations.  

- **listCachedPatients()**  
  Returns a list of patient IDs that have cached records.  
