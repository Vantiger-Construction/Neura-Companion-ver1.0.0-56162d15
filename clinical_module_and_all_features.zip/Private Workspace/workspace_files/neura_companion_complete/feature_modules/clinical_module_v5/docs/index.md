# Clinical Module v4 Documentation

Welcome to the Clinical Module v4! This module provides paid features for medical professionals, including remote patient monitoring, FHIR integration, and offline support.

## Table of Contents
- [Installation](installation.md)
- [Quick Start](quick_start.md)
- [API Reference](api_reference.md)
- [Testing](testing.md)
- [CI/CD Integration](ci_cd.md)
