#!/usr/bin/env bash
set -e
echo "Installing Clinical Module (paid professional features)..."
flutter pub get
echo "✔ Clinical module registered."
