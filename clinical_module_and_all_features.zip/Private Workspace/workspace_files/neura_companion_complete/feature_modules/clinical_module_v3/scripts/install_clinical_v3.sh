#!/usr/bin/env bash
set -e
echo "Installing Clinical Module v3..."
flutter pub get
