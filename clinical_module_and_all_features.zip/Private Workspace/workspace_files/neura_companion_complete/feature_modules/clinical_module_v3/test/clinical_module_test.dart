import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:http/http.dart' as http;
import 'package:clinical_module/clinical_module.dart';
import 'dart:convert';

class MockIAP extends Mock implements InAppPurchasePlatform {}
class MockClient extends Mock implements http.Client {}

void main() {
  late MockIAP mockIap;
  late MockClient mockHttp;
  late ClinicalModule module;

  setUp(() {
    mockIap = MockIAP();
    mockHttp = MockClient();
    when(mockIap.isAvailable()).thenAnswer((_) async => true);
    when(mockIap.queryProductDetails({'clinical_module_pro'}))
        .thenAnswer((_) async => ProductDetailsResponse(
          productDetails: [ProductDetails(id: 'clinical_module_pro', title: '', description: '', price: '', rawPrice: 0.0, currencyCode: '')],
          notFoundIDs: {},
        ));
    when(mockIap.queryPastPurchases())
        .thenAnswer((_) async => QueryPurchaseDetailsResponse(pastPurchases: [PurchaseDetails(productID: 'clinical_module_pro', status: PurchaseStatus.purchased)]));
    module = ClinicalModule(
      iap: mockIap,
      httpClient: mockHttp,
      storage: null as dynamic, // not used
      fhirServerUrl: 'https://fhir.test',
      apiKey: 'key',
    );
  });

  test('init succeeds with subscription', () async {
    await module.init();
  });

  test('fetchPatient returns Patient', () async {
    final patientJson = jsonEncode({'resourceType':'Patient','id':'123'});
    when(mockHttp.get(Uri.parse('https://fhir.test/Patient/123'), headers:anyNamed('headers')))
        .thenAnswer((_) async => http.Response(patientJson, 200));
    await module.init();
    final patient = await module.fetchPatient('123');
    expect(patient.id?.value, '123');
  });
}
