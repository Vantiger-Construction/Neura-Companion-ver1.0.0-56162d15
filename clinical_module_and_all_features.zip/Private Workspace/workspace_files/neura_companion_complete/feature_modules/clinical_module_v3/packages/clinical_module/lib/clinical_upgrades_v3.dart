import 'package:clinical_module/clinical_module.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:http/http.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ClinicalUpgradesV3 {
  static Future<ClinicalModule> initModule({
    required String fhirServerUrl,
    required String apiKey,
  }) async {
    final module = ClinicalModule(
      iap: InAppPurchase.instance,
      httpClient: Client(),
      storage: FlutterSecureStorage(),
      fhirServerUrl: fhirServerUrl,
      apiKey: apiKey,
    );
    await module.init();
    return module;
  }
}
