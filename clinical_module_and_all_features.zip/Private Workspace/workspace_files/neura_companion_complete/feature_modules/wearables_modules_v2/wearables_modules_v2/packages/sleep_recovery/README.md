# SleepRecovery

## Installation
Add to root `pubspec.yaml`:
```yaml
sleep_recovery:
  path: ./packages/sleep_recovery
``` 

## Usage
```dart
import 'package:sleep_recovery/sleep_recovery.dart';

await SleepRecovery.init();
// Example:
// TODO: use SleepRecovery features
```