# ThirdPartySensors

## Installation
Add to root `pubspec.yaml`:
```yaml
third_party_sensors:
  path: ./packages/third_party_sensors
``` 

## Usage
```dart
import 'package:third_party_sensors/third_party_sensors.dart';

await ThirdPartySensors.init();
// Example:
// TODO: use ThirdPartySensors features
```