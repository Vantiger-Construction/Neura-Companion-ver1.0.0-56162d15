# HealthTrendInsights

## Installation
Add to root `pubspec.yaml`:
```yaml
health_trend_insights:
  path: ./packages/health_trend_insights
``` 

## Usage
```dart
import 'package:health_trend_insights/health_trend_insights.dart';

await HealthTrendInsights.init();
// Example:
// TODO: use HealthTrendInsights features
```