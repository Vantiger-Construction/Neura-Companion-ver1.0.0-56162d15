# MicroWorkouts

## Installation
Add to root `pubspec.yaml`:
```yaml
micro_workouts:
  path: ./packages/micro_workouts
``` 

## Usage
```dart
import 'package:micro_workouts/micro_workouts.dart';

await MicroWorkouts.init();
// Example:
// TODO: use MicroWorkouts features
```