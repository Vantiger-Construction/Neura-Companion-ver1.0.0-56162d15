# BiometricFeedback

## Installation
Add to root `pubspec.yaml`:
```yaml
biometric_feedback:
  path: ./packages/biometric_feedback
``` 

## Usage
```dart
import 'package:biometric_feedback/biometric_feedback.dart';

await BiometricFeedback.init();
// Example:
var hrv = await BiometricFeedback.fetchAverageHrv(DateTime.now().subtract(Duration(hours:1)), DateTime.now());
```