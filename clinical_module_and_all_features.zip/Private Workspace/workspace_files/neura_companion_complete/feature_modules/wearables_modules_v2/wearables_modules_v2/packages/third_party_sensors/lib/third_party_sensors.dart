library third_party_sensors;

import 'dart:convert';
import 'package:http/http.dart' as http;

class ThirdPartySensors {
  static String _apiKey = '';

  static void configure({required String apiKey}) {
    _apiKey = apiKey;
  }

  static Future<Map<String, dynamic>> fetchOuraData() async {
    final res = await http.get(
      Uri.parse('https://api.ouraring.com/v1/userinfo'),
      headers: {'Authorization': 'Bearer $_apiKey'},
    );
    if (res.statusCode == 200) return jsonDecode(res.body);
    throw Exception('Oura API error');
  }
}