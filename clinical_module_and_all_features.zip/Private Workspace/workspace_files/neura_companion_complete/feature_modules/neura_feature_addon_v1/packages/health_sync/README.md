# health_sync

## Installation
Add to root pubspec.yaml:
```yaml
health_sync:
  path: ./packages/health_sync
```

## Usage
```dart
import 'package:health_sync/health_sync.dart';
await HealthSync.init();
```