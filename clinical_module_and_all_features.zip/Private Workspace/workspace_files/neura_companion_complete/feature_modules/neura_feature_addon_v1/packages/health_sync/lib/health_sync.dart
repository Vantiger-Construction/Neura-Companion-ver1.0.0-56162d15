library health_sync;

import 'package:health/health.dart';

class HealthSync {
  static final _health = HealthFactory();

  static Future<void> init() async {
    final types = [HealthDataType.HEART_RATE, HealthDataType.STEPS];
    await _health.requestAuthorization(types);
  }

  static Future<List<HealthDataPoint>> fetchHeartRate(DateTime start, DateTime end) async {
    return _health.getHealthDataFromTypes(start, end, [HealthDataType.HEART_RATE]);
  }
}