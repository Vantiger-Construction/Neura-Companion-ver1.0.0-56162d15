library calendar_notifications;

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tzdata;

class CalendarNotifications {
  static final _notif = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    tzdata.initializeTimeZones();
    await _notif.initialize(InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
  }

  static Future<void> scheduleDaily({int hour = 8, int minute = 0}) async {
    await _notif.zonedSchedule(
      0,
      'Daily Check-In',
      'Log your mood now',
      tz.TZDateTime.local(DateTime.now().year, DateTime.now().month, DateTime.now().day, hour, minute).add(Duration(days: 1)),
      NotificationDetails(android: AndroidNotificationDetails('daily', 'Daily Checks')),
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }
}