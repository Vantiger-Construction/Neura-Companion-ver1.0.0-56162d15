# dream_interpreter

## Installation
Add to root pubspec.yaml:
```yaml
dream_interpreter:
  path: ./packages/dream_interpreter
```

## Usage
```dart
import 'package:dream_interpreter/dream_interpreter.dart';
await DreamInterpreter.init();
```