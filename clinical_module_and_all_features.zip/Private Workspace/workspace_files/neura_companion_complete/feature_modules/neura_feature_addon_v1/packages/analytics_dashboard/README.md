# analytics_dashboard

## Installation
Add to root pubspec.yaml:
```yaml
analytics_dashboard:
  path: ./packages/analytics_dashboard
```

## Usage
```dart
import 'package:analytics_dashboard/analytics_dashboard.dart';
await AnalyticsDashboard.init();
```