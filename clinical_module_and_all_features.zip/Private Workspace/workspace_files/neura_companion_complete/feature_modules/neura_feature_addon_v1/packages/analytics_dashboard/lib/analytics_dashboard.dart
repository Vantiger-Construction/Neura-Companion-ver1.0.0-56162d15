library analytics_dashboard;

import 'package:flutter/widgets.dart';
import 'package:fl_chart/fl_chart.dart';

class AnalyticsDashboard {
  static void init() {/* init analytics backend */}

  static Widget moodBarChart(List<BarChartGroupData> data) =>
      BarChart(BarChartData(barGroups: data));
}