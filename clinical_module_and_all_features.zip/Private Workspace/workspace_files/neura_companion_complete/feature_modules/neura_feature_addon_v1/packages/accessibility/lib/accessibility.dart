library accessibility;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AccessibilityService with ChangeNotifier {
  double _textScale = 1.0;
  double get textScale => _textScale;

  void increase() {
    _textScale += 0.1;
    notifyListeners();
  }

  void decrease() {
    if (_textScale > 0.5) _textScale -= 0.1;
    notifyListeners();
  }
}

class SemanticToggle extends StatelessWidget {
  final Widget child;
  const SemanticToggle({required this.child, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Row(children: [
        IconButton(icon: Icon(Icons.text_increase), onPressed: () => context.read<AccessibilityService>().increase()),
        IconButton(icon: Icon(Icons.text_decrease), onPressed: () => context.read<AccessibilityService>().decrease()),
      ]),
      Expanded(child: Consumer<AccessibilityService>(builder: (_, svc, __) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: svc.textScale),
        child: child,
      ))),
    ]);
  }
}