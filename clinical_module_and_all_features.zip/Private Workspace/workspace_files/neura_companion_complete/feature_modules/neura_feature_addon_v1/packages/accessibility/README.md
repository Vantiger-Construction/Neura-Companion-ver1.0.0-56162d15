# accessibility

## Installation
Add to root pubspec.yaml:
```yaml
accessibility:
  path: ./packages/accessibility
```

## Usage
```dart
import 'package:accessibility/accessibility.dart';
await Accessibility.init();
```