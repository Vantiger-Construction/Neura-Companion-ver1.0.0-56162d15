library voice_personas;

import 'package:flutter_tts/flutter_tts.dart';

class VoicePersonas {
  static final FlutterTts _tts = FlutterTts();

  static Future<void> init() async {
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(0.5);
  }

  static Future<void> speak(String text, {String? voice}) async {
    if (voice != null) await _tts.setVoice({'name': voice});
    await _tts.speak(text);
  }
}