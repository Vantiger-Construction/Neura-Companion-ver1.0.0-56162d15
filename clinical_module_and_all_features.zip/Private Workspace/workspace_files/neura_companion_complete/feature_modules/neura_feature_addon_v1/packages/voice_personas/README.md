# voice_personas

## Installation
Add to root pubspec.yaml:
```yaml
voice_personas:
  path: ./packages/voice_personas
```

## Usage
```dart
import 'package:voice_personas/voice_personas.dart';
await VoicePersonas.init();
```