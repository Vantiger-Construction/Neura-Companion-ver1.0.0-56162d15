# dynamic_theme

## Installation
Add to root pubspec.yaml:
```yaml
dynamic_theme:
  path: ./packages/dynamic_theme
```

## Usage
```dart
import 'package:dynamic_theme/dynamic_theme.dart';
await DynamicTheme.init();
```