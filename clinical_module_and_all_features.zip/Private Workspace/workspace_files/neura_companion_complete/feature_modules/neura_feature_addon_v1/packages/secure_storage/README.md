# secure_storage

## Installation
Add to root pubspec.yaml:
```yaml
secure_storage:
  path: ./packages/secure_storage
```

## Usage
```dart
import 'package:secure_storage/secure_storage.dart';
await SecureStorage.init();
```