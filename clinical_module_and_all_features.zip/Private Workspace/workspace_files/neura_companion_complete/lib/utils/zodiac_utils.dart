// Zodiac utilities implementation
