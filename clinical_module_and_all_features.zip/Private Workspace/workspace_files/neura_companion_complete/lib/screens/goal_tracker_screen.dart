// GoalTrackerScreen implementation
