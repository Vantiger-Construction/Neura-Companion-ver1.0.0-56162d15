// HealthDashboardScreen implementation
