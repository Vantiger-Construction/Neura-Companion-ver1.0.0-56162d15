// AIChatScreen implementation
