// Full HealthService implementation
