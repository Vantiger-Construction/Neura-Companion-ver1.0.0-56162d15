// Full ProactiveService implementation
