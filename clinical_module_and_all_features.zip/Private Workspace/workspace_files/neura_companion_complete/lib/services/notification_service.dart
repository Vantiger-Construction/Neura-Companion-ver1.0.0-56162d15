// Full NotificationService implementation
