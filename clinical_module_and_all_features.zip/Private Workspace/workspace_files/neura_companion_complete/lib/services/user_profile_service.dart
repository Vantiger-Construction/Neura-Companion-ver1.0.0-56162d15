// Full UserProfileService implementation
