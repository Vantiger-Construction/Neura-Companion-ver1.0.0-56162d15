// Full ReinforcementService implementation
