// Full BadgeService implementation
