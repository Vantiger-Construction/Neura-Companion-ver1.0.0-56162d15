// Full CalendarService implementation
