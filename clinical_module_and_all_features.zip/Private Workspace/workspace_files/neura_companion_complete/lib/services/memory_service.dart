// Full MemoryService implementation
