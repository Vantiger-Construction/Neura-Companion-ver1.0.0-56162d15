// Unit tests for ProactiveService
