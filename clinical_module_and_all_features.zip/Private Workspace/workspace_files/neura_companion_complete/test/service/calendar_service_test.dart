// Unit tests for CalendarService
