plugins {
    kotlin("jvm") version "1.9.0"
    application
}

repositories {
    mavenCentral()
    google()
}

dependencies {
    implementation("io.ktor:ktor-server-netty:2.4.0")
    implementation("io.ktor:ktor-server-core:2.4.0")
    implementation("io.ktor:ktor-serialization-kotlinx-json:2.4.0")
    implementation("ch.qos.logback:logback-classic:1.4.7")
}

application {
    mainClass.set("backend.ApplicationKt")
}
