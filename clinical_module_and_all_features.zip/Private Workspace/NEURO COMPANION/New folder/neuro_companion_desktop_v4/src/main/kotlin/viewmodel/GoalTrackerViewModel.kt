package viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import services.AIService
import java.lang.Exception

class GoalTrackerViewModel(private val ai: AIService) {
    var result by mutableStateOf("")
        private set

    var isBusy by mutableStateOf(false)
        private set

    fun loadGoals() {
        CoroutineScope(Dispatchers.Main).launch {
            isBusy = true
            result = try {
                ai.generateText("Suggest three achievable goals for today.")
            } catch (e: Exception) {
                Log.e("GoalTrackerVM", "Error in loadGoals", e)
                "Operation failed."
            } finally {
                isBusy = false
            }
        }
    }
}
