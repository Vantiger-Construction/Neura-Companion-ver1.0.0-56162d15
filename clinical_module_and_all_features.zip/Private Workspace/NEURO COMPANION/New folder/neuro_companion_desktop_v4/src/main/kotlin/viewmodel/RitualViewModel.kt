package viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import services.AIService
import java.lang.Exception

class RitualViewModel(private val ai: AIService) {
    var result by mutableStateOf("")
        private set

    var isBusy by mutableStateOf(false)
        private set

    fun loadRitual() {
        CoroutineScope(Dispatchers.Main).launch {
            isBusy = true
            result = try {
                ai.generateText("Suggest a daily self-care ritual for mindfulness.")
            } catch (e: Exception) {
                Log.e("RitualVM", "Error in loadRitual", e)
                "Operation failed."
            } finally {
                isBusy = false
            }
        }
    }
}
