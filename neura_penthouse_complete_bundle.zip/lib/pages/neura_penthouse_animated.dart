// lib/pages/neura_penthouse_animated.dart
// (Paste your NeuraPenthouseAnimatedPage code here)
