// lib/widgets/neura_avatar.dart
// (Paste your NeuraAvatarWidget code here)
