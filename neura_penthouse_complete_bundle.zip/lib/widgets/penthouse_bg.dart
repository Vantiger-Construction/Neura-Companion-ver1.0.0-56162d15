// lib/widgets/penthouse_bg.dart
// (Paste your PenthouseBG code here)
