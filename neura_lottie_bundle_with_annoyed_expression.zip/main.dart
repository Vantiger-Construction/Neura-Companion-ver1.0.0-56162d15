
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

void main() => runApp(const NeuraApp());

class NeuraApp extends StatelessWidget {
  const NeuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Lottie.asset('assets/wave_smile_hello.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/idle_breathing_glow.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/peace_sign_cheer.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/celebrate_raise_arms.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/listening_mode_ear_glow.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/sad_reflective_look.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/hug_open_arms.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/sleep_curl_mode.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/surprised_blink.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/smirk_sideways.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/hopeful_eyes.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/skeptical_look.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/confident_gaze.json'),
              SizedBox(height: 20),
              Lottie.asset('assets/annoyed_puff.json'),
            ],
          ),
        ),
      ),
    );
  }
}
