
import 'package:flutter/material.dart';

class MoodArchiveScreen extends StatelessWidget {
  final bool isPro;
  const MoodArchiveScreen({super.key, required this.isPro});

  @override
  Widget build(BuildContext context) {
    if (!isPro) {
      return const Center(
        child: Text("Upgrade to Pro to access full Mood Archive."),
      );
    }
    return Scaffold(
      appBar: AppBar(title: const Text("Mood Archive")),
      body: const Center(child: Text("Coming soon: full mood timeline and export tools")),
    );
  }
}
