
import 'package:flutter/material.dart';

class ForecastTransitionAnimator extends StatefulWidget {
  final String newForecast;
  const ForecastTransitionAnimator({super.key, required this.newForecast});

  @override
  State<ForecastTransitionAnimator> createState() => _ForecastTransitionAnimatorState();
}

class _ForecastTransitionAnimatorState extends State<ForecastTransitionAnimator> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fade = Tween(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: Text(
        widget.newForecast,
        style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.amber),
        textAlign: TextAlign.center,
      ),
    );
  }
}
