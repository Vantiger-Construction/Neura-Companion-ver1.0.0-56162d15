
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'mood_animation_hook.dart';
import '../../services/mood/mood_content_variations.dart';

class EmotionalForecastWidget extends StatefulWidget {
  final String mood;
  const EmotionalForecastWidget({super.key, required this.mood});

  @override
  State<EmotionalForecastWidget> createState() => _EmotionalForecastWidgetState();
}

class _EmotionalForecastWidgetState extends State<EmotionalForecastWidget> {
  final FlutterTts tts = FlutterTts();

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 500), () {
      _speakForecast();
    });
  }

  void _speakForecast() {
    final tip = MoodContentVariations.getDashboardTip(widget.mood);
    tts.speak("Today's forecast: " + tip);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        MoodReactionWidget(currentMood: widget.mood),
        const SizedBox(height: 12),
        Text(
          MoodContentVariations.getDashboardTip(widget.mood),
          style: Theme.of(context).textTheme.bodyLarge,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
