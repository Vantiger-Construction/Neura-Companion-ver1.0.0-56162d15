
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../services/mood/mood_weekly_tracker.dart';

class MoodWeeklyGraph extends StatelessWidget {
  final MoodWeeklyTracker tracker;
  const MoodWeeklyGraph({super.key, required this.tracker});

  @override
  Widget build(BuildContext context) {
    final data = tracker.getWeeklyMoodCounts();
    final moods = data.keys.toList();
    final counts = data.values.map((e) => e.toDouble()).toList();

    return Scaffold(
      appBar: AppBar(title: const Text("Weekly Mood Trends")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: BarChart(
          BarChartData(
            barGroups: List.generate(moods.length, (i) {
              return BarChartGroupData(
                x: i,
                barRods: [
                  BarChartRodData(toY: counts[i], width: 14, color: Colors.tealAccent)
                ],
              );
            }),
            titlesData: FlTitlesData(
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(showTitles: true, getTitlesWidget: (value, _) {
                  return Text(moods[value.toInt()]);
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
