
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class MoodSparklineTile extends StatelessWidget {
  final List<double> moodValues;
  const MoodSparklineTile({super.key, required this.moodValues});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: SizedBox(
        height: 80,
        child: LineChart(
          LineChartData(
            lineBarsData: [
              LineChartBarData(
                isCurved: true,
                spots: List.generate(moodValues.length, (i) => FlSpot(i.toDouble(), moodValues[i])),
                belowBarData: BarAreaData(show: false),
                dotData: FlDotData(show: false),
                color: Colors.orangeAccent,
              )
            ],
            titlesData: FlTitlesData(show: false),
            gridData: FlGridData(show: false),
            borderData: FlBorderData(show: false),
          ),
        ),
      ),
    );
  }
}
