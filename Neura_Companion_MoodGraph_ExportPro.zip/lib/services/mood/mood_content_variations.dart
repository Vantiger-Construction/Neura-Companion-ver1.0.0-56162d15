
class MoodContentVariations {
  static String getRitualSuggestion(String mood) {
    switch (mood.toLowerCase()) {
      case 'happy':
        return "Keep the joy flowing! Try a gratitude ritual.";
      case 'sad':
        return "Gentle breathwork may help center your emotions.";
      case 'anxious':
        return "Try a grounding ritual to calm your nerves.";
      case 'angry':
        return "Release tension with a quick venting journal.";
      case 'confident':
        return "Push a goal forward—you're on fire!";
      default:
        return "Begin your day with a mood-aware mindfulness ritual.";
    }
  }

  static String getJournalPrompt(String mood) {
    switch (mood.toLowerCase()) {
      case 'happy':
        return "What made today feel brighter?";
      case 'sad':
        return "Where do you feel the sadness in your body?";
      case 'anxious':
        return "What’s one thing you *can* control right now?";
      case 'angry':
        return "What’s beneath the frustration?";
      case 'confident':
        return "What strength did you show today?";
      default:
        return "How do you feel right now?";
    }
  }

  static String getDashboardTip(String mood) {
    switch (mood.toLowerCase()) {
      case 'happy':
        return "Your happiness is contagious. Share the vibe!";
      case 'sad':
        return "Low days are part of growth. You're not alone.";
      case 'anxious':
        return "Focus on the present moment. You're doing enough.";
      case 'angry':
        return "Take a breath. It’s okay to feel this way.";
      case 'confident':
        return "You’re thriving. Set your sights even higher.";
      default:
        return "Check in with yourself. Your feelings matter.";
    }
  }
}
