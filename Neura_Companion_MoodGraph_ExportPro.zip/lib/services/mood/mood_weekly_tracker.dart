
import 'package:intl/intl.dart';

class MoodWeeklyTracker {
  final Map<String, List<String>> _moodHistory = {};

  void logMood(String mood) {
    final String date = DateFormat('EEE').format(DateTime.now());
    _moodHistory.putIfAbsent(date, () => []).add(mood);
  }

  Map<String, int> getWeeklyMoodCounts() {
    final Map<String, int> counts = {};
    for (final entry in _moodHistory.entries) {
      for (final mood in entry.value) {
        counts[mood] = (counts[mood] ?? 0) + 1;
      }
    }
    return counts;
  }

  List<String> getLoggedDays() => _moodHistory.keys.toList();
}
