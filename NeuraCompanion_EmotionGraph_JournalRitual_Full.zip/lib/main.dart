
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'modules/mood/mood_log.dart';
import 'modules/journal/journal_screen.dart';
import 'modules/ritual/ritual_screen.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => MoodLog(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool showRitual = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text(showRitual ? "Ritual Tracker" : "Journal Tracker"),
          actions: [
            IconButton(
              icon: Icon(Icons.swap_horiz),
              onPressed: () => setState(() => showRitual = !showRitual),
            )
          ],
        ),
        body: showRitual ? RitualScreen() : JournalScreen(),
      ),
    );
  }
}
