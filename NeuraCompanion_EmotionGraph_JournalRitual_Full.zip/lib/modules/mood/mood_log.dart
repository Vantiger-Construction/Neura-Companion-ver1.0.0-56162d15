
import 'package:flutter/foundation.dart';

class MoodEntry {
  final DateTime timestamp;
  final String emotion;
  final double intensity;

  MoodEntry(this.timestamp, this.emotion, this.intensity);
}

class MoodLog with ChangeNotifier {
  List<MoodEntry> _entries = [
    MoodEntry(DateTime.now().subtract(Duration(days: 0)), 'joy', 0.8),
    MoodEntry(DateTime.now().subtract(Duration(days: 1)), 'sad', 0.5),
    MoodEntry(DateTime.now().subtract(Duration(days: 2)), 'calm', 0.6),
    MoodEntry(DateTime.now().subtract(Duration(days: 3)), 'anger', 0.3),
    MoodEntry(DateTime.now().subtract(Duration(days: 4)), 'joy', 0.9),
    MoodEntry(DateTime.now().subtract(Duration(days: 5)), 'calm', 0.7),
    MoodEntry(DateTime.now().subtract(Duration(days: 6)), 'sad', 0.4),
  ];

  List<MoodEntry> get entries => _entries;

  void addEntry(MoodEntry entry) {
    _entries.add(entry);
    notifyListeners();
  }
}
