#!/bin/bash
echo 'Launching Neura Companion on Linux...'
xdg-open lib/main.dart
