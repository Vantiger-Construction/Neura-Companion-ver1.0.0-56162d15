#!/bin/bash
echo 'Launching Neura Companion on macOS...'
open lib/main.dart
