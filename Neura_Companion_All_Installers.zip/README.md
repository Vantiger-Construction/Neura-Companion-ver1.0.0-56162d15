# Neura Companion README with module descriptions
