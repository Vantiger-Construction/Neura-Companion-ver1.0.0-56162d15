// main.dart - Neura Companion entry point
