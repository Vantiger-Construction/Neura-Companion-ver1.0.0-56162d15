module.exports = {
  docs: [
    'intro',
    {
      type: 'category',
      label: 'Tutorial',
      items: ['tutorial/getting-started'],
    },
    {
      type: 'category',
      label: 'API Reference',
      items: ['api'],
    },
    {
      type: 'category',
      label: 'SDKs',
      items: [
        'sdk/python',
        'sdk/typescript',
        'sdk/react-native',
        'sdk/flutter',
        'sdk/go',
        'sdk/java',
        'sdk/php',
      ],
    },
    'architecture',
  ],
};
