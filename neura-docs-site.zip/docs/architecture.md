# Architecture Overview

```mermaid
flowchart LR
  A[Client App] -->|HTTP| B[FastAPI Neura API]
  B --> C[Auth Service]
  B --> D[CORS & Middleware]
  B --> E[Webhook Handler]
  E --> F[Celery Queue]
  F --> G[Worker Processes]
  G --> H[External Webhook Targets]
  F --> I[Redis Cache]
  B --> J[Prometheus Metrics]
  B --> K[AuditLog (DB)]
  B --> L[AI Error Handler]
  B --> M[WebSocket Manager]
```
