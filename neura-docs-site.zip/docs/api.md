# API Reference

## Authentication
- **POST** `/v1/auth/token` - Obtain JWT token  
- **POST** `/v1/auth/refresh` - Refresh access token  
- **DELETE** `/v1/auth/logout` - Revoke refresh token  

## Resources
- **GET** `/v1/resources` - Paginated list of resources  

## Webhooks
- **POST** `/v1/webhooks/subscribe` - Create subscription  
- **GET** `/v1/webhooks/subscriptions` - List subscriptions  
- **DELETE** `/v1/webhooks/subscriptions/{id}` - Remove subscription  
- **GET** `/v1/webhooks/subscriptions/{id}/history` - Delivery history  
- **GET** `/v1/webhooks/subscriptions/{id}/status` - Last delivery status  
- **POST** `/v1/webhooks/receive` - Receive events (HMAC-secured)  
- **POST** `/v1/webhooks/legacy` - Legacy trigger endpoint
