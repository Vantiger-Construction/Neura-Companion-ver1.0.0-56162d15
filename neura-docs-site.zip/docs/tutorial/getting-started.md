# Getting Started

## 1. Authenticate
```bash
curl -X POST https://api.neura.app/v1/auth/token \
  -d "username=alice" \
  -d "password=secret"
```

## 2. List Resources
```bash
curl -H "Authorization: Bearer <token>" \
  https://api.neura.app/v1/resources
```

## 3. Subscribe to Webhooks
```bash
curl -X POST https://api.neura.app/v1/webhooks/subscribe \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"url":"https://example.com/hooks","eventType":"resource.created"}'
```

## 4. Receive Events
Handle incoming HMAC-signed POSTs to your endpoint and respond with 2xx status codes.
