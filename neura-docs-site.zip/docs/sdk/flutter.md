# Flutter Plugin

```yaml
dependencies:
  neura_flutter_sdk: ^0.1.0
```

```dart
import 'package:neura_flutter_sdk/neura_flutter_sdk.dart';
final client = NeuraClient('https://api.neura.app', '<token>');
print(await client.listResources());
```
