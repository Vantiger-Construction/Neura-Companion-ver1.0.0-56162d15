# TypeScript SDK

```bash
npm install @neura/sdk
```

```ts
import { NeuraClient } from '@neura/sdk';
const client = new NeuraClient('https://api.neura.app', '<token>');
console.log(await client.listResources());
```
