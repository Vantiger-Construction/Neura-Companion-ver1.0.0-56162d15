# Java SDK

Maven dependency:
```xml
<dependency>
  <groupId>com.neura</groupId>
  <artifactId>neura-java-sdk</artifactId>
  <version>0.1.0</version>
</dependency>
```

```java
NeuraClient client = new NeuraClient("https://api.neura.app", "<token>");
String resp = client.listResources(0,5);
```
