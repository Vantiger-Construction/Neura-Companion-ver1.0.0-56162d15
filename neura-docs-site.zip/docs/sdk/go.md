# Go SDK

```bash
go get github.com/neura/sdk-go
```

```go
client := neura.NewClient("https://api.neura.app", "<token>")
resp, _ := client.ListResources(0, 10)
```
