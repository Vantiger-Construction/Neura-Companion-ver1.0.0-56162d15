# React Native SDK

```bash
npm install @neura/react-native-sdk
```

```js
import { createNeuraClient } from '@neura/react-native-sdk';
const client = createNeuraClient('https://api.neura.app', '<token>');
console.log(await client.listResources());
```
