# Python SDK

```bash
pip install neura_sdk
```

```python
from neura_sdk.client import NeuraClient
client = NeuraClient('https://api.neura.app', '<token>')
print(client.list_resources())
```
