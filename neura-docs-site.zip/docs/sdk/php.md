# PHP SDK

```bash
composer require neura/sdk-php
```

```php
$client = new Neura\Sdk\NeuraClient('https://api.neura.app', '<token>');
print_r($client->listResources());
```
