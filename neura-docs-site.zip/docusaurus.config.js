module.exports = {
  title: 'Neura API Documentation',
  tagline: 'Developer and User Guides',
  url: 'https://docs.neura.app',
  baseUrl: '/',
  onBrokenLinks: 'throw',
  onBrokenMarkdownLinks: 'warn',
  favicon: 'img/favicon.ico',
  organizationName: 'your-org',
  projectName: 'neura-api',
  themeConfig: {
    navbar: {
      title: 'Neura Docs',
      items: [
        { to: 'docs/intro', label: 'Tutorial', position: 'left' },
        { to: 'docs/api', label: 'API', position: 'left' },
        { to: 'docs/sdk/python', label: 'SDKs', position: 'left' },
        { to: 'docs/architecture', label: 'Architecture', position: 'left' },
      ],
    },
  },
  presets: [
    [
      '@docusaurus/preset-classic',
      {
        docs: {
          routeBasePath: 'docs',
          sidebarPath: require.resolve('./sidebars.js'),
          editUrl: 'https://github.com/your-org/neura-api/edit/main/',
        },
        theme: {
          customCss: require.resolve('./src/css/custom.css'),
        },
      },
    ],
  ],
};
