
import 'package:flutter/material.dart';
import '../state/neura_mood_manager.dart';

class NeuraFaceWidget extends StatelessWidget {
  final NeuraMood mood;

  NeuraFaceWidget({required this.mood});

  String getImageForMood() {
    switch (mood) {
      case NeuraMood.joy: return 'assets/neura_happy.png';
      case NeuraMood.calm: return 'assets/neura_calm.png';
      case NeuraMood.sad: return 'assets/neura_sad.png';
      case NeuraMood.angry: return 'assets/neura_angry.png';
      case NeuraMood.anxious: return 'assets/neura_anxious.png';
      default: return 'assets/neura_idle.png';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: 20,
      right: 20,
      child: Container(
        width: 150,
        height: 150,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(getImageForMood()),
            fit: BoxFit.contain,
          ),
        ),
      ),
    );
  }
}
