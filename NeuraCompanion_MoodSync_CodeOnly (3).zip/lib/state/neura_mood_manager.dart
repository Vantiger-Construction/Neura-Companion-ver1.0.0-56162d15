
import 'package:flutter/material.dart';

enum NeuraMood {
  joy,
  calm,
  sad,
  angry,
  anxious,
  neutral,
}

class NeuraMoodManager with ChangeNotifier {
  NeuraMood _currentMood = NeuraMood.neutral;

  NeuraMood get mood => _currentMood;

  void setMood(NeuraMood newMood) {
    _currentMood = newMood;
    notifyListeners();
  }
}
