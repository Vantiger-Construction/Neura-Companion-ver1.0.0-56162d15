
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'state/neura_mood_manager.dart';
import 'widgets/neura_face_widget.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => NeuraMoodManager(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final moodManager = Provider.of<NeuraMoodManager>(context);

    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("Neura Companion")),
        body: Stack(
          children: [
            Center(
              child: Text("Your Neura Companion Content Goes Here"),
            ),
            NeuraFaceWidget(mood: moodManager.mood),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            final current = moodManager.mood;
            final next = NeuraMood.values[(NeuraMood.values.indexOf(current) + 1) % NeuraMood.values.length];
            moodManager.setMood(next);
          },
          child: Icon(Icons.change_circle),
        ),
      ),
    );
  }
}
