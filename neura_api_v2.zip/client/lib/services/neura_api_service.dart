import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class NeuraApiService {
  final String baseUrl;
  final FlutterSecureStorage storage;
  String? _token;

  NeuraApiService({required this.baseUrl, required this.storage});

  Future<void> login(String email, String password) async {
    final res = await http.post(Uri.parse('\$baseUrl/api/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}));
    final body = jsonDecode(res.body);
    _token = body['token'];
    await storage.write(key: 'jwt', value: _token);
  }

  Future<void> register(String email, String password) async {
    await http.post(Uri.parse('\$baseUrl/api/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}));
  }

  Future<List<dynamic>> fetchJokes() async {
    await _loadToken();
    final res = await http.get(Uri.parse('\$baseUrl/api/jokes'),
      headers: { 'Authorization': 'Bearer \$_token' });
    return jsonDecode(res.body);
  }

  Future<void> _loadToken() async {
    if (_token == null) {
      _token = await storage.read(key: 'jwt');
    }
  }
}
