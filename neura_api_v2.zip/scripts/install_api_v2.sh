#!/usr/bin/env bash
set -e
echo "Installing Neura API v2..."
cd backend && npm install
echo "✔ Backend dependencies installed."
