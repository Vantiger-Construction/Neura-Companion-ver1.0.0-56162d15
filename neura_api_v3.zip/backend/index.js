require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');

const auth = require('./routes/auth');
const jokes = require('./routes/jokes');
const dreams = require('./routes/dreams');
const settings = require('./routes/settings');
const memory = require('./routes/memory');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Routes
app.use('/api/auth', auth);
app.use('/api/jokes', jokes);
app.use('/api/dreams', dreams);
app.use('/api/settings', settings);
app.use('/api/memory', memory);
const shop = require('./routes/shop');
app.use('/api/shop', shop);

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: err.message });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Neura API v2 running on port ${PORT}`));
