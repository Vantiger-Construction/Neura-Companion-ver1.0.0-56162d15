import httpx
from src.security import verify_replay, sign_payload
"""Webhook handlers and event handoff logic"""

from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from typing import Dict

router = APIRouter()

subscriptions: Dict[str, BaseModel] = {}

class WebhookSubscription(BaseModel):
    id: str = None
    url: str
    eventType: str

class WebhookStatus(BaseModel):
    id: str
    status: str
    lastAttempt: str

@router.post("/subscribe", status_code=201)
async def subscribe(sub: WebhookSubscription):
    sub.id = "sub" + sub.url[-4:]
    subscriptions[sub.id] = sub
    return sub

@router.get("/subscriptions/{id}/status")
async def get_status(id: str):
    if id not in subscriptions:
        raise HTTPException(status_code=404, detail="Subscription not found")
    # Stub status
    return WebhookStatus(id=id, status="pending", lastAttempt="2025-07-19T00:00:00Z")

@router.post("/receive")
async def receive_event(request: Request):
    timestamp = request.headers.get("X-Timestamp")
    signature = request.headers.get("X-Signature")
    body = await request.body()
    if not timestamp or not signature or not verify_replay(timestamp):
        raise HTTPException(status_code=400, detail="Invalid or missing signature/timestamp")
    expected_sig = sign_payload(os.getenv("WEBHOOK_SECRET", "secret"), body)
    if not hmac.compare_digest(expected_sig, signature):
        raise HTTPException(status_code=401, detail="Signature verification failed")
    event = await request.json()
    # Dispatch to subscribers asynchronously
    results = []
    for sub in subscriptions.values():
        try:
            resp = await httpx.post(sub.url, json=event)
            results.append({"id": sub.id, "status": resp.status_code})
        except Exception as e:
            results.append({"id": sub.id, "status": "error"})
    return {"dispatched": results}
