"""Main application entry point for Neura API"""

from fastapi import FastAPI
from src.auth import router as auth_router
from src.webhooks import router as webhooks_router
from src.resources import router as resources_router
from src.rate_limit import init_rate_limiter

app = FastAPI(docs_url="/docs", openapi_url="/openapi.json")
init_rate_limiter(app)

app.include_router(auth_router, prefix="/auth", tags=["auth"])
app.include_router(webhooks_router, prefix="/webhooks", tags=["webhooks"])

    app.include_router(resources_router, prefix="/resources", tags=["resources"])
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
