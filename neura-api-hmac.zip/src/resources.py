"""Resource listing endpoint with cursor-based pagination"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from src.pagination import paginate_list

router = APIRouter()

class Resource(BaseModel):
    id: str
    name: str

class PageInfo(BaseModel):
    nextCursor: Optional[str]
    prevCursor: Optional[str]

class PaginatedResources(BaseModel):
    items: List[Resource]
    pageInfo: PageInfo

# Dummy in-memory resources
_resources = [Resource(id=str(i), name=f"Resource {i}") for i in range(1, 101)]

@router.get("/", response_model=PaginatedResources)
async def list_resources(cursor: Optional[str] = None, limit: int = 50):
    data = paginate_list([r.dict() for r in _resources], cursor, limit)
    return data