"""Tests for the /resources endpoint"""

from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_list_resources_default():
    resp = client.get("/resources")
    assert resp.status_code == 200
    data = resp.json()
    assert "items" in data and "pageInfo" in data
    assert len(data["items"]) == 50

def test_list_resources_cursor_limit():
    resp = client.get("/resources?cursor=10&limit=20")
    assert resp.status_code == 200
    data = resp.json()
    assert data["items"][0]["id"] == "11"
    assert len(data["items"]) == 20