"""Tests for webhook receive with HMAC verification"""

import os
import hmac
import hashlib
from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_receive_event_success(monkeypatch):
    secret = "secret"
    monkeypatch.setenv("WEBHOOK_SECRET", secret)
    payload = {"foo": "bar"}
    body = b'{"foo":"bar"}'
    # correct timestamp within window
    timestamp = str(int(__import__('time').time()))
    sig = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    resp = client.post("/webhooks/receive", json=payload, headers={"X-Timestamp": timestamp, "X-Signature": sig})
    assert resp.status_code == 200
    data = resp.json()
    assert "dispatched" in data

def test_receive_event_invalid_signature():
    timestamp = str(int(__import__('time').time()))
    resp = client.post("/webhooks/receive", json={"foo": "bar"}, headers={"X-Timestamp": timestamp, "X-Signature": "bad"})
    assert resp.status_code == 401
