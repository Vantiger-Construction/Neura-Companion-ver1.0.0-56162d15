// BottomNav implementation with all tabs
