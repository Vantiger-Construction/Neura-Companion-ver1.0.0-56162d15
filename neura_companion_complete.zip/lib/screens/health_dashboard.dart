// HealthDashboardScreen implementation
