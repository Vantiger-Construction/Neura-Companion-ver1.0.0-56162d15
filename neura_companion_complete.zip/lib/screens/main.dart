// main.dart with PersonaSelection and BottomNav
