// TeachingScreen with Syllabus, Lesson, Quiz tabs and animations
