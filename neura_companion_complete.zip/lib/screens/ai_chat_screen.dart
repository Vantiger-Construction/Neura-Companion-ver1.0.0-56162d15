// AIChatScreen implementation
