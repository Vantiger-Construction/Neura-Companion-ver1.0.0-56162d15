// GoalTrackerScreen implementation
