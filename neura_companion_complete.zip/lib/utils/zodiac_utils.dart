// Zodiac utilities implementation
