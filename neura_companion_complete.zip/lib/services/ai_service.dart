// Full AIService implementation as per previous discussions
