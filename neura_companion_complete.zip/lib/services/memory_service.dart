// Full MemoryService implementation
