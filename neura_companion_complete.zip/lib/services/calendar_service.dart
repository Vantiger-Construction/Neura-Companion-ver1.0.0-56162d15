// Full CalendarService implementation
