// Full NotificationService implementation
