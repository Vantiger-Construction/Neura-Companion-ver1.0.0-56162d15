// Full UserProfileService implementation
