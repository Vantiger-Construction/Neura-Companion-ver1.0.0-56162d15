// Full HealthService implementation
