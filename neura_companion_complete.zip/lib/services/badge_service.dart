// Full BadgeService implementation
