// Full ReinforcementService implementation
