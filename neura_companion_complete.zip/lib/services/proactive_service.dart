// Full ProactiveService implementation
