// Unit tests for CalendarService
