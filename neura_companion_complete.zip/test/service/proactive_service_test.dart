// Unit tests for ProactiveService
