# Neura Companion
The ultimate AI-powered wellness companion app.

## Contents
- **scripts/**: merge/build automation.
- **lib/**: source code (services, screens, utils).
- **assets/**: Lottie animations, sounds, icons.
- **test/**: unit and widget tests.
- **legal/**: disclaimer, privacy policy, terms.
- **.idea/**: IntelliJ run configuration.

## Setup & Build
1. Run `scripts/merge_and_build.ps1` on Windows.
2. Open in IntelliJ or Android Studio.
3. Run `flutter pub get` and `flutter pub run build_runner build`.
4. Build and run on your device/emulator.
