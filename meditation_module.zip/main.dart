
import 'package:flutter/material.dart';
import 'dashboard.dart';

void main() {
  runApp(NeuroCompanionApp());
}

class NeuroCompanionApp extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neuro Companion',
      theme: import // Add this single line at the top of your lib/main.dart file:
import 'package:flutter/material.dart';
 'package:flutter/material.dart';  // Put import at the top of file

class NeuroCompanionApp extends StatelessWidget {
  @override  // Add this annotation
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neuro Companion',
      theme: ThemeData(
        // Your theme customizations
        primarySwatch: Colors.blue,
        // etc.
      ),
      home: YourHomeWidget(),  // Add your home widget here
    );
  }
}
(
  theme: ThemeData(
    // Your theme customizations
    primarySwatch: Colors.blue,
    // etc.
  ),
  // rest of your app
)
 'package:flutter/material.dart';  // Complete the import statement

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('My App'),
        ),
        body: Center(
          child: Text('Hello World'),
        ),
      ),
    );
  }
}
 'package:flutter/material.dart'; // This import is essential

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: const Center(child: Text('Hello World')),
    );
  }
}
 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My App',
      theme: ThemeData(
        // Enable Material 3
        useMaterial3: true,
        
        // Color scheme
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.light,
        ),
        
        // AppBar theme
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 2,
        ),
        
        // Text theme
        textTheme: const TextTheme(
          headlineMedium: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
          bodyMedium: TextStyle(
            fontSize: 16,
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Welcome',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 16),
            Text(
              'This is a sample app',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }
}
;

class NeuroCompanionApp extends StatelessWidget {
  @override  // Add this annotation for best practice
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neuro Companion',
      theme: ThemeData.dark(),
      home: DashboardScreen(),
    );
  }
}
.dark(),
      home: DashboardScreen(),
    );
  }
}

class MaterialApp {
}
