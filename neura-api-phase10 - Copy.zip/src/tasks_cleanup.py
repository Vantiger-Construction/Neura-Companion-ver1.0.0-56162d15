from celery_app import celery_app
from src.db import get_session
from src.models import AuditLog
from datetime import datetime, timedelta

@celery_app.task
def purge_old_audit_logs(days: int = 90):
    session = next(get_session())
    cutoff = datetime.utcnow() - timedelta(days=days)
    session.query(AuditLog).filter(AuditLog.timestamp < cutoff).delete()
    session.commit()
    session.close()
