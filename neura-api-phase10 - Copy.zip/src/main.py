from fastapi import FastAPI
from src.correlation import correlation_middleware
# ... other imports ...

app = FastAPI()

# Register correlation middleware early
app.middleware("http")(correlation_middleware)

# ... existing middleware and routes ...
