import os
import boto3
from botocore.exceptions import BotoCoreError

def get_secret(kms_key_id: str, secret_name: str) -> str:
    try:
        client = boto3.client('secretsmanager')
        response = client.get_secret_value(SecretId=secret_name)
        return response['SecretString']
    except BotoCoreError:
        return os.getenv(secret_name)
