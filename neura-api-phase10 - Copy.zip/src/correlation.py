import uuid
from fastapi import Request
from src.logging_config import logger

async def correlation_middleware(request: Request, call_next):
    # Generate or propagate correlation ID
    corr_id = request.headers.get("X-Correlation-ID") or str(uuid.uuid4())
    request.state.correlation_id = corr_id
    logger.bind(correlation_id=corr_id).info(f"Request start: {request.method} {request.url.path}")
    response = await call_next(request)
    response.headers["X-Correlation-ID"] = corr_id
    logger.bind(correlation_id=corr_id).info(f"Request end: {request.method} {request.url.path} - {response.status_code}")
    return response
