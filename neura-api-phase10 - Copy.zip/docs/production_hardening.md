# Production Hardening

## Secrets Management
- Use AWS KMS or Vault for secrets via `src/secrets_kms.py` or `src/secrets.py`.
- Rotate keys every 90 days.

## Blue-Green Deployments
- Deploy new version (`green`) alongside `blue`.
- Switch Service selector to point to `green` when ready.
- Rollback by switching back.

## Auto-Scaling
- HPA configured via `k8s/hpa.yaml` for CPU-based scaling.

## Monitoring & Alerting
- Alerts configured in `monitoring/prometheus/alert_rules.yml`.
- Dashboards in `monitoring/grafana/`.

## Compliance
- Audit logs retention and GDPR anonymization endpoint.
