# Compliance & Auditing

## Audit Log Retention
- Audit logs are stored in the `auditlog` table.
- Logs older than 90 days will be purged via scheduled job.

## Data Encryption
- All sensitive data in transit is secured via TLS.
- At rest encryption is enforced on database and log storage.

## GDPR Compliance
- Audit logs and user-related data can be anonymized via `DELETE /v1/user/{id}/anonymize` endpoint.
- Request data retention policy: 30 days.

## Access Auditing
- Admin users can query audit trails via `/v1/admin/auditlogs`.
- Access to audit logs is RBAC protected (`roles: ["admin"]`).
