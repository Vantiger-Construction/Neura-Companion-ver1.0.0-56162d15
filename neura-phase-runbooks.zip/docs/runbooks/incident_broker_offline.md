# Incident Response: Message Broker Offline

## Symptoms
- Webhook dispatch tasks failing or queuing indefinitely
- Celery worker logs show connection errors to Redis/RabbitMQ

## Immediate Actions
1. Check broker status:
   ```bash
   kubectl get pods -l app=redis
   kubectl logs redis-0
   ```
2. Restart broker service:
   ```bash
   kubectl rollout restart deployment/redis
   ```
3. Confirm Celery connectivity:
   ```bash
   kubectl exec -it neura-api-0 -- celery -A src.celery_app status
   ```

## Mitigation
- Reconfigure Celery retry/backoff settings if flooding.
- Scale worker replicas if backlog high.

## Recovery
- Monitor queue length and worker success rate.
- Ensure webhook deliveries resume.
