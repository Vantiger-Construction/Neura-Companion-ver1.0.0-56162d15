# Incident Response: Database Down

## Symptoms
- API returns 500 errors on resource or webhook operations
- Health check `/healthz` or `/readyz` shows DB connectivity failure

## Immediate Actions
1. Check database status:
   ```bash
   kubectl logs neura-db-0
   # or connect via psql
   psql $DATABASE_URL -c "\l"
   ```
2. Restart the DB pod or failover if using replicas:
   ```bash
   kubectl rollout restart statefulset/neura-db
   ```
3. Verify connection from API:
   ```bash
   curl http://neura-api:8000/readyz
   ```

## Mitigation
- Promote a read replica to primary if failover needed.
- Restore from backup if data corruption is detected.

## Recovery
- Ensure API metrics (`error_count`, `request_latency_seconds`) return to normal.
- Monitor `/metrics` and Grafana dashboards.
