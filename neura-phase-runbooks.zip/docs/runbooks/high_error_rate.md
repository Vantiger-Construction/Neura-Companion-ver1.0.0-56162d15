# Incident Response: High Error Rate

## Symptoms
- Grafana alert `HighErrorRate` triggered (error rate >5% over 5m)
- Clients reporting API failures

## Immediate Actions
1. Identify failing endpoints:
   ```promql
   sum by (endpoint)(rate(error_count[5m]))
   ```
2. Tail real-time logs for errors:
   ```bash
   kubectl logs deployment/neura-api -f
   ```
3. Rollback recent deployments if new code suspect:
   ```bash
   kubectl rollout undo deployment/neura-api
   ```

## Mitigation
- If rate limit misconfiguration, adjust `slowapi` settings.
- Patch any discovered bugs via emergency PR.

## Recovery
- Confirm error rate drops below threshold.
- Validate via synthetic requests.
