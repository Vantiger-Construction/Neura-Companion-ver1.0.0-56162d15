Neura Companion – Multi-Platform Build

📱 Android APK: NeuraCompanion_Android.apk
🪟 Windows EXE: NeuraCompanion_Windows.exe
🌐 Web Preview: NeuraCompanion_WebPreview/index.html

You can replace these placeholder files with your actual builds once compiled.