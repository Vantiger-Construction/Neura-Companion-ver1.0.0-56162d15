
@echo off
setlocal ENABLEDELAYEDEXPANSION

set LOGFILE=neura_setup_log.txt
echo Neura Install Log > %LOGFILE%

:: =========== CONFIG ===========
set INSTALL_DIR=NeuraInstallSource
set APP_DIR=%INSTALL_DIR%\NeuraCompanion
set FLUTTER_ZIP_URL=https://storage.googleapis.com/flutter_infra_release/releases/stable/windows/flutter_windows_3.13.0-stable.zip
set FLUTTER_ZIP=flutter_windows.zip
set FLUTTER_DIR=%CD%\flutter
set CODE_ZIP=NeuraCompanion_MoodSync_CodeOnly.zip
set ZIPS=NeuraCompanion_Asset_Idle.zip NeuraCompanion_Asset_Happy.zip NeuraCompanion_Asset_Calm.zip NeuraCompanion_Asset_Sad.zip NeuraCompanion_Asset_Angry.zip NeuraCompanion_Asset_Anxious.zip

:: =========== AI CONSOLE ===========
echo 💡 [Neura AI] Initiating system integrity check...
if not exist %CODE_ZIP% (
    echo ❌ [Neura AI] Missing: %CODE_ZIP%. >> %LOGFILE%
    echo 😬 Neura can't run without her brain. Place the code ZIP next to this file.
    pause
    exit /b
)

for %%F in (%ZIPS%) do (
    if not exist "%%F" (
        echo ❌ [Neura AI] Missing: %%F >> %LOGFILE%
        echo 🤖 I need all 6 emotion modules! Missing: %%F
        pause
        exit /b
    )
)

:: =========== GIT CHECK ===========
git --version >nul 2>&1
if %errorlevel% neq 0 (
    echo 🛠 [Neura AI] Git not found. Fetching it for you... >> %LOGFILE%
    powershell -Command "Invoke-WebRequest -Uri https://github.com/git-for-windows/git/releases/latest/download/Git-2.43.0-64-bit.exe -OutFile git_installer.exe"
    start /wait git_installer.exe /VERYSILENT
    del git_installer.exe
)

:: =========== FLUTTER INSTALL ===========
if not exist "%FLUTTER_DIR%" (
    echo 🛠 [Neura AI] Flutter not found. Downloading... >> %LOGFILE%
    powershell -Command "Invoke-WebRequest -Uri %FLUTTER_ZIP_URL% -OutFile %FLUTTER_ZIP%"
    powershell -Command "Expand-Archive -Path '%FLUTTER_ZIP%' -DestinationPath ."
    rename flutter flutter_temp
    move flutter_temp\flutter flutter
    rmdir /s /q flutter_temp
    del "%FLUTTER_ZIP%"
)

:: PATH injection
set PATH=%FLUTTER_DIR%\bin;%PATH%
where flutter >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ [Neura AI] Flutter command not detected even after setup! Try restarting CMD or setting PATH manually.
    pause
    exit /b
)

:: =========== FOLDER SETUP ===========
rmdir /s /q "%INSTALL_DIR%" 2>nul
mkdir "%APP_DIR%\assets"
echo ✅ [Neura AI] Fresh folders ready.

:: =========== UNZIP CODE ===========
echo 📦 [Neura AI] Unzipping Neura's core code...
powershell -Command "Expand-Archive -Path '%CODE_ZIP%' -DestinationPath '%APP_DIR%'" || (
    echo ⚠️ PowerShell unzip failed. Trying fallback...
    tar -xf "%CODE_ZIP%" -C "%APP_DIR%"
)

:: =========== UNZIP FACE MODULES ===========
echo 🧠 [Neura AI] Installing emotional overlays...
for %%F in (%ZIPS%) do (
    powershell -Command "Expand-Archive -Path '%%F' -DestinationPath '%APP_DIR%'" || (
        echo ⚠️ Fallback unzip: %%F
        tar -xf "%%F" -C "%APP_DIR%"
    )
)

:: =========== FLUTTER GET & RUN ===========
cd "%APP_DIR%"
echo 🔄 [Neura AI] Fetching dependencies...
flutter pub get || (
    echo ❌ [Neura AI] Flutter pub get failed. Trying again in 5s...
    timeout /t 5 >nul
    flutter pub get
)

echo 🚀 [Neura AI] Launching app into your dimension...
flutter run

:: Log complete
echo ✅ Neura Companion is up and running. > %LOGFILE%
pause
