
🧠 Neura AI Installer - README

This bundle contains:
- neura_autoheal_setup.bat: A self-healing Windows batch installer for the Neura Companion app.
- Instructions for placement of asset/code ZIPs.
- Auto-download of Git and Flutter if missing.
- Logs and fixes common setup issues.

💡 To use:
1. Place the following ZIP files in this folder:
   - NeuraCompanion_MoodSync_CodeOnly.zip
   - NeuraCompanion_Asset_Idle.zip
   - NeuraCompanion_Asset_Happy.zip
   - NeuraCompanion_Asset_Calm.zip
   - NeuraCompanion_Asset_Sad.zip
   - NeuraCompanion_Asset_Angry.zip
   - NeuraCompanion_Asset_Anxious.zip

2. Run the batch file:
   - Right-click `neura_autoheal_setup.bat` → Run as Administrator

It will handle the full setup and build process for Windows.
