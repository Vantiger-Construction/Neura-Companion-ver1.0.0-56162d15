# Neura Lottie Animation

This bundle contains the Lottie JSON and preview for Neura's wave animation.