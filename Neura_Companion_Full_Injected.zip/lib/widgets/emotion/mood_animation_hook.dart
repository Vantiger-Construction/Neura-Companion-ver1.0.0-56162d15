
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'emotion_lottie_mapper.dart';

class MoodReactionWidget extends StatelessWidget {
  final String currentMood;

  const MoodReactionWidget({super.key, required this.currentMood});

  @override
  Widget build(BuildContext context) {
    final lottieAsset = EmotionLottieMapper.getLottieForEmotion(currentMood);
    return Column(
      children: [
        Text("Neura senses you feel: $currentMood", style: Theme.of(context).textTheme.headline6),
        const SizedBox(height: 12),
        Lottie.asset(lottieAsset, width: 200),
      ],
    );
  }
}
