
class EmotionLottieMapper {
  static String getLottieForEmotion(String emotion) {
    switch (emotion.toLowerCase()) {
      case 'happy':
        return 'assets/lottie/neura_happy_spin.json';
      case 'sad':
        return 'assets/lottie/neura_sad_drift.json';
      case 'angry':
        return 'assets/lottie/neura_fire_react.json';
      case 'anxious':
        return 'assets/lottie/neura_breathe_calm.json';
      case 'confident':
        return 'assets/lottie/neura_glow_up.json';
      case 'neutral':
      default:
        return 'assets/lottie/neura_react_idle.json';
    }
  }
}
