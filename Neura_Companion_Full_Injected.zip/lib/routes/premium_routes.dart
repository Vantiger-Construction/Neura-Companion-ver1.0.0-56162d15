
import 'package:flutter/material.dart';

class PremiumRouteGuard extends StatelessWidget {
  final Widget child;
  final bool isPremiumUser;

  const PremiumRouteGuard({
    Key? key,
    required this.child,
    required this.isPremiumUser,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (isPremiumUser) {
      return child;
    } else {
      return Scaffold(
        appBar: AppBar(title: const Text("Premium Access Required")),
        body: const Center(
          child: Text("Upgrade to Pro Mode to access this feature."),
        ),
      );
    }
  }
}
