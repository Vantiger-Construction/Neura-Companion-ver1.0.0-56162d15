# Neura API

Version 1.1.0

This repository contains the Neura API implementation with:
- Cursor-based pagination
- Webhook subscription & status endpoints
- HMAC payload signing with replay prevention
- Error handling and catalog
- Rate limiting middleware
- OAuth2 scopes & RBAC
- SDK clients (Python & TypeScript)
- Integration tests and CI workflow
