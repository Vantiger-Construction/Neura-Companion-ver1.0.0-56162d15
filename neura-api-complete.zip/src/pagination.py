"""Cursor-based pagination utilities"""

def paginate_list(items, cursor: str = None, limit: int = 50):
    start = int(cursor) if cursor else 0
    end = start + limit
    next_cursor = str(end) if end < len(items) else None
    return {
        "items": items[start:end],
        "pageInfo": {"nextCursor": next_cursor, "prevCursor": str(start - limit) if start - limit >= 0 else None}
    }
