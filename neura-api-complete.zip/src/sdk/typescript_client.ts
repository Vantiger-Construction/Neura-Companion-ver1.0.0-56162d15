// TypeScript SDK client for Neura API
import axios, { AxiosInstance } from 'axios';

export class NeuraClient {
  private client: AxiosInstance;

  constructor(baseUrl: string, token: string) {
    this.client = axios.create({ baseURL: baseUrl, headers: { Authorization: `Bearer ${token}` } });
  }

  async listResources(cursor?: string, limit: number = 50) {
    const resp = await this.client.get('/resources', { params: { cursor, limit } });
    return resp.data;
  }
}
