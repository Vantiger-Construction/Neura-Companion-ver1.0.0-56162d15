"""Python SDK client for Neura API"""

import requests

class NeuraClient:
    def __init__(self, base_url: str, token: str):
        self.base_url = base_url
        self.token = token

    def get_resource(self, resource_id: str, cursor=None, limit=50):
        params = {"cursor": cursor, "limit": limit}
        headers = {"Authorization": f"Bearer {self.token}"}
        resp = requests.get(f"{self.base_url}/resources", params=params, headers=headers)
        return resp.json()
