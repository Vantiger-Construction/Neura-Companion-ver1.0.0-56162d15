"""Error handling and HTTP error definitions"""

from fastapi import HTTPException

class APIError(HTTPException):
    def __init__(self, code: str, status_code: int, detail: str):
        super().__init__(status_code=status_code, detail={"code": code, "message": detail})

error_catalog = {
    "AUTH_FAILURE": {"status": 401, "message": "Authentication Failed"},
    "INVALID_INPUT": {"status": 400, "message": "Invalid Request Data"},
    "RATE_LIMIT": {"status": 429, "message": "Too Many Requests"},
}
