"""OAuth2 scopes and RBAC mapping"""

from fastapi import APIRouter, Security, HTTPException
from fastapi.security import OAuth2PasswordBearer, SecurityScopes
from pydantic import BaseModel

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

router = APIRouter()

class Token(BaseModel):
    access_token: str
    token_type: str

@router.post("/token", response_model=Token)
async def login(form_data: OAuth2PasswordBearer = Security(oauth2_scheme)):
    # TODO: validate user and issue JWT with scopes
    return {"access_token": "fakejwt", "token_type": "bearer"}

@router.get("/me")
async def read_current_user(security_scopes: SecurityScopes, token: str = Security(oauth2_scheme)):
    # TODO: extract scopes from token and enforce
    return {"username": "alice", "scopes": security_scopes.scopes}
