"""HMAC payload signing utilities with replay prevention"""

import hmac
import hashlib
import time
from typing import Tuple

def sign_payload(secret: str, payload: bytes, algorithm: str = 'sha256') -> str:
    hash_func = getattr(hashlib, algorithm)
    return hmac.new(secret.encode(), payload, hash_func).hexdigest()

def verify_replay(timestamp: str, window: int = 300) -> bool:
    """Prevent replay by checking timestamp within a window (seconds)"""
    try:
        ts = int(timestamp)
    except ValueError:
        return False
    return abs(time.time() - ts) <= window
