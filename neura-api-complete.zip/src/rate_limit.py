"""Rate limiting middleware"""

from slowapi import Limiter, _rate_limit_exceeded_handler
from fastapi import FastAPI
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)

def init_rate_limiter(app: FastAPI):
    app.state.limiter = limiter
    app.add_exception_handler(429, _rate_limit_exceeded_handler)
    # Example usage: app.middleware("http")(limiter.limit("100/minute"))
