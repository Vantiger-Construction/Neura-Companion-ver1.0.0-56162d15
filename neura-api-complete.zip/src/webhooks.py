"""Webhook handlers and event handoff logic"""

from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from typing import Dict

router = APIRouter()

subscriptions: Dict[str, BaseModel] = {}

class WebhookSubscription(BaseModel):
    id: str = None
    url: str
    eventType: str

class WebhookStatus(BaseModel):
    id: str
    status: str
    lastAttempt: str

@router.post("/subscribe", status_code=201)
async def subscribe(sub: WebhookSubscription):
    sub.id = "sub" + sub.url[-4:]
    subscriptions[sub.id] = sub
    return sub

@router.get("/subscriptions/{id}/status")
async def get_status(id: str):
    if id not in subscriptions:
        raise HTTPException(status_code=404, detail="Subscription not found")
    # Stub status
    return WebhookStatus(id=id, status="pending", lastAttempt="2025-07-19T00:00:00Z")
