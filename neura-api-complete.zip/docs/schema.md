# Schema Documentation

## Resource
- **id**: string — Unique resource identifier.
- **name**: string — Human-readable name.
```json
{
  "id": "abc123",
  "name": "Test Resource"
}
```

## PaginatedResources
- **items**: Resource[] — List of resources.
- **pageInfo**: PageInfo — Cursors for pagination.
```json
{
  "items": [{ "id": "abc123", "name": "Test Resource" }],
  "pageInfo": { "nextCursor": "50", "prevCursor": null }
}
```

## WebhookSubscription & Status
- Subscribe:
```json
POST /webhooks/subscribe
{
  "url": "https://example.com/hook",
  "eventType": "user.created"
}
```
- Status:
```json
GET /webhooks/subscriptions/sub789/status
{
  "id": "sub789",
  "status": "pending",
  "lastAttempt": "2025-07-19T00:00:00Z"
}
```
