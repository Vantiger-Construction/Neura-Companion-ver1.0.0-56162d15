"""Tests for pagination utility"""

from src.pagination import paginate_list

def test_paginate():
    items = list(range(100))
    page = paginate_list(items, cursor="10", limit=20)
    assert page["items"] == list(range(10, 30))
    assert page["pageInfo"]["nextCursor"] == "30"
