"""Tests for HMAC signing and replay prevention"""

import pytest
from src.security import sign_payload, verify_replay
import time

def test_sign_payload():
    secret = "test"
    payload = b"data"
    sig = sign_payload(secret, payload)
    assert isinstance(sig, str) and len(sig) > 0

def test_replay():
    now = str(int(time.time()))
    assert verify_replay(now)
    assert not verify_replay("0")
