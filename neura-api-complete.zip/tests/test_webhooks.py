"""Tests for webhook subscription and status"""

from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_subscribe_and_status():
    resp = client.post("/webhooks/subscribe", json={"url": "https://x.com", "eventType": "test"})
    assert resp.status_code == 201
    data = resp.json()
    sub_id = data["id"]
    status_resp = client.get(f"/webhooks/subscriptions/{sub_id}/status")
    assert status_resp.status_code == 200
    assert status_resp.json()["id"] == sub_id
