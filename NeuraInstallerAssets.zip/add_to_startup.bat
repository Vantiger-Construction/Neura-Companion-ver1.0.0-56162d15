@echo off
REG ADD "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /V "NeuraCompanion" /t REG_SZ /F /D "%~dp0NeuraCompanion.exe"