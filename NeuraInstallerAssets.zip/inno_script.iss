[Setup]
AppName=Neura Companion
AppVersion=1.0
DefaultDirName={pf}\Neura Companion
DefaultGroupName=Neura Companion
OutputDir=.
OutputBaseFilename=NeuraCompanionInstaller

[Files]
Source: "build\windows\runner\Release\*"; DestDir: "{app}"; Flags: recursesubdirs

[Icons]
Name: "{userdesktop}\Neura Companion"; Filename: "{app}\NeuraCompanion.exe"

[Run]
Filename: "reg.exe"; Parameters: "ADD HKCU\Software\Microsoft\Windows\CurrentVersion\Run /V NeuraCompanion /t REG_SZ /F /D "{app}\NeuraCompanion.exe""; Flags: runhidden