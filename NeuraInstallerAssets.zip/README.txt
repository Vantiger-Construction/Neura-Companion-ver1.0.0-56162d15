# Neura Companion Installer Assets

This bundle includes everything you need to create a custom Windows installer for Neura Companion.

## Contents
- `add_to_startup.bat` – Adds Neura to Windows startup using registry.
- `nsis_script.nsi` – Use this with NSIS (Nullsoft Scriptable Install System) to create an installer.
- `inno_script.iss` – Use this with Inno Setup to create an alternate installer.

## Usage

### For NSIS:
1. Download [NSIS](https://nsis.sourceforge.io/Download).
2. Place all files from `build/windows/runner/Release/` into the working directory.
3. Compile `nsis_script.nsi` in NSIS.

### For Inno Setup:
1. Download [Inno Setup](https://jrsoftware.org/isinfo.php).
2. Place your app files in `build/windows/runner/Release/`.
3. Compile `inno_script.iss` in Inno Setup Compiler.