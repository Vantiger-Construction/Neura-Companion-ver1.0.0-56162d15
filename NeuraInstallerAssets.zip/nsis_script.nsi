!define APPNAME "Neura Companion"
!define DESCRIPTION "Your intelligent emotional assistant"

Outfile "NeuraCompanionInstaller.exe"
InstallDir "$PROGRAMFILES\NeuraCompanion"
RequestExecutionLevel user

Page directory
Page instfiles

Section "Install Neura Companion"
  SetOutPath $INSTDIR
  File /r "build\windows\runner\Release\*.*"

  ; Add shortcut
  CreateShortcut "$DESKTOP\${APPNAME}.lnk" "$INSTDIR\NeuraCompanion.exe"

  ; Auto-start on boot
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "NeuraCompanion" "$INSTDIR\NeuraCompanion.exe"
SectionEnd