from fastapi import FastAPI, Body
from pydantic import BaseModel
import uvicorn

app = FastAPI()

user_state = {"mood": "neutral", "ritual": None}

class ActionRequest(BaseModel):
    action: str

class MoodRequest(BaseModel):
    mood: str

@app.post("/act")
def perform_action(req: ActionRequest):
    print(f"Action requested: {req.action}")
    # TODO: Integrate with Unity API/command channel here
    return {"status": "success", "action": req.action}

@app.post("/mood")
def set_mood(req: MoodRequest):
    user_state["mood"] = req.mood
    print(f"Mood set to: {req.mood}")
    # TODO: Trigger avatar expression change
    return {"status": "success", "mood": req.mood}

@app.get("/state")
def get_state():
    return user_state

@app.post("/personalize")
def personalize(user: dict = Body(...)):
    print(f"Personalizing with data: {user}")
    return {"status": "success", "profile": user}

@app.post("/upgrade")
def upgrade_action(asset: dict = Body(...)):
    asset_name = asset.get("name")
    print(f"Upgrading with asset: {asset_name}")
    # TODO: Download/install animation/asset and trigger Unity reload
    return {"status": "success", "asset": asset_name}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
