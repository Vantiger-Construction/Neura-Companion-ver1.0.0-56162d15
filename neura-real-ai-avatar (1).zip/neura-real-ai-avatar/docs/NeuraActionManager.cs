
using UnityEngine;

public class NeuraActionManager : MonoBehaviour
{
    public Animator neuraAnimator;

    // Call this method when receiving API input
    public void TriggerAction(string action)
    {
        neuraAnimator.SetTrigger(action); // E.g. "Wave", "Smile", "Sit"
    }
}
