class NeuraFeedbackEngine {
  static String getFeedback(String mood, int streak) {
    if (mood == "sad") {
      return "You’ve had a tough day. Want to write it out in the journal?";
    } else if (mood == "happy" && streak >= 3) {
      return "You've been shining for days! Keep it up!";
    } else if (mood == "neutral") {
      return "Feeling flat today? Maybe a ritual will boost your mood.";
    }
    return "I'm here if you want to reflect or chat.";
  }
}