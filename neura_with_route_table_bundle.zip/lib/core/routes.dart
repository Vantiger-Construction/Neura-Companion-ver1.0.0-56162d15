
import 'package:flutter/material.dart';
import 'screens/global_mood_map.dart';
import 'screens/public_ritual_feed.dart';
import 'screens/clinical.dart';
import 'screens/ritual_curator.dart';
import 'screens/ritual_portal.dart';
import 'screens/companion_cast.dart';
import 'screens/synaptic_growth.dart';
import 'screens/reflective_mirror.dart';

final Map<String, WidgetBuilder> appRoutes = {
  "/globalMoodMap": (context) => const GlobalMoodMapPage(),
  "/publicRitualFeed": (context) => const PublicRitualFeedPage(),
  "/clinical": (context) => const ClinicalModulePage(),
  "/ritualCurator": (context) => const RitualCuratorPage(),
  "/ritualPortal": (context) => const RitualPortalPage(),
  "/companionCast": (context) => const CompanionCastPage(),
  "/synapticGrowth": (context) => const SynapticGrowthPage(),
  "/reflectiveMirror": (context) => const ReflectiveMirrorPage(),
};
