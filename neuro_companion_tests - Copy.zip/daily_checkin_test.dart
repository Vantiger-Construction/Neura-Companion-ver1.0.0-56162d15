import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:neuro_companion/screens/daily_checkin.dart';

void main() {
  testWidgets('Daily Check-In launches and logs emotion', (WidgetTester tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: DailyCheckInScreen(),
    ));

    expect(find.byType(DailyCheckInScreen), findsOneWidget);

    await tester.tap(find.text('Happy'));
    await tester.pump();

    expect(find.text('Happy'), findsOneWidget); // Replace with confirmation widget or mood label if needed
  });
}
