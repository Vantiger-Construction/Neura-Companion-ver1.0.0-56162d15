import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:neuro_companion/widgets/neura_joke_panel_animated.dart';

void main() {
  testWidgets('Neura Joke Panel displays and animates', (WidgetTester tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(
        body: NeuraJokePanelAnimated(),
      ),
    ));

    expect(find.byType(NeuraJokePanelAnimated), findsOneWidget);
    expect(find.textContaining('Neura'), findsNothing); // Adjust this based on your default text

    await tester.pump(const Duration(seconds: 1)); // Allow animations to trigger
  });
}
