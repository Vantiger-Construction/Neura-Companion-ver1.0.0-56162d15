import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:neuro_companion/screens/dream_journal_entry.dart';

void main() {
  testWidgets('Dream Journal Entry opens and accepts input', (WidgetTester tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: DreamJournalEntry(),
    ));

    expect(find.byType(DreamJournalEntry), findsOneWidget);

    await tester.enterText(find.byType(TextField).first, 'Flying through a rainbow factory');
    await tester.pump();

    expect(find.text('Flying through a rainbow factory'), findsOneWidget);
  });
}
