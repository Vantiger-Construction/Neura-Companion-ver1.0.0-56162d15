import 'package:flutter/material.dart';
import '../../widgets/neuro_appbar.dart';

class RitualScreen extends StatelessWidget {
  const RitualScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: NeuroAppBar(title: 'Daily Ritual'),
      body: const Center(child: Text('Ritual Screen Placeholder')),
    );
  }
}
