import 'package:flutter/material.dart';
import '../../widgets/neuro_appbar.dart';

class GoalsScreen extends StatelessWidget {
  const GoalsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: NeuroAppBar(title: 'Goal Tracker'),
      body: const Center(child: Text('Goals Screen Placeholder')),
    );
  }
}
