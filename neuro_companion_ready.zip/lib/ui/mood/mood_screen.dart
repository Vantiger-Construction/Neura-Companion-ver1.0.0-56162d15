import 'package:flutter/material.dart';
import '../../widgets/neuro_appbar.dart';

class MoodScreen extends StatelessWidget {
  const MoodScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: NeuroAppBar(title: 'Mood Analytics'),
      body: const Center(child: Text('Mood Screen Placeholder')),
    );
  }
}
