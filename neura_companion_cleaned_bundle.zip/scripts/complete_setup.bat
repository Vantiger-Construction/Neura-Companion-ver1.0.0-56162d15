@echo off
echo [Neura Companion] Windows Full Setup
setlocal
set "JAVA_HOME=C:\Path\To\JDK"
set "PATH=%JAVA_HOME%\bin;%PATH%"
where flutter >nul 2>&1 || (echo Flutter CLI not found & exit /b 1)
flutter clean
flutter pub get
flutter format --set-exit-if-changed .
flutter analyze
flutter test --coverage || exit /b 1
flutter drive --driver=test_driver/integration_test.dart --target=integration_test/app_test.dart --no-build || exit /b 1
flutter build apk --debug --release
flutter build web --release
pause
