#!/usr/bin/env bash
set -euo pipefail
echo "[Neura Companion] UNIX Full Setup"
export JAVA_HOME="/path/to/jdk"
export PATH="$JAVA_HOME/bin:$PATH"
command -v flutter || { echo "Flutter CLI not found"; exit 1; }
flutter clean
flutter pub get
flutter format --set-exit-if-changed .
flutter analyze
flutter test --coverage
flutter drive --driver=test_driver/integration_test.dart --target=integration_test/app_test.dart --no-build
flutter build apk --debug --release
flutter build web --release
