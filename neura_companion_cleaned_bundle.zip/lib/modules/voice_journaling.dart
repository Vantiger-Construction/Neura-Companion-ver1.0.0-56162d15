class VoiceJournaling {
  Future<void> record() async {}
}
