class QuestSystem {
  void startQuest(String id) {}
}
