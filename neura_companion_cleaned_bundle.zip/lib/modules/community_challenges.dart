class CommunityChallenges {
  List<String> getActive() => [];
}
