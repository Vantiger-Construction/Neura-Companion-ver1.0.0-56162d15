class HomeAutomation {
  void trigger(String device, String action) {}
}
