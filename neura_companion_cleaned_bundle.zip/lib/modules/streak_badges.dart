class StreakBadges {
  void award(int days) {}
}
