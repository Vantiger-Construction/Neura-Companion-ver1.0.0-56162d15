class OfflineMode {
  void enable() {}
}
