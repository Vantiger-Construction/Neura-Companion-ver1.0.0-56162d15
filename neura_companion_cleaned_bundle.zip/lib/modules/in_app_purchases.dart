class InAppPurchases {
  Future<bool> purchase(String id) async => false;
}
