class MoodForecasting {
  String forecast(DateTime date) {
    return 'Neutral';
  }
}
