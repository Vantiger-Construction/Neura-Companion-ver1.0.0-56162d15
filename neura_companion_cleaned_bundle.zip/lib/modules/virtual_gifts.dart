class VirtualGifts {
  void send(String userId, String giftId) {}
}
