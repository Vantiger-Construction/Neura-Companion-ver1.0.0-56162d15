# Neura Companion Cleaned Package

## Overview
Consolidated modules and streamlined scripts.

## Usage
- UNIX: `bash scripts/setup.sh`
- Windows: `scripts\complete_setup.bat`

Adjust JAVA_HOME and paths as needed.
