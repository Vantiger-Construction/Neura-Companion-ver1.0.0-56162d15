
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'neura_emotion_state.dart';
import 'neura_emotion_mapper.dart';
import 'neura_animation_engine.dart';
import 'neura_mood_memory.dart';

class NeuraVoiceSyncWidget extends StatefulWidget {
  const NeuraVoiceSyncWidget({Key? key}) : super(key: key);

  @override
  State<NeuraVoiceSyncWidget> createState() => _NeuraVoiceSyncWidgetState();
}

class _NeuraVoiceSyncWidgetState extends State<NeuraVoiceSyncWidget> {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();
  String _emotion = 'neutral';
  List<String> _history = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final moods = await MoodMemory.getMoodHistory();
    setState(() => _history = moods);
  }

  Future<void> _speakAndReact(String text) async {
    final detectedEmotion = mapTextToEmotion(text);
    await MoodMemory.logMood(detectedEmotion);
    setState(() => _emotion = detectedEmotion);
    await _tts.speak(text);
    await _loadHistory();
  }

  Future<void> _listen() async {
    bool available = await _speech.initialize();
    if (available) {
      _speech.listen(
        onResult: (result) {
          final spoken = result.recognizedWords;
          if (spoken.isNotEmpty) {
            _speakAndReact(spoken);
          }
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(child: NeuraAnimationEngine(emotion: _emotion)),
        ElevatedButton.icon(
          onPressed: _listen,
          icon: const Icon(Icons.mic),
          label: const Text("Speak to Neura"),
        ),
        const SizedBox(height: 10),
        Text("Mood History", style: const TextStyle(color: Colors.white)),
        for (var mood in _history)
          Text("• $mood", style: const TextStyle(color: Colors.grey)),
      ],
    );
  }
}
