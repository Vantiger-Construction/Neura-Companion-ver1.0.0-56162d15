
class ReflectiveMirrorController {
  Map<String, String> getReflection() {
    return {
      "mood": "Reflective & Calm",
      "insight": "You've balanced productivity and rest today.",
      "narration": "Today, you paused long enough to hear your own thoughts. You handled your responsibilities with grace and allowed yourself space to breathe. Well done."
    };
  }
}
