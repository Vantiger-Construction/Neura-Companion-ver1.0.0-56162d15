
import 'package:flutter/material.dart';
import 'reflective_mirror_controller.dart';

class ReflectiveMirrorScreen extends StatelessWidget {
  const ReflectiveMirrorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final reflection = ReflectiveMirrorController().getReflection();

    return Scaffold(
      appBar: AppBar(title: const Text("🪞 Reflective Mirror Mode")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Today's Emotional Summary:",
                style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 16),
            Text("🧠 Mood: ${reflection["mood"]}"),
            Text("💭 Insight: ${reflection["insight"]}"),
            const SizedBox(height: 24),
            Text("📣 Narration:", style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.blueGrey.shade50,
              ),
              child: Text(
                reflection["narration"],
                style: const TextStyle(fontStyle: FontStyle.italic),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
