package com.truetrace.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*

class BillingClientManager(
    private val context: Context,
    private val listener: PurchasesUpdatedListener
) {
    private var billingClient: BillingClient

    init {
        billingClient = BillingClient.newBuilder(context)
            .setListener(listener)
            .enablePendingPurchases()
            .build()
    }

    fun startConnection(onReady: () -> Unit) {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    onReady()
                }
            }

            override fun onBillingServiceDisconnected() {}
        })
    }

    fun launchPurchaseFlow(activity: Activity, productId: String) {
        val productList = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId)
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        )

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productList)
            .build()

        billingClient.queryProductDetailsAsync(params) { billingResult, products ->
            if (products.isNotEmpty()) {
                val productDetails = products[0]
                val offerToken = productDetails.subscriptionOfferDetails?.get(0)?.offerToken
                val billingParams = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(
                        listOf(
                            BillingFlowParams.ProductDetailsParams.newBuilder()
                                .setProductDetails(productDetails)
                                .setOfferToken(offerToken!!)
                                .build()
                        )
                    ).build()
                billingClient.launchBillingFlow(activity, billingParams)
            }
        }
    }

    fun isPremium(purchaseList: List<Purchase>?): Boolean {
        return purchaseList?.any { it.products.contains("truetrace_premium") } == true
    }
}