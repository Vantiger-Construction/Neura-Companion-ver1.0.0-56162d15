Drop Unity WebGL files into webvr/Build/.
This loader will render them fullscreen.