#!/bin/bash
set -e

# Clone or init repo folder
rm -rf neura-companion-microsite
git clone https://github.com/Vantiger1/neura-companion-microsite.git || (mkdir neura-companion-microsite && cd neura-companion-microsite && git init && git remote add origin https://github.com/Vantiger1/neura-companion-microsite.git && cd ..)

# Switch to gh-pages branch
cd neura-companion-microsite
git checkout gh-pages 2>/dev/null || git checkout -b gh-pages

# Clean old files and copy new ones
rm -rf *
cp ../neura_microsite_embed_final/* .

# Commit and push
git add .
git commit -m "🚀 Deployed updated Neura Companion microsite"
git push origin gh-pages
