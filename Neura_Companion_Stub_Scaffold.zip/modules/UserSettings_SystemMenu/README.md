# User Settings/System Menu
All toggles, device management, and permissions.