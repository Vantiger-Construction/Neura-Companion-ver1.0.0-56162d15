# Lifelog Module
Build export/import, timeline, advanced search, note tagging.