# Installer/Onboarding
Animated Neura, audio cues, step-by-step logic.