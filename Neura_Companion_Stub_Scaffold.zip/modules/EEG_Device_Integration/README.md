# EEG Device Integration
Implement device scan/connect, data stream, and error fallback.