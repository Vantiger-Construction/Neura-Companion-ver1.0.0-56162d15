# Localization/Internationalization
Provide i18n string files and translation logic.