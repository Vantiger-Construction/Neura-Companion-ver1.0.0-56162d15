# Child Mode
Games, learning quests, and parent controls go here.