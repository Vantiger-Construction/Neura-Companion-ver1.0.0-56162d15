# Predictive Analytics
Link analytics widgets to real models/data.