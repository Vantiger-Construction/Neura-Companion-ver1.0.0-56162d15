# Feedback & Rating Engine
Embed feedback in every module and wire to dashboard.