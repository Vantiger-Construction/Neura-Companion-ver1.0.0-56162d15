
import 'package:flutter/material.dart';
import 'offline_ritual_controller.dart';

class OfflineRitualScreen extends StatelessWidget {
  const OfflineRitualScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = OfflineRitualController();

    return Scaffold(
      appBar: AppBar(title: const Text("Offline Ritual Realm")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text("Offline Mode Active", style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 10),
            const Text("Fallback Rituals Available:"),
            Expanded(
              child: ListView.builder(
                itemCount: controller.offlineRituals.length,
                itemBuilder: (_, i) => ListTile(
                  title: Text(controller.offlineRituals[i]),
                  leading: const Icon(Icons.bolt_outlined),
                  onTap: () {
                    controller.logRitual(i);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Ritual Started: ${controller.offlineRituals[i]}")),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
