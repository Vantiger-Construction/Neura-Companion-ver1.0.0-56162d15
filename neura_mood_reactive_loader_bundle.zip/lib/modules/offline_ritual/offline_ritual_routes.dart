
import 'package:flutter/material.dart';
import 'offline_ritual_screen.dart';

Map<String, WidgetBuilder> offlineRitualRoutes = {
  '/offlineRitual': (context) => const OfflineRitualScreen(),
};
