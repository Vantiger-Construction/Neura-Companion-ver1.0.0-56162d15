
class OfflineRitualController {
  final List<String> offlineRituals = [
    "Deep Breath Session",
    "Gratitude Reflection",
    "3-Minute Calm Reset",
    "Mirror Motivation Boost",
  ];

  void logRitual(int index) {
    final ritual = offlineRituals[index];
    print("Ritual executed offline: \$ritual");
    // TODO: Save locally with timestamp
  }
}
