
import 'package:flutter/material.dart';
import 'synaptic_growth_screen.dart';

Map<String, WidgetBuilder> synapticGrowthRoutes = {
  '/synapticGrowth': (context) => const SynapticGrowthScreen(),
};
