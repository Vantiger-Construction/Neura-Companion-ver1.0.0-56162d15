
import 'package:flutter/material.dart';
import 'synaptic_growth_controller.dart';

class SynapticGrowthScreen extends StatelessWidget {
  const SynapticGrowthScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final data = SynapticGrowthController().getGrowthData();

    return Scaffold(
      appBar: AppBar(title: const Text("🌱 Synaptic Growth Mode")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Habits & Mood Correlation", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ...data.map((entry) => ListTile(
              leading: Icon(Icons.link, color: entry["color"]),
              title: Text(entry["habit"]),
              subtitle: Text("Mood impact: ${entry["mood"]}"),
              trailing: Text("Score: ${entry["score"]}"),
            ))
          ],
        ),
      ),
    );
  }
}
