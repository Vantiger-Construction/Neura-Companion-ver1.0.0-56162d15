
import 'package:flutter/material.dart';

class SynapticGrowthController {
  List<Map<String, dynamic>> getGrowthData() {
    return [
      {
        "habit": "Morning Walks",
        "mood": "Positive boost",
        "score": "+8",
        "color": Colors.green
      },
      {
        "habit": "Late-night Screen Time",
        "mood": "Sleep disruption",
        "score": "-5",
        "color": Colors.red
      },
      {
        "habit": "Gratitude Journal",
        "mood": "Reflective calm",
        "score": "+6",
        "color": Colors.blue
      },
    ];
  }
}
