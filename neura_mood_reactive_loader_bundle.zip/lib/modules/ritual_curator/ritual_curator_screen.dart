
import 'package:flutter/material.dart';
import 'ritual_curator_controller.dart';

class RitualCuratorScreen extends StatelessWidget {
  const RitualCuratorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final quests = RitualCuratorController().generateQuests();

    return Scaffold(
      appBar: AppBar(title: const Text("🎯 AI Ritual Curator")),
      body: ListView.separated(
        padding: const EdgeInsets.all(20),
        itemBuilder: (_, i) => ListTile(
          leading: const Icon(Icons.auto_awesome),
          title: Text(quests[i]["title"]),
          subtitle: Text(quests[i]["description"]),
          trailing: ElevatedButton(
            onPressed: () {},
            child: const Text("Begin"),
          ),
        ),
        separatorBuilder: (_, __) => const Divider(),
        itemCount: quests.length,
      ),
    );
  }
}
