
import 'package:flutter/material.dart';
import 'ritual_curator_screen.dart';

Map<String, WidgetBuilder> ritualCuratorRoutes = {
  '/ritualCurator': (context) => const RitualCuratorScreen(),
};
