
import 'package:flutter/material.dart';
import 'legacy_screen.dart';

Map<String, WidgetBuilder> legacyRoutes = {
  '/legacy': (context) => const LegacyScreen(),
};
