
import 'package:flutter/material.dart';

class LegacyMessage {
  final String text;
  final String timestamp;
  final bool encrypted;

  LegacyMessage(this.text, this.timestamp, this.encrypted);
}

class LegacyController {
  final TextEditingController messageController = TextEditingController();
  bool encrypt = false;
  final List<LegacyMessage> legacyMessages = [];

  void saveMessage() {
    final msg = messageController.text.trim();
    if (msg.isEmpty) return;

    final timestamp = DateTime.now().toIso8601String();
    legacyMessages.add(LegacyMessage(
      encrypt ? "[ENCRYPTED] $msg" : msg,
      timestamp,
      encrypt,
    ));
    messageController.clear();
  }
}
