
import 'package:flutter/material.dart';
import 'legacy_controller.dart';

class LegacyScreen extends StatefulWidget {
  const LegacyScreen({super.key});

  @override
  State<LegacyScreen> createState() => _LegacyScreenState();
}

class _LegacyScreenState extends State<LegacyScreen> {
  final controller = LegacyController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Legacy Mode Vault")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: controller.messageController,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: "Write your legacy message",
                border: OutlineInputBorder(),
              ),
            ),
            Row(
              children: [
                const Text("Encrypt?"),
                Switch(
                  value: controller.encrypt,
                  onChanged: (val) => setState(() => controller.encrypt = val),
                ),
                const Spacer(),
                ElevatedButton(
                  onPressed: () {
                    controller.saveMessage();
                    setState(() {});
                  },
                  child: const Text("Save"),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text("Saved Messages:", style: TextStyle(fontWeight: FontWeight.bold)),
            Expanded(
              child: ListView.builder(
                itemCount: controller.legacyMessages.length,
                itemBuilder: (_, i) {
                  final msg = controller.legacyMessages[i];
                  return ListTile(
                    title: Text(msg.text),
                    subtitle: Text("Saved: ${msg.timestamp}"),
                    trailing: msg.encrypted ? const Icon(Icons.lock) : null,
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
