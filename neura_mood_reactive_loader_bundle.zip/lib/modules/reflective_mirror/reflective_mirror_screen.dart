
import 'package:flutter/material.dart';
import 'reflective_mirror_controller.dart';

class ReflectiveMirrorScreen extends StatelessWidget {
  const ReflectiveMirrorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final mirrorInsights = ReflectiveMirrorController().generateSummary();

    return Scaffold(
      appBar: AppBar(title: const Text("🪞 Reflective Mirror Mode")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Text(
              "Narrated Emotional Summary",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Text(
              mirrorInsights,
              style: const TextStyle(fontSize: 16, height: 1.6),
            ),
          ],
        ),
      ),
    );
  }
}
