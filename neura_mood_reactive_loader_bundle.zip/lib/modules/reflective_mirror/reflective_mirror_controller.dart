
class ReflectiveMirrorController {
  String generateSummary() {
    final recentMoods = ["Focused", "Tired", "Motivated", "Calm"];
    final highlights = {
      "Focused": "you were productive and task-oriented",
      "Tired": "you may have needed more rest",
      "Motivated": "you took initiative on key goals",
      "Calm": "you maintained emotional balance"
    };

    String summary = "This week, your emotional patterns reflected a blend of focus and calm energy.\n\n";

    for (final mood in recentMoods) {
      summary += "• When you felt $mood, ${highlights[mood]}.\n";
    }

    summary += "\nContinue nurturing moments of balance while watching for signals of burnout. You're growing well.";

    return summary;
  }
}
