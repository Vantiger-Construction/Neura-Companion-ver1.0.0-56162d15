
import 'package:flutter/material.dart';
import 'reflective_mirror_screen.dart';

Map<String, WidgetBuilder> reflectiveMirrorRoutes = {
  '/reflectiveMirror': (context) => const ReflectiveMirrorScreen(),
};
