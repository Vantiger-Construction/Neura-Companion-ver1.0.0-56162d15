
class MoodForecastController {
  Map<String, dynamic> predictMood() {
    return {
      "mood": "Optimistic",
      "confidence": 88,
      "timeline": [
        {"time": "Morning", "mood": "Calm"},
        {"time": "Afternoon", "mood": "Motivated"},
        {"time": "Evening", "mood": "Relaxed"},
        {"time": "Night", "mood": "Sleepy"},
      ]
    };
  }
}
