
import 'package:flutter/material.dart';
import 'mood_forecast_screen.dart';

Map<String, WidgetBuilder> moodForecastRoutes = {
  '/moodForecast': (context) => const MoodForecastScreen(),
};
