
import 'package:flutter/material.dart';
import 'mood_forecast_controller.dart';

class MoodForecastScreen extends StatelessWidget {
  const MoodForecastScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = MoodForecastController();
    final moodData = controller.predictMood();

    return Scaffold(
      appBar: AppBar(title: const Text("Mood Forecast AI")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Upcoming Emotional Outlook", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text("🧠 Predicted Mood: ${moodData['mood']}"),
            Text("📈 Confidence: ${moodData['confidence']}%"),
            const SizedBox(height: 20),
            const Text("🌀 Mood Timeline:"),
            ...moodData['timeline'].map<Widget>((e) => ListTile(
              title: Text("→ ${e['time']}"),
              trailing: Text(e['mood']),
            )),
          ],
        ),
      ),
    );
  }
}
