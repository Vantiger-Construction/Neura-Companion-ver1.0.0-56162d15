
import 'package:flutter/material.dart';
import 'neura_timeline_controller.dart';

class NeuraTimelineScreen extends StatelessWidget {
  const NeuraTimelineScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final events = NeuraTimelineController().getTimeline();

    return Scaffold(
      appBar: AppBar(title: const Text("📅 Neura Timeline")),
      body: ListView.builder(
        itemCount: events.length,
        itemBuilder: (context, index) {
          final entry = events[index];
          return ListTile(
            leading: Icon(entry["icon"], color: entry["color"]),
            title: Text(entry["title"]),
            subtitle: Text(entry["detail"]),
            trailing: Text(entry["timestamp"]),
          );
        },
      ),
    );
  }
}
