
import 'package:flutter/material.dart';

class NeuraTimelineController {
  List<Map<String, dynamic>> getTimeline() {
    return [
      {
        "title": "Mood: Focused",
        "detail": "You had a productive check-in this morning.",
        "icon": Icons.bolt,
        "color": Colors.orange,
        "timestamp": "9:00 AM"
      },
      {
        "title": "Reflection Logged",
        "detail": "You wrote in your journal about feeling empowered.",
        "icon": Icons.menu_book,
        "color": Colors.purple,
        "timestamp": "12:15 PM"
      },
      {
        "title": "Gratitude Ritual",
        "detail": "3 things you're grateful for were recorded.",
        "icon": Icons.favorite,
        "color": Colors.red,
        "timestamp": "8:30 PM"
      }
    ];
  }
}
