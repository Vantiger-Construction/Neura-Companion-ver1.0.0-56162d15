
import 'package:flutter/material.dart';
import 'neura_timeline_screen.dart';

Map<String, WidgetBuilder> neuraTimelineRoutes = {
  '/neuraTimeline': (context) => const NeuraTimelineScreen(),
};
