


// 🔮 Future Enhancements for Global Mood Map:
// - Heatmap by country/region
// - Emoji check-in interface
// - Animated wave patterns to show mood shifts
final Map<String, double> regionMoodScores = {
  "US": 0.76,
  "EU": 0.64,
  "ASIA": 0.82,
};
