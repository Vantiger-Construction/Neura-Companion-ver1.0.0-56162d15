
class MoodArt {
  final String moodLabel;
  final String imagePath;

  MoodArt({required this.moodLabel, required this.imagePath});
}

class VisualMoodboardController {
  List<MoodArt> generateMoodboard() {
    return [
      MoodArt(moodLabel: "Serenity", imagePath: "assets/mood/serenity.png"),
      MoodArt(moodLabel: "Elation", imagePath: "assets/mood/elation.png"),
      MoodArt(moodLabel: "Melancholy", imagePath: "assets/mood/melancholy.png"),
      MoodArt(moodLabel: "Empowered", imagePath: "assets/mood/empowered.png"),
    ];
  }
}
