
import 'package:flutter/material.dart';
import 'visual_moodboard_screen.dart';

Map<String, WidgetBuilder> visualMoodboardRoutes = {
  '/visualMoodboard': (context) => const VisualMoodboardScreen(),
};
