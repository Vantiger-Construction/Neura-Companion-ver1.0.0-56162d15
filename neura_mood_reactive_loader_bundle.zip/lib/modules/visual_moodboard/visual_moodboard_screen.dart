
import 'package:flutter/material.dart';
import 'visual_moodboard_controller.dart';

class VisualMoodboardScreen extends StatelessWidget {
  const VisualMoodboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<MoodArt> moodArtList = VisualMoodboardController().generateMoodboard();

    return Scaffold(
      appBar: AppBar(title: const Text("🎨 Visual Moodboard")),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 16,
          crossAxisSpacing: 16,
        ),
        itemCount: moodArtList.length,
        itemBuilder: (context, index) {
          final moodArt = moodArtList[index];
          return Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(moodArt.imagePath),
                fit: BoxFit.cover,
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                color: Colors.black54,
                padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 10),
                child: Text(
                  moodArt.moodLabel,
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
