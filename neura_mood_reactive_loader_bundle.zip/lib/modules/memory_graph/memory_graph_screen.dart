
import 'package:flutter/material.dart';
import 'memory_graph_controller.dart';

class MemoryGraphScreen extends StatelessWidget {
  const MemoryGraphScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final graph = MemoryGraphController().getGraphNodes();

    return Scaffold(
      appBar: AppBar(title: const Text("🧠 Neural Memory Graph")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView.builder(
          itemCount: graph.length,
          itemBuilder: (context, index) {
            final node = graph[index];
            return Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: ListTile(
                leading: Icon(Icons.memory, color: node["color"]),
                title: Text(node["event"]),
                subtitle: Text("Mood: ${node["mood"]}"),
                trailing: Text(node["timestamp"]),
              ),
            );
          },
        ),
      ),
    );
  }
}
