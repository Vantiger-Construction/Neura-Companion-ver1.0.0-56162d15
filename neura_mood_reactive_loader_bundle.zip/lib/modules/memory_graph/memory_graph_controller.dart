
import 'package:flutter/material.dart';

class MemoryGraphController {
  List<Map<String, dynamic>> getGraphNodes() {
    return [
      {
        "event": "Ritual: Calm Morning",
        "mood": "Peaceful",
        "timestamp": "7:30 AM",
        "color": Colors.blue
      },
      {
        "event": "Therapist Check-in",
        "mood": "Emotional",
        "timestamp": "11:00 AM",
        "color": Colors.deepPurple
      },
      {
        "event": "Goal Completed",
        "mood": "Motivated",
        "timestamp": "5:45 PM",
        "color": Colors.green
      }
    ];
  }
}
