
import 'package:flutter/material.dart';
import 'memory_graph_screen.dart';

Map<String, WidgetBuilder> memoryGraphRoutes = {
  '/memoryGraph': (context) => const MemoryGraphScreen(),
};
