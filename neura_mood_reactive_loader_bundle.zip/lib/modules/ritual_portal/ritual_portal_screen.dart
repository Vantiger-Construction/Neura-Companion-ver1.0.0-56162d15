
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'ritual_portal_controller.dart';

class RitualPortalScreen extends StatefulWidget {
  const RitualPortalScreen({super.key});

  @override
  State<RitualPortalScreen> createState() => _RitualPortalScreenState();
}

class _RitualPortalScreenState extends State<RitualPortalScreen> {
  String currentScene = "focus";

  @override
  Widget build(BuildContext context) {
    final portalAssets = RitualPortalController().getPortalAssets(currentScene);

    return Scaffold(
      appBar: AppBar(title: const Text("🌀 Ritual Portal Mode")),
      body: Column(
        children: [
          Expanded(
            child: Lottie.asset(
              portalAssets["animation"]!,
              fit: BoxFit.cover,
            ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            color: Colors.black12,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                for (final scene in ["focus", "relax", "joy"])
                  ElevatedButton(
                    onPressed: () => setState(() => currentScene = scene),
                    child: Text(scene.toUpperCase()),
                  )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
