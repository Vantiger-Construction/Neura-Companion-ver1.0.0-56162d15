
import 'package:flutter/material.dart';
import 'ritual_portal_screen.dart';

Map<String, WidgetBuilder> ritualPortalRoutes = {
  '/ritualPortal': (context) => const RitualPortalScreen(),
};
