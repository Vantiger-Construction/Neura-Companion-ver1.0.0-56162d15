
class RitualPortalController {
  Map<String, String> getPortalAssets(String mood) {
    final assets = {
      "focus": "assets/lottie/portal_focus.json",
      "relax": "assets/lottie/portal_relax.json",
      "joy": "assets/lottie/portal_joy.json",
    };
    return {"animation": assets[mood] ?? assets["focus"]!};
  }
}



// 🔮 Future Enhancements for Ritual Portal:
// - Audio themes per scene
// - Dynamic weather/lighting effects
// - Voice-activated scene switch
final Map<String, String> audioThemes = {
  "focus": "assets/audio/focus_theme.mp3",
  "relax": "assets/audio/relax_theme.mp3",
  "joy": "assets/audio/joy_theme.mp3",
};
