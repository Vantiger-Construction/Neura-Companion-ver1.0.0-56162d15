
import 'package:flutter/material.dart';
import 'global_mood_map_controller.dart';

class GlobalMoodMapScreen extends StatelessWidget {
  const GlobalMoodMapScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = GlobalMoodMapController();
    final moodData = controller.fetchGlobalMoodData();

    return Scaffold(
      appBar: AppBar(title: const Text("🌍 Global Mood Map")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: moodData.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                itemCount: moodData.length,
                itemBuilder: (context, index) {
                  final entry = moodData[index];
                  return Card(
                    child: ListTile(
                      leading: Icon(entry["icon"], color: entry["color"]),
                      title: Text(entry["region"]),
                      subtitle: Text("Mood: ${entry["mood"]}"),
                      trailing: Text(entry["timestamp"]),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
