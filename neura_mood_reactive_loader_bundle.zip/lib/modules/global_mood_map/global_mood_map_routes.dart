
import 'package:flutter/material.dart';
import 'global_mood_map_screen.dart';

Map<String, WidgetBuilder> globalMoodMapRoutes = {
  '/globalMoodMap': (context) => const GlobalMoodMapScreen(),
};
