
import 'package:flutter/material.dart';

class GlobalMoodMapController {
  List<Map<String, dynamic>> fetchGlobalMoodData() {
    return [
      {
        "region": "North America",
        "mood": "Focused",
        "icon": Icons.lightbulb,
        "color": Colors.green,
        "timestamp": "5 min ago"
      },
      {
        "region": "Europe",
        "mood": "Melancholic",
        "icon": Icons.cloud,
        "color": Colors.blueGrey,
        "timestamp": "7 min ago"
      },
      {
        "region": "Asia",
        "mood": "Excited",
        "icon": Icons.bolt,
        "color": Colors.orange,
        "timestamp": "2 min ago"
      }
    ];
  }
}
