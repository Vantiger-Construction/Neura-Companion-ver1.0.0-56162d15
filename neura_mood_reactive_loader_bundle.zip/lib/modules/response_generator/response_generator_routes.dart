
import 'package:flutter/material.dart';
import 'response_generator_screen.dart';

Map<String, WidgetBuilder> responseGeneratorRoutes = {
  '/responseGenerator': (context) => const NeuralResponseGeneratorScreen(),
};
