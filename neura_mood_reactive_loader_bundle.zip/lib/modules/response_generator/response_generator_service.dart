
class ResponseGeneratorService {
  static String generateReply(String prompt) {
    // Mock emotional AI response – plug in OpenAI or local model here
    final emotionalTone = prompt.contains("sad") ? "comforting" : "motivational";
    return emotionalTone == "comforting"
        ? "I'm here with you. It's okay to feel that way. How can we take a small step forward today?"
        : "That’s powerful! Let’s channel that energy into something meaningful. What’s your next move?";
  }
}
