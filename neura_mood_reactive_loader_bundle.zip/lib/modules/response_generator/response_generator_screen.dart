
import 'package:flutter/material.dart';
import 'response_generator_service.dart';

class NeuralResponseGeneratorScreen extends StatefulWidget {
  const NeuralResponseGeneratorScreen({super.key});

  @override
  State<NeuralResponseGeneratorScreen> createState() => _NeuralResponseGeneratorScreenState();
}

class _NeuralResponseGeneratorScreenState extends State<NeuralResponseGeneratorScreen> {
  final TextEditingController _inputController = TextEditingController();
  String _aiResponse = '';

  void _generateResponse() {
    final prompt = _inputController.text.trim();
    if (prompt.isNotEmpty) {
      setState(() {
        _aiResponse = ResponseGeneratorService.generateReply(prompt);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("🗣️ Neural Response Generator")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _inputController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: "What’s on your mind?",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _generateResponse,
              child: const Text("Generate Insight"),
            ),
            const SizedBox(height: 16),
            if (_aiResponse.isNotEmpty)
              Card(
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(_aiResponse),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
