
import 'package:flutter/material.dart';
import 'clinical_controller.dart';

class ClinicalScreen extends StatelessWidget {
  const ClinicalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = ClinicalController();

    return Scaffold(
      appBar: AppBar(title: const Text("Vitals & Health Sync")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Enter Vitals", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            TextField(
              controller: controller.heartRateController,
              decoration: const InputDecoration(labelText: "Heart Rate (bpm)"),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: controller.temperatureController,
              decoration: const InputDecoration(labelText: "Body Temp (°F)"),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.upload),
              label: const Text("Upload to Doctor"),
              onPressed: () {
                controller.uploadVitals(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}
