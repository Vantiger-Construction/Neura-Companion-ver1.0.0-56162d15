
import 'package:flutter/material.dart';

class ClinicalMedicationReminders extends StatefulWidget {
  const ClinicalMedicationReminders({super.key});

  @override
  State<ClinicalMedicationReminders> createState() => _ClinicalMedicationRemindersState();
}

class _ClinicalMedicationRemindersState extends State<ClinicalMedicationReminders> {
  final List<Map<String, String>> reminders = [
    {"pill": "Vitamin D", "time": "8:00 AM"},
    {"pill": "Sertraline", "time": "9:00 AM"},
    {"pill": "Melatonin", "time": "10:00 PM"}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("💊 Pill Reminders")),
      body: ListView.builder(
        itemCount: reminders.length,
        itemBuilder: (context, index) {
          final item = reminders[index];
          return Card(
            child: ListTile(
              leading: const Icon(Icons.alarm),
              title: Text(item["pill"]!),
              trailing: Text(item["time"]!),
            ),
          );
        },
      ),
    );
  }
}
