
import 'package:flutter/material.dart';
import 'clinical_medication_reminders.dart';

Map<String, WidgetBuilder> clinicalRoutes = {
  '/clinicalReminders': (context) => const ClinicalMedicationReminders(),
};
