
class CompanionCastController {
  List<Map<String, String>> getCast() {
    return [
      {
        "name": "Neura",
        "emoji": "🤖",
        "personality": "Warm, nurturing, intuitive AI companion."
      },
      {
        "name": "Neuro",
        "emoji": "🧠",
        "personality": "Logical, focused, goal-driven motivator."
      },
      {
        "name": "Luma",
        "emoji": "🌟",
        "personality": "Dreamy, creative, supports vision-building."
      }
    ];
  }
}



// 🔮 Expansion Ideas:
// 1. voicePack (path to TTS or audio files per character)
// 2. dailyGreetings (morning/night personalized phrases)
// 3. moodAnimations (Lottie files or animation states per emotion)

final Map<String, dynamic> voicePack = {
  "Neura": "assets/voices/neura_voice.mp3",
  "Neuro": "assets/voices/neuro_voice.mp3",
  "Luma": "assets/voices/luma_voice.mp3",
};

final Map<String, String> dailyGreetings = {
  "Neura": "Good morning, sunshine 🌞 Let's grow today.",
  "Neuro": "Let's execute. Your focus is your power.",
  "Luma": "Wander and wonder, beautiful dreamer ✨",
};

final Map<String, String> moodAnimations = {
  "Neura": "assets/lottie/neura_idle.json",
  "Neuro": "assets/lottie/neuro_focus.json",
  "Luma": "assets/lottie/luma_glow.json",
};
