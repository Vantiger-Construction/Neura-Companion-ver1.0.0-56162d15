
import 'package:flutter/material.dart';
import 'companion_cast_screen.dart';

Map<String, WidgetBuilder> companionCastRoutes = {
  '/companionCast': (context) => const CompanionCastScreen(),
};
