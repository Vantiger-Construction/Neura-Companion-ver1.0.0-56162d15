
import 'package:flutter/material.dart';
import 'companion_cast_controller.dart';

class CompanionCastScreen extends StatefulWidget {
  const CompanionCastScreen({super.key});

  @override
  State<CompanionCastScreen> createState() => _CompanionCastScreenState();
}

class _CompanionCastScreenState extends State<CompanionCastScreen> {
  String selectedCompanion = "Neura";

  @override
  Widget build(BuildContext context) {
    final cast = CompanionCastController().getCast();

    return Scaffold(
      appBar: AppBar(title: const Text("💬 Companion Cast Dialogues")),
      body: ListView.builder(
        itemCount: cast.length,
        itemBuilder: (_, i) {
          final character = cast[i];
          final isSelected = character["name"] == selectedCompanion;
          return ListTile(
            leading: CircleAvatar(child: Text(character["emoji"]!)),
            title: Text(character["name"]!),
            subtitle: Text(character["personality"]!),
            trailing: isSelected ? const Icon(Icons.check, color: Colors.green) : null,
            onTap: () => setState(() => selectedCompanion = character["name"]!),
          );
        },
      ),
    );
  }
}
