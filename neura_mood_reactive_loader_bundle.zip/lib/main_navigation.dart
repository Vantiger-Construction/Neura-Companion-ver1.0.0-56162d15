
import 'package:flutter/material.dart';
import 'screens/settings/expansion_settings_page.dart';

class MainNavigation extends StatelessWidget {
  const MainNavigation({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Neura Companion")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton.icon(
              icon: const Icon(Icons.psychology),
              label: const Text("Expansion Settings"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ExpansionSettingsPage()),
                );
              },
            ),
            const SizedBox(height: 16),
            
            ElevatedButton.icon(
              icon: const Icon(Icons.map),
              label: const Text("Global Mood Map"),
              onPressed: () {
                Navigator.pushNamed(context, "/globalMoodMap");
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.emoji_emotions),
              label: const Text("Public Ritual Feed"),
              onPressed: () {
                Navigator.pushNamed(context, "/publicRitualFeed");
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.local_hospital),
              label: const Text("Clinical Module"),
              onPressed: () {
                Navigator.pushNamed(context, "/clinical");
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.star),
              label: const Text("Ritual Curator"),
              onPressed: () {
                Navigator.pushNamed(context, "/ritualCurator");
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.auto_awesome_motion),
              label: const Text("Ritual Portal"),
              onPressed: () {
                Navigator.pushNamed(context, "/ritualPortal");
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.groups),
              label: const Text("Companion Cast"),
              onPressed: () {
                Navigator.pushNamed(context, "/companionCast");
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.insights),
              label: const Text("Synaptic Growth"),
              onPressed: () {
                Navigator.pushNamed(context, "/synapticGrowth");
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.mic_external_on),
              label: const Text("Reflective Mirror"),
              onPressed: () {
                Navigator.pushNamed(context, "/reflectiveMirror");
              },
            ),

          ],
        ),
      ),
    );
  }
}
