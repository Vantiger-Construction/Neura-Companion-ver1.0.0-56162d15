
import 'package:flutter/material.dart';
import '../../core/expansion_manager.dart';

class ExpansionSettingsPage extends StatefulWidget {
  const ExpansionSettingsPage({Key? key}) : super(key: key);

  @override
  State<ExpansionSettingsPage> createState() => _ExpansionSettingsPageState();
}

class _ExpansionSettingsPageState extends State<ExpansionSettingsPage> {
  final manager = ExpansionManager();

  Widget buildSwitch(String label, bool value, Function(bool) onChanged) {
    return SwitchListTile(
      title: Text(label),
      value: value,
      onChanged: (val) {
        setState(() {
          onChanged(val);
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Expansion Features")),
      body: ListView(
        children: [
          buildSwitch("Voice Packs", manager.enableVoicePacks, (val) => manager.enableVoicePacks = val),
          buildSwitch("Mood Animations", manager.enableMoodAnimations, (val) => manager.enableMoodAnimations = val),
          buildSwitch("Daily Greetings", manager.enableDailyGreetings, (val) => manager.enableDailyGreetings = val),
          buildSwitch("Audio Themes", manager.enableAudioThemes, (val) => manager.enableAudioThemes = val),
          buildSwitch("Pill Reminders", manager.enablePillReminders, (val) => manager.enablePillReminders = val),
          buildSwitch("AI Ritual Generator", manager.enableAIGeneratedRituals, (val) => manager.enableAIGeneratedRituals = val),
          buildSwitch("Global Mood Heatmap", manager.enableHeatmapRegionTracking, (val) => manager.enableHeatmapRegionTracking = val),
          buildSwitch("Emoji Reactions", manager.enableEmojiReactions, (val) => manager.enableEmojiReactions = val),
        ],
      ),
    );
  }
}
