
class ExpansionManager {
  static final ExpansionManager _singleton = ExpansionManager._internal();

  factory ExpansionManager() {
    return _singleton;
  }

  ExpansionManager._internal();

  // Toggleable feature flags
  bool enableVoicePacks = true;
  bool enableMoodAnimations = true;
  bool enableDailyGreetings = true;
  bool enableAudioThemes = true;
  bool enablePillReminders = true;
  bool enableAIGeneratedRituals = true;
  bool enableHeatmapRegionTracking = true;
  bool enableEmojiReactions = true;

  void resetToDefaults() {
    enableVoicePacks = true;
    enableMoodAnimations = true;
    enableDailyGreetings = true;
    enableAudioThemes = true;
    enablePillReminders = true;
    enableAIGeneratedRituals = true;
    enableHeatmapRegionTracking = true;
    enableEmojiReactions = true;
  }

  Map<String, bool> getActiveExpansions() => {
    "voicePacks": enableVoicePacks,
    "moodAnimations": enableMoodAnimations,
    "dailyGreetings": enableDailyGreetings,
    "audioThemes": enableAudioThemes,
    "pillReminders": enablePillReminders,
    "aiGeneratedRituals": enableAIGeneratedRituals,
    "heatmapRegionTracking": enableHeatmapRegionTracking,
    "emojiReactions": enableEmojiReactions,
  };
}
