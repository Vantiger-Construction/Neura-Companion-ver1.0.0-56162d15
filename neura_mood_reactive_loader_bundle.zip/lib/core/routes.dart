
import 'package:flutter/material.dart';
import '../screens/global_mood_map.dart';
import '../screens/public_ritual_feed.dart';
import '../screens/clinical.dart';
import '../screens/ritual_curator.dart';
import '../screens/ritual_portal.dart';
import '../screens/companion_cast.dart';
import '../screens/synaptic_growth.dart';
import '../screens/reflective_mirror.dart';
import '../widgets/route_loader_wrapper.dart';

final Map<String, WidgetBuilder> appRoutes = {
  "/globalMoodMap": (context) => const RouteLoaderWrapper(page: GlobalMoodMapPage(), voiceMessage: "Let’s check the world’s emotions together."),
  "/publicRitualFeed": (context) => const RouteLoaderWrapper(page: PublicRitualFeedPage(), voiceMessage: "See what others are doing to feel alive."),
  "/clinical": (context) => const RouteLoaderWrapper(page: ClinicalModulePage(), voiceMessage: "Here’s where I help you feel better."),
  "/ritualCurator": (context) => const RouteLoaderWrapper(page: RitualCuratorPage(), voiceMessage: "Let’s design a path just for you."),
  "/ritualPortal": (context) => const RouteLoaderWrapper(page: RitualPortalPage(), voiceMessage: "I’ve prepared an immersive ritual for you."),
  "/companionCast": (context) => const RouteLoaderWrapper(page: CompanionCastPage(), voiceMessage: "Meet my crew. They’re excited to connect."),
  "/synapticGrowth": (context) => const RouteLoaderWrapper(page: SynapticGrowthPage(), voiceMessage: "Exploring how your moods and habits connect."),
  "/reflectiveMirror": (context) => const RouteLoaderWrapper(page: ReflectiveMirrorPage(), voiceMessage: "Let’s reflect together on how you’ve felt."),
};
