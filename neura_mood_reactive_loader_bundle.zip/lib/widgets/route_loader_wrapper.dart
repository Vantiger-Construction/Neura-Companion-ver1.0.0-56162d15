
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:lottie/lottie.dart';

class RouteLoaderWrapper extends StatefulWidget {
  final Widget page;
  final String routeName;
  final String voiceMessage;

  const RouteLoaderWrapper({
    super.key,
    required this.page,
    required this.routeName,
    required this.voiceMessage,
  });

  @override
  State<RouteLoaderWrapper> createState() => _RouteLoaderWrapperState();
}

class _RouteLoaderWrapperState extends State<RouteLoaderWrapper> {
  bool _loading = true;
  final FlutterTts tts = FlutterTts();

  @override
  void initState() {
    super.initState();
    _speakIntro();
    Future.delayed(const Duration(seconds: 2), () {
      setState(() => _loading = false);
    });
  }

  Future<void> _speakIntro() async {
    await tts.setLanguage("en-US");
    await tts.setPitch(1.0);
    await tts.speak(widget.voiceMessage);
  }

  String getLottiePath() {
    switch (widget.routeName) {
      case "/globalMoodMap":
        return 'assets/lottie/neura_moodmap.json';
      case "/publicRitualFeed":
        return 'assets/lottie/neura_social.json';
      case "/clinical":
        return 'assets/lottie/neura_healthcare.json';
      case "/ritualCurator":
        return 'assets/lottie/neura_magic_glow.json';
      case "/ritualPortal":
        return 'assets/lottie/neura_portal_spin.json';
      case "/companionCast":
        return 'assets/lottie/neura_friends_wave.json';
      case "/synapticGrowth":
        return 'assets/lottie/neura_thinking.json';
      case "/reflectiveMirror":
        return 'assets/lottie/neura_reflection.json';
      default:
        return 'assets/lottie/neura_react_idle.json';
    }
  }

  @override
  Widget build(BuildContext context) {
    return _loading
        ? Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Lottie.asset(getLottiePath(), width: 180),
                  const SizedBox(height: 20),
                  Text("Neura is loading ${widget.routeName.replaceAll("/", "")}..."),
                ],
              ),
            ),
          )
        : widget.page;
  }
}
