
import 'package:flutter/material.dart';
import 'main_navigation.dart';
import 'core/routes.dart';

void main() {
  runApp(const NeuraApp());
}

class NeuraApp extends StatelessWidget {
  const NeuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      theme: ThemeData.dark(),
      home: const MainNavigation(),
      routes: appRoutes,
    );
  }
}
