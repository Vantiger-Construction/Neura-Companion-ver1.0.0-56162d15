# AI Optimizations Add-On v1

## Overview of Improvements

1. **Model Quantization**: Load and run TFLite quantized models locally.
2. **Retrieval-Augmented Generation**: Use Pinecone vector DB to retrieve context and generate with OpenAI.
3. **Prompt & Response Caching**: Cache embeddings and responses with Hive.
4. **On-Device vs Cloud Hybrid**: Automatically choose local or remote inference based on connectivity.
5. **Streaming Inference**: Display partial results as they stream from OpenAI.
6. **Error Handling & Logging**: Robust try/catch and detailed logs via Logger.

## Installation

1. Unzip this add-on into your project root.
2. Add to your `pubspec.yaml`:
   ```yaml
   ai_optimizations:
     path: ./packages/ai_optimizations
   ```
3. Run installer:
   ```bash
   ./scripts/install_ai_optimizations.sh
   ```
4. Initialize in your app:
   ```dart
   await AIOptimizations.init(
     openAIApiKey: 'YOUR_KEY',
     pineconeApiKey: 'YOUR_KEY',
     pineconeEnvironment: 'us-west1-gcp',
     quantModelPath: 'assets/model_quant.tflite',
   );
   ```
5. Use:
   ```dart
   final resp = await AIOptimizations.infer('Tell me a joke');
   ```
