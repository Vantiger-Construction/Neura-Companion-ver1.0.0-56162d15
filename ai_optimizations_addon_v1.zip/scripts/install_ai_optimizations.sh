#!/usr/bin/env bash
set -e
echo "Installing AI Optimizations Add-On..."
flutter pub get
echo "Done."
