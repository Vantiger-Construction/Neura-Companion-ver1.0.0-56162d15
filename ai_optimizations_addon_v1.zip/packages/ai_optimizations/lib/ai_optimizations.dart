library ai_optimizations;

import 'dart:async';
import 'dart:convert';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:pinecone/pinecone.dart';
import 'package:openai/openai.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hive/hive.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:logger/logger.dart';

/// Central AI optimization service
class AIOptimizations {
  static final Logger _log = Logger();
  static Interpreter? _interpreter;
  static OpenAIClient? _openAI;
  static PineconeClient? _pinecone;
  static bool _initialized = false;

  /// Initialize all components
  static Future<void> init({
    required String openAIApiKey,
    required String pineconeApiKey,
    required String pineconeEnvironment,
    String? quantModelPath,
  }) async {
    if (_initialized) return;
    try {
      // Load quantized model
      if (quantModelPath != null) {
        _interpreter = await Interpreter.fromAsset(quantModelPath);
        _log.i('Loaded quantized model from \$quantModelPath');
      }
      // Init OpenAI
      _openAI = OpenAIClient(apiKey: openAIApiKey);
      // Init Pinecone
      _pinecone = PineconeClient(apiKey: pineconeApiKey, environment: pineconeEnvironment);
      // Init Hive for caching
      Hive.initFlutter();
      await Hive.openBox('response_cache');
      await Hive.openBox('embed_cache');
      _initialized = true;
      _log.i('AIOptimizations initialized');
    } catch (e) {
      _log.e('Error initializing AIOptimizations: \$e');
      rethrow;
    }
  }

  /// Quantized inference (placeholder)
  static Future<List<double>> runLocalInference(List<double> input) async {
    if (_interpreter == null) throw Exception('Local model not loaded');
    final output = List<double>.filled(256, 0);
    _interpreter!.run(input, output);
    return output;
  }

  /// Get embedding with cache
  static Future<List<double>> getEmbedding(String text) async {
    final box = Hive.box('embed_cache');
    if (box.containsKey(text)) return List<double>.from(box.get(text));
    final embed = await _openAI!.embeddings.create(input: [text], model: OpenAIEmbeddingModel.textEmbeddingAda002);
    final vec = embed.data.first.embedding;
    await box.put(text, vec);
    return vec;
  }

  /// RAG: query Pinecone and generate answer
  static Future<String> rag(String query, {int topK = 5}) async {
    final vec = await getEmbedding(query);
    final idx = _pinecone!.index('neura-index');
    final matches = await idx.fetchTopK(vec, topK: topK);
    final docs = matches.matches.map((m) => m.metadata['text']).join('\n');
    final prompt = 'Answer based on the docs:\n\$docs\nQuery: \$query';
    // streaming response
    final response = StringBuffer();
    await for (final chunk in _openAI!.chat.streamChat(
      model: ChatModel.gptTurbo,
      messages: [ChatMessage(role: Role.system, content: prompt)],
    )) {
      response.write(chunk.choices.first.delta.content);
    }
    return response.toString();
  }

  /// Cache and retrieve generic responses
  static Future<String> cachedResponse(String key, Future<String> Function() compute) async {
    final box = Hive.box('response_cache');
    if (box.containsKey(key)) return box.get(key);
    final resp = await compute();
    await box.put(key, resp);
    return resp;
  }

  /// Check connectivity
  static Future<bool> isOnline() async {
    final status = await Connectivity().checkConnectivity();
    return status != ConnectivityResult.none;
  }

  /// Decide on-device vs cloud inference
  static Future<String> infer(String input) async {
    if (await isOnline()) {
      return await rag(input);
    } else {
      final embed = await runLocalInference(input.codeUnits.map((c) => c.toDouble()).toList());
      return 'Local inference result: \$embed';
    }
  }
}
