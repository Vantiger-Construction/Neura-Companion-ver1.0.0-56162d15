# AI Optimizations

Provides utilities for:
- **Model Quantization** (TFLite)
- **Retrieval-Augmented Generation** (Pinecone + OpenAI)
- **Prompt & Response Caching** (Hive)
- **On-Device vs Cloud Hybrid** (Connectivity check)
- **Streaming Inference** (OpenAI streaming)
- **Error Handling & Logging** (Logger)
