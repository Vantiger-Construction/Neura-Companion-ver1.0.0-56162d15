Outfile "NeuraCompanionInstaller.exe"
InstallDir "$PROGRAMFILES\Neura Companion"
Page directory
Page instfiles
Section
  SetOutPath "$INSTDIR"
  File "NeuraCompanion.exe"
  CreateShortCut "$DESKTOP\Neura Companion.lnk" "$INSTDIR\NeuraCompanion.exe"
SectionEnd