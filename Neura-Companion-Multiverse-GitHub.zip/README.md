
# Neura Companion - Multiverse Edition

This project includes:
- Flutter build (with AI logic, mood tracking, Dimensional Sync)
- Unity VR build for Meta/VR deployment
- Shared logic modules
