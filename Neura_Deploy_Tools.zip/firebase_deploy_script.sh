#!/bin/bash
echo "Deploying Neura Companion Web + Version..."
firebase deploy --only hosting