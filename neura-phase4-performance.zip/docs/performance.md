# Performance & Cost Optimization

## OpenTelemetry Tracing
- Traces are sent to Jaeger. Configure `JAEGER_HOST` and `JAEGER_PORT`.
- Service name via `OTEL_SERVICE_NAME`.

## Caching TTL
- Set `RESOURCES_CACHE_TTL` (seconds) to tune resource list cache duration.

## Cost Dashboards
- Grafana dashboard `cost_dashboard.json` shows monthly cost metrics.
- Prometheus alert `MonthlyCostExceeded` fires if cost > $1000/month.

## Configuring Budget Alerts
1. Adjust threshold in `monitoring/prometheus/budget_alerts.yml`.
2. Ensure cost exporter is configured to push `cloud_service_costs_total`.
