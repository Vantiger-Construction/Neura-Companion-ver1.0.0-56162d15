from fastapi import APIRouter, Depends, Query
from sqlmodel import select
from src.db import get_session
from src.models import Resource
from src.pagination import paginate_list
from src.errors import APIError
from slowapi import limiter
import redis
import os
import json

router = APIRouter()
redis_client = redis.Redis.from_url(os.getenv('REDIS_URL','redis://localhost:6379/0'))
CACHE_TTL = int(os.getenv("RESOURCES_CACHE_TTL", "60"))

@router.get("/", response_model=dict)
@limiter.limit("100/minute")
def list_resources(cursor: int = Query(0), limit: int = Query(50), session=Depends(get_session)):
    cache_key = f"resources:{cursor}:{limit}"
    cached = redis_client.get(cache_key)
    if cached:
        return json.loads(cached)
    resources = session.exec(select(Resource).offset(cursor).limit(limit)).all()
    data = paginate_list([r.dict() for r in resources], cursor, limit)
    redis_client.set(cache_key, json.dumps(data), ex=CACHE_TTL)
    return data
