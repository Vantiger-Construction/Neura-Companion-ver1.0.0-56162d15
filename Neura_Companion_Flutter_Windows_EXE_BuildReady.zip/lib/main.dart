import 'package:flutter/material.dart';
import 'neura_animator.dart';
import 'neura_coach.dart';

void main() => runApp(NeuraApp());

class NeuraApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      home: Scaffold(
        appBar: AppBar(title: Text('Neura Companion AI')),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(child: NeuraAnimator(emotion: "happy", viseme: "A")),
            Padding(
              padding: EdgeInsets.all(16),
              child: NeuraCoach(mood: "happy", userName: "Tigger", useAI: false),
            ),
          ],
        ),
      ),
    );
  }
}