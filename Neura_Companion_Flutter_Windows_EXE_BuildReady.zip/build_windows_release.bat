@echo off
echo Building Neura Companion for Windows...
flutter pub get
flutter build windows --release
echo Build complete. Output in build\windows\runner\Release\
pause