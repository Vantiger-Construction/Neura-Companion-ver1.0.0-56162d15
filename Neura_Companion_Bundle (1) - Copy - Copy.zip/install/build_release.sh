#!/bin/bash
echo 'Building Neura Companion...'
