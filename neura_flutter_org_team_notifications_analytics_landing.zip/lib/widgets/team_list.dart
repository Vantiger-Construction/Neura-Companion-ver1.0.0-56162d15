import 'package:flutter/material.dart';

class TeamList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Stubbed with example data
    final teams = [
      {"name": "Neura Core", "role": "Admin"},
      {"name": "DevOps Squad", "role": "Member"},
    ];
    return ListView(
      children: teams.map((t) => ListTile(
        title: Text(t["name"]!),
        subtitle: Text("Role: ${t["role"]}"),
        trailing: IconButton(icon: Icon(Icons.person_add), onPressed: () {/* Invite stub */}),
      )).toList(),
    );
  }
}
