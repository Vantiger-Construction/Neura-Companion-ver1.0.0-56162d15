import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class AnalyticsCharts extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Example mood distribution data (stub)
    final moodData = {'Happy': 10, 'Sad': 5, 'Excited': 7, 'Calm': 4};
    final barSpots = moodData.entries
        .toList()
        .asMap()
        .entries
        .map((e) => BarChartRodData(toY: e.value.value.toDouble(), width: 16))
        .toList();

    return Column(
      children: [
        Text("Team Mood Distribution", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(
          height: 200,
          child: BarChart(
            BarChartData(
              barGroups: moodData.entries
                  .toList()
                  .asMap()
                  .entries
                  .map((e) => BarChartGroupData(x: e.key, barRods: [BarChartRodData(toY: e.value.value.toDouble(), width: 16)]))
                  .toList(),
              titlesData: FlTitlesData(show: false),
              borderData: FlBorderData(show: false),
            ),
          ),
        ),
        SizedBox(height: 32),
        Text("Mood Trend (stub)", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(
          height: 180,
          child: LineChart(
            LineChartData(
              lineBarsData: [
                LineChartBarData(spots: [FlSpot(0, 3), FlSpot(1, 4), FlSpot(2, 5), FlSpot(3, 6)])
              ],
              titlesData: FlTitlesData(show: false),
              borderData: FlBorderData(show: false),
            ),
          ),
        )
      ],
    );
  }
}
