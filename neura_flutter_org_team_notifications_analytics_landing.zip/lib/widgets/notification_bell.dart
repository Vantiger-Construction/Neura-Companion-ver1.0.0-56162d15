import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class NotificationProvider with ChangeNotifier {
  List<String> _notices = [];
  List<String> get notices => _notices;
  void addNotice(String notice) {
    _notices.add(notice);
    notifyListeners();
  }
  void clear() {
    _notices.clear();
    notifyListeners();
  }
}

class NotificationBell extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<NotificationProvider>(context);
    return Stack(
      children: [
        Icon(Icons.notifications),
        if (provider.notices.isNotEmpty)
          Positioned(
            right: 0,
            child: Container(
              padding: EdgeInsets.all(2),
              decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(8)),
              constraints: BoxConstraints(minWidth: 16, minHeight: 16),
              child: Text('${provider.notices.length}', style: TextStyle(color: Colors.white, fontSize: 10), textAlign: TextAlign.center),
            ),
          )
      ],
    );
  }
}
