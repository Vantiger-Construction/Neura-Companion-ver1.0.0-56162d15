import 'package:flutter/material.dart';
import '../widgets/team_list.dart';

class OrgPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Organization / Teams")),
      body: TeamList(),
    );
  }
}
