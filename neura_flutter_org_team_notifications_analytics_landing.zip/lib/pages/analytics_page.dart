import 'package:flutter/material.dart';
import '../widgets/analytics_charts.dart';

class AnalyticsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Analytics")),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: AnalyticsCharts(),
      ),
    );
  }
}
