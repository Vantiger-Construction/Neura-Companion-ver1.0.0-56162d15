import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../widgets/notification_bell.dart';

class NotificationsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final notices = Provider.of<NotificationProvider>(context).notices;
    return Scaffold(
      appBar: AppBar(title: Text("Notifications")),
      body: ListView(
        children: notices.map((n) => ListTile(title: Text(n))).toList(),
      ),
    );
  }
}
