import 'package:flutter/material.dart';

class LandingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.indigo, Colors.purpleAccent], begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.psychology, size: 80, color: Colors.white),
            SizedBox(height: 32),
            Text("Welcome to Neura Companion", style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text("Your AI-powered mood & productivity dashboard.
Grow, connect, thrive.", style: TextStyle(color: Colors.white70)),
            SizedBox(height: 32),
            ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/login'), child: Text("Log In")),
            OutlinedButton(onPressed: () => Navigator.pushNamed(context, '/about'), child: Text("About")),
          ],
        ),
      ),
    );
  }
}
