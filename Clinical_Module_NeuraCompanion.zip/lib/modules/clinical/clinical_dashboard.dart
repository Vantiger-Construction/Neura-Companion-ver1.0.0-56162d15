import 'package:flutter/material.dart';

class ClinicalDashboardPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Clinical Dashboard')),
      body: ListView(
        children: [
          ListTile(
            title: Text('Check Vitals'),
            subtitle: Text('Enter or sync your health vitals'),
            onTap: () => Navigator.pushNamed(context, '/clinical/vitals'),
          ),
          ListTile(
            title: Text('Medication Tracker'),
            subtitle: Text('View and manage medications'),
            onTap: () => Navigator.pushNamed(context, '/clinical/medications'),
          ),
          ListTile(
            title: Text('Emergency Checklist'),
            subtitle: Text('Run emergency pre-check now'),
            onTap: () => Navigator.pushNamed(context, '/clinical/emergency'),
          ),
        ],
      ),
    );
  }
}