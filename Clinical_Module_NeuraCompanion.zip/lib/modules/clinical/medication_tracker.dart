import 'package:flutter/material.dart';

class MedicationTrackerPage extends StatefulWidget {
  @override
  _MedicationTrackerPageState createState() => _MedicationTrackerPageState();
}

class _MedicationTrackerPageState extends State<MedicationTrackerPage> {
  final List<String> meds = [];
  final controller = TextEditingController();

  void addMedication() {
    if (controller.text.trim().isNotEmpty) {
      setState(() {
        meds.add(controller.text.trim());
        controller.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Medication Tracker')),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16),
            child: TextField(
              controller: controller,
              decoration: InputDecoration(
                labelText: 'Medication Name',
                suffixIcon: IconButton(
                  icon: Icon(Icons.add),
                  onPressed: addMedication,
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: meds.length,
              itemBuilder: (_, i) => ListTile(
                title: Text(meds[i]),
              ),
            ),
          ),
        ],
      ),
    );
  }
}