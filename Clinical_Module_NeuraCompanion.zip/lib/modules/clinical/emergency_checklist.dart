import 'package:flutter/material.dart';

class EmergencyChecklistPage extends StatelessWidget {
  final List<String> symptoms = [
    'Severe chest pain',
    'Shortness of breath',
    'Confusion or fainting',
    'Unusual bleeding',
    'Sudden numbness or weakness',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Emergency Checklist')),
      body: ListView(
        children: symptoms.map((s) {
          return CheckboxListTile(
            title: Text(s),
            value: false,
            onChanged: (val) {
              // Handle symptom selection here
            },
          );
        }).toList(),
      ),
    );
  }
}