import 'package:flutter/material.dart';

class VitalsMonitorPage extends StatefulWidget {
  @override
  _VitalsMonitorPageState createState() => _VitalsMonitorPageState();
}

class _VitalsMonitorPageState extends State<VitalsMonitorPage> {
  final _formKey = GlobalKey<FormState>();
  String bp = '';
  String heartRate = '';
  String temp = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Vitals Monitor')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(16),
          children: [
            TextFormField(
              decoration: InputDecoration(labelText: 'Blood Pressure'),
              onSaved: (value) => bp = value ?? '',
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Heart Rate'),
              onSaved: (value) => heartRate = value ?? '',
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Temperature (°F)'),
              onSaved: (value) => temp = value ?? '',
            ),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text('Save'),
              onPressed: () {
                _formKey.currentState?.save();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Vitals Saved')),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}