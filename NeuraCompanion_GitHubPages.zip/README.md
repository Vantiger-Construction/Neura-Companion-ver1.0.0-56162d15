
# Neura Companion (Web Version)
This branch hosts the GitHub Pages version of Neura Companion.

🌐 Access it at: https://YOUR_USERNAME.github.io/neura-companion/
