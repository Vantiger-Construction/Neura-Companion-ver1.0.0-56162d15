
Neura Companion Trailer Generator

Dependencies:
- Python 3.x
- moviepy
- numpy
- ImageMagick installed and enabled

Install dependencies:
pip install moviepy numpy

Run the script:
python neura_trailer_generator.py

This will generate 'neura_trailer.mp4' in the current folder.
