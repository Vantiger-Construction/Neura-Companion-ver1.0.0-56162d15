
from moviepy.editor import *

def make_scene(text, duration, color):
    img = np.zeros((720, 1280, 3), dtype=np.uint8)
    img[:] = color
    clip = ImageClip(img, duration=duration)
    txt_clip = TextClip(text, fontsize=60, color='white', size=clip.size, method='caption')
    txt_clip = txt_clip.set_position('center').set_duration(duration)
    return CompositeVideoClip([clip, txt_clip])

if __name__ == "__main__":
    import numpy as np

    scenes = [
        make_scene("NEURA COMPANION", 2, (0, 60, 90)),
        make_scene("Your Emotionally Intelligent AI", 2, (20, 20, 20)),
        make_scene("💬 Voice + Viseme Sync", 2, (0, 100, 150)),
        make_scene("🌈 Mood-Based Glows", 2, (80, 0, 120)),
        make_scene("🏠 Explore Joy Lounge + Mood Den", 3, (30, 90, 30)),
        make_scene("🧠 Personality + Memory Engine", 2, (100, 50, 0)),
        make_scene("🚀 Launching Now", 2, (0, 60, 90)),
    ]

    final_video = concatenate_videoclips(scenes, method="compose")
    audio = AudioClip(lambda t: 0.3 * np.sin(2 * np.pi * 261.63 * t), duration=final_video.duration)
    final_video = final_video.set_audio(audio)
    final_video.write_videofile("neura_trailer.mp4", fps=24)
