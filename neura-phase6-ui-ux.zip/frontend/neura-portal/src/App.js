import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import './i18n';
import BackgroundWrapper from './components/BackgroundWrapper';
import NeuraDashboardWrapper from './components/NeuraDashboardWrapper';
import MoodTracker from './components/MoodTracker';
import Journal from './components/Journal';
import Exercise from './components/Exercise';
import RealTimeEvents from './components/RealTimeEvents';
import Onboarding from './components/Onboarding';

function App() {
  const { t, i18n } = useTranslation();
  const changeLang = (lng) => i18n.changeLanguage(lng);

  return (
    <BrowserRouter>
      <BackgroundWrapper>
        <header role="banner" className="p-4 bg-gray-800 text-white flex justify-between items-center">
          <nav role="navigation" aria-label="Main" className="flex space-x-4">
            <Link to="/" aria-label={t('Dashboard')}>{t('Dashboard')}</Link>
            <Link to="/mood" aria-label={t('Mood Tracker')}>{t('Mood Tracker')}</Link>
            <Link to="/journal" aria-label={t('Journal')}>{t('Journal')}</Link>
            <Link to="/exercise" aria-label={t('Exercise')}>{t('Exercise')}</Link>
            <Link to="/realtime" aria-label={t('Real-Time')}>{t('Real-Time')}</Link>
            <Link to="/onboarding" aria-label={t('Onboarding')}>{t('Onboarding')}</Link>
          </nav>
          <div>
            <label htmlFor="lang-select" className="sr-only">Select language</label>
            <select
              id="lang-select"
              onChange={(e) => changeLang(e.target.value)}
              className="bg-gray-700 text-white p-1 rounded"
              aria-label="Select language"
            >
              <option value="en">EN</option>
              <option value="es">ES</option>
            </select>
          </div>
        </header>
        <main role="main" className="p-4">
          <Routes>
            <Route path="/" element={<NeuraDashboardWrapper />} />
            <Route path="/mood" element={<MoodTracker />} />
            <Route path="/journal" element={<Journal />} />
            <Route path="/exercise" element={<Exercise />} />
            <Route path="/realtime" element={<RealTimeEvents />} />
            <Route path="/onboarding" element={<Onboarding />} />
          </Routes>
        </main>
      </BackgroundWrapper>
    </BrowserRouter>
  );
}

export default App;
