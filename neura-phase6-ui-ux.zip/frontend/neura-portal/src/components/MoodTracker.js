import React from 'react';
import { useTranslation } from 'react-i18next';

export default function MoodTracker() {
  const { t } = useTranslation();
  return (
    <section aria-labelledby="mood-heading">
      <h2 id="mood-heading" className="text-2xl font-bold">{t('Mood Tracker')}</h2>
      {/* TODO: Implement mood tracking UI */}
    </section>
  );
}
