#!/usr/bin/env bash
set -e
echo "Installing Neura API v5..."
cd backend && npm install
