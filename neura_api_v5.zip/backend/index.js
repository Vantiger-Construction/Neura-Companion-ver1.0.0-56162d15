require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const promClient = require('prom-client');
const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

// Import routes
const auth = require('./routes/auth');
const jokes = require('./routes/jokes');
const dreams = require('./routes/dreams');
const settings = require('./routes/settings');
const memory = require('./routes/memory');
const shop = require('./routes/shop');
const orders = require('./routes/orders');
const subscriptions = require('./routes/subscriptions');
const ephemeral = require('./routes/ephemeral_keys');
const webhook = require('./routes/webhook');

const app = express();

// Rate limiter
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use(limiter);

// Logging
app.use(morgan('combined'));

// Metrics
const collectDefaultMetrics = promClient.collectDefaultMetrics;
collectDefaultMetrics();
app.get('/metrics', async (req, res) => {
  res.set('Content-Type', promClient.register.contentType);
  res.end(await promClient.register.metrics());
});

// Swagger setup
const swaggerOptions = {
  swaggerDefinition: {
    openapi: '3.0.0',
    info: {
      title: process.env.SWAGGER_API_TITLE,
      version: process.env.SWAGGER_API_VERSION,
    },
  },
  apis: ['./routes/*.js'],
};
const swaggerSpecs = swaggerJsdoc(swaggerOptions);

app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpecs));

// Body parser, CORS
app.use(cors());
app.use(bodyParser.json());

// Health check
app.get('/health', (req, res) => res.json({ status: 'ok' }));

// MongoDB connect
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Mount routes
app.use('/api/auth', auth);
app.use('/api/jokes', jokes);
app.use('/api/dreams', dreams);
app.use('/api/settings', settings);
app.use('/api/memory', memory);
app.use('/api/shop', shop);
app.use('/api/orders', orders);
app.use('/api/subscriptions', subscriptions);
app.use('/api/stripe', ephemeral);
app.use('/api/stripe/webhook', webhook);

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: err.message });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Neura API v5 running on port ${PORT}`));
