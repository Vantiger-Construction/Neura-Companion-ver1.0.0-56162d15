
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'neura_voice_reactive_widget.dart';
import 'neura_emotion_state.dart';
import 'neura_persona.dart';
import 'neura_emotion_memory.dart';
import 'mood_weather_widget.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final persona = NeuraPersona();
  final memory = EmotionMemory();
  await persona.loadPersona();
  await memory.loadLog();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => NeuraEmotionState()),
        ChangeNotifierProvider(create: (_) => persona),
        ChangeNotifierProvider(create: (_) => memory),
      ],
      child: const NeuraApp(),
    ),
  );
}

class NeuraApp extends StatelessWidget {
  const NeuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      theme: ThemeData.dark(),
      home: const NeuraHome(),
    );
  }
}

class NeuraHome extends StatelessWidget {
  const NeuraHome({super.key});

  @override
  Widget build(BuildContext context) {
    final mood = context.watch<NeuraPersona>().currentMood;
    final log = context.watch<EmotionMemory>().log;

    return Scaffold(
      appBar: AppBar(title: Text('Mood: $mood')),
      body: Column(
        children: [
          MoodWeatherWidget(mood: mood),
          const Expanded(child: NeuraVoiceReactiveWidget()),
          SizedBox(
            height: 120,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: log.length,
              itemBuilder: (_, i) => Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Text(log[i].mood),
                    Text(
                      log[i].time.hour.toString().padLeft(2, '0') + ':' +
                      log[i].time.minute.toString().padLeft(2, '0'),
                      style: TextStyle(fontSize: 10),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
