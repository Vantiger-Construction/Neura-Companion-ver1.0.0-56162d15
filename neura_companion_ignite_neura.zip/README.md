
# Neura Companion - IGNITE Build

✅ Real-time mic + TTS interaction  
✅ Personality-driven dialogue  
✅ Viseme-based animated mouth sync  
✅ Emotion tracking + animated moods  
✅ Responsive Lottie visuals + expression states

## How to run:
flutter pub get  
flutter run
