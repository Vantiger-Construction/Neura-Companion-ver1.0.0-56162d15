
Neura Companion Installer Package

Includes:
- NeuraCompanion.exe (placeholder main executable)
- Neura_Dream_Mode_Static_Preview.mp4
- This bundle can be used with NSIS/Inno Setup to create a full .exe installer.
