
# Neura Companion (Live API Linked)

This is the full AI-powered, real-time version of Neura Companion — now capable of:
- Real-time voice input and animation via Lottie
- Mood-based coaching and OpenAI personalization
- Offline archive dump and export
- Smart device & Discord webhook integration

## Local Run
```bash
uvicorn main:app --reload
```

## Windows Batch Run
```cmd
run_local_server.bat
```

## Flutter UI Linked Location
See `flutter/lib/` for Neura UI modules.

