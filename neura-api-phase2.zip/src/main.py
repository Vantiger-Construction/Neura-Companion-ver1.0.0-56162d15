from fastapi import FastAPI
from src.swagger_custom import customize_swagger
from src.graphql import app as graphql_app
from fastapi.middleware.cors import CORSMiddleware

api = FastAPI(docs_url=None)
customize_swagger(api)

# CORS (as previously configured)
api.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-frontend.example.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount GraphQL endpoint
api.mount("/graphql", graphql_app)

# Include other routers...
from src.auth import router as auth_router
from src.resources import router as resources_router
from src.webhooks import router as webhooks_router
from src.rate_limit import init_rate_limiter
from src.db import init_db
from src.health import router as health_router
from src.metrics import metrics_endpoint, record_metrics
from src.logging_config import configure_logging

configure_logging()
api.add_api_route('/metrics', metrics_endpoint, include_in_schema=False)
api.include_router(health_router, include_in_schema=False)

init_rate_limiter(api)
init_db()

api.include_router(auth_router, prefix="/v1/auth", tags=["auth"])
api.include_router(resources_router, prefix="/v1/resources", tags=["resources"])
api.include_router(webhooks_router, prefix="/v1/webhooks", tags=["webhooks"])
