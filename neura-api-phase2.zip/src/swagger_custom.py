from fastapi import FastAPI
from fastapi.openapi.docs import get_swagger_ui_html

def customize_swagger(app: FastAPI):
    @app.get("/docs", include_in_schema=False)
    async def custom_swagger_ui():
        return get_swagger_ui_html(
            openapi_url=app.openapi_url,
            title="Neura API v4 - Customized Docs",
            swagger_favicon_url="https://neura.app/favicon.ico",
            swagger_js_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist/swagger-ui-bundle.js",
            swagger_css_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist/swagger-ui.css",
        )
