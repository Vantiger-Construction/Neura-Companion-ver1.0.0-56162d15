from ariadne import QueryType, make_executable_schema
from ariadne.asgi import GraphQL

type_defs = """
    type Resource { id: Int, name: String }
    type Subscription { id: Int, url: String, eventType: String }
    type DeliveryRecord { id: Int, timestamp: String, statusCode: Int }
    type Query {
        resources(cursor: Int = 0, limit: Int = 50): [Resource]
        subscriptions: [Subscription]
    }
"""

query = QueryType()

@query.field("resources")
def resolve_resources(_, info, cursor=0, limit=50):
    # Placeholder: pull from DB
    return [{"id": i, "name": f"Resource {i}"} for i in range(cursor+1, cursor+limit+1)]

@query.field("subscriptions")
def resolve_subscriptions(_, info):
    # Placeholder: no real data
    return []

schema = make_executable_schema(type_defs, query)
app = GraphQL(schema, debug=True)
