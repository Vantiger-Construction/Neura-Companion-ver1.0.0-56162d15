import React, { useEffect, useState } from "react";
import axios from "axios";

function App() {
  const [subs, setSubs] = useState([]);
  useEffect(() => {
    axios.get("/v1/webhooks/subscriptions", { headers: { Authorization: "Bearer <token>" } })
      .then(res => setSubs(res.data));
  }, []);
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Webhooks Dashboard</h1>
      <ul>
        {subs.map(s => (
          <li key={s.id} className="border p-2 m-2">
            <div>ID: {s.id}</div>
            <div>URL: {s.url}</div>
            <div>Event: {s.eventType}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
