Beginner Step-by-Step Guide

1. Open your terminal and go to your project main folder.
2. Make the setup script executable:
   chmod +x setup_azure_storage.sh
3. Run the script:
   ./setup_azure_storage.sh
4. After it finishes, open lib/main.dart and replace:
   - yourAccountName: with your Azure Storage account name
   - your-container: with your container name
5. Run your app:
   flutter run

That's it! Your app now supports file upload, listing, preview, download, delete, and undo.
