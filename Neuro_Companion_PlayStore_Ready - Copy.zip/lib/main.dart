
import 'package:flutter/material.dart';
import 'dashboard.dart';

void main() {
  runApp(NeuroCompanionApp());
}

class NeuroCompanionApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neuro Companion',
      theme: ThemeData.dark(),
      home: DashboardScreen(),
    );
  }
}
