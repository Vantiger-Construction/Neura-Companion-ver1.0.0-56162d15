import 'package:flutter/material.dart';
import 'neura_animation_engine.dart';

void main() => runApp(const NeuraEmotionApp());

class NeuraEmotionApp extends StatefulWidget {
  const NeuraEmotionApp({super.key});

  @override
  State<NeuraEmotionApp> createState() => _NeuraEmotionAppState();
}

class _NeuraEmotionAppState extends State<NeuraEmotionApp> {
  String currentEmotion = 'calm';

  final List<String> emotions = [
    'happy', 'calm', 'sad', 'anxious', 'surprised',
    'confident', 'playful', 'tired', 'frustrated', 'curious'
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(title: const Text('Neura Emotion Engine')),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(child: NeuraAnimationEngine(emotion: currentEmotion)),
            Wrap(
              spacing: 10,
              children: emotions.map((emotion) {
                return ElevatedButton(
                  onPressed: () {
                    setState(() {
                      currentEmotion = emotion;
                    });
                  },
                  child: Text(emotion),
                );
              }).toList(),
            )
          ],
        ),
      ),
    );
  }
}