import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class NeuraLottieDemoScreen extends StatelessWidget {
  const NeuraLottieDemoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Neura Lottie Demo")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.asset('animations/face_blink.json', width: 200, height: 200),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              child: Text("Play Glow Pulse"),
            ),
          ],
        ),
      ),
    );
  }
}