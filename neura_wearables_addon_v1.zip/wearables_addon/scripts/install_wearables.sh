#!/usr/bin/env bash
set -e
echo "Installing wearable integration modules..."
flutter pub get
echo "✔ Wearable modules registered."
