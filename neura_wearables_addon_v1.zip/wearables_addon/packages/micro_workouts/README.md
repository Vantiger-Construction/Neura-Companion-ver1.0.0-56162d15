# MicroWorkouts

## Installation
Add to your root `pubspec.yaml`:
```yaml
micro_workouts:
  path: ./packages/micro_workouts
```

## Usage
```dart
import 'package:micro_workouts/micro_workouts.dart';

await MicroWorkouts.init();
// Use example method:
MicroWorkouts.example();
```
