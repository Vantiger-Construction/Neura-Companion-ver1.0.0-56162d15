# BiometricFeedback

## Installation
Add to your root `pubspec.yaml`:
```yaml
biometric_feedback:
  path: ./packages/biometric_feedback
```

## Usage
```dart
import 'package:biometric_feedback/biometric_feedback.dart';

await BiometricFeedback.init();
// Use example method:
BiometricFeedback.example();
```
