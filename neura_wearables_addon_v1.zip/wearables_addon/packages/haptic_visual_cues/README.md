# HapticVisualCues

## Installation
Add to your root `pubspec.yaml`:
```yaml
haptic_visual_cues:
  path: ./packages/haptic_visual_cues
```

## Usage
```dart
import 'package:haptic_visual_cues/haptic_visual_cues.dart';

await HapticVisualCues.init();
// Use example method:
HapticVisualCues.example();
```
