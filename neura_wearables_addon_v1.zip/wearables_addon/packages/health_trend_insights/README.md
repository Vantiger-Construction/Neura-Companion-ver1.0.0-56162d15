# HealthTrendInsights

## Installation
Add to your root `pubspec.yaml`:
```yaml
health_trend_insights:
  path: ./packages/health_trend_insights
```

## Usage
```dart
import 'package:health_trend_insights/health_trend_insights.dart';

await HealthTrendInsights.init();
// Use example method:
HealthTrendInsights.example();
```
