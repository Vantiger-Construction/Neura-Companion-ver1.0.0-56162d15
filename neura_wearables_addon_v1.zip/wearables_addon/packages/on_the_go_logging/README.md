# OnTheGoLogging

## Installation
Add to your root `pubspec.yaml`:
```yaml
on_the_go_logging:
  path: ./packages/on_the_go_logging
```

## Usage
```dart
import 'package:on_the_go_logging/on_the_go_logging.dart';

await OnTheGoLogging.init();
// Use example method:
OnTheGoLogging.example();
```
