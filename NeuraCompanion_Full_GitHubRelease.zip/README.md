
# Neura Companion

Neura Companion is a hyper-intelligent, emotionally-aware AI assistant. This build includes:

- Persistent mood tracking (via Hive)
- Journal and Ritual emotion graph
- Graph filter & PNG export
- Modular design for VR/desktop/mobile
- GitHub Actions auto-build for APK

## How to Build

### Android
```bash
flutter pub get
flutter packages pub run build_runner build
flutter build apk
```

### Windows
```bash
flutter pub get
flutter build windows
```

## License
(c) Vantiger Construction — All Rights Reserved.
