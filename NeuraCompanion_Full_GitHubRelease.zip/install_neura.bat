
@echo off
echo Installing Neura Companion...
cd NeuraCompanion
flutter pub get
flutter build windows
echo Done! You can find the installer in build/windows/runner/Release
pause
