#!/usr/bin/env bash
set -e

# Variables - adjust as needed
REPO_URL="https://github.com/Vantiger1/Neura-Companion-ver1.0.0-56162d14.git"
CLONE_DIR="neura-companion"
PHASE_DIR="/mnt/data/neura-api-phase5"

echo "Cloning repository..."
git clone "$REPO_URL" "$CLONE_DIR"

cd "$CLONE_DIR"

echo "Checking out main branch..."
git checkout main
git pull origin main

echo "Copying Phase 5 files into repository..."
rsync -av --exclude='.git' "$PHASE_DIR/" .

echo "Staging changes..."
git add .

echo "Committing merge of Phase 5 features into main..."
git commit -m "Merge Phase 5 features into main"

echo "Pushing to origin main..."
git push origin main

echo "Merge complete! Main branch is updated with Phase 5 features."
