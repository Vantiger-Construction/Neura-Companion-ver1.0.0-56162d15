
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:lottie/lottie.dart';

class RouteLoaderWrapper extends StatefulWidget {
  final Widget page;
  final String voiceMessage;

  const RouteLoaderWrapper({super.key, required this.page, required this.voiceMessage});

  @override
  State<RouteLoaderWrapper> createState() => _RouteLoaderWrapperState();
}

class _RouteLoaderWrapperState extends State<RouteLoaderWrapper> {
  bool _loading = true;
  final FlutterTts tts = FlutterTts();

  @override
  void initState() {
    super.initState();
    _speakIntro();
    Future.delayed(const Duration(seconds: 2), () {
      setState(() => _loading = false);
    });
  }

  Future<void> _speakIntro() async {
    await tts.setLanguage("en-US");
    await tts.setPitch(1.0);
    await tts.speak(widget.voiceMessage);
  }

  @override
  Widget build(BuildContext context) {
    return _loading
        ? Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Lottie.asset('assets/lottie/neura_react_idle.json', width: 160),
                  const SizedBox(height: 20),
                  const Text("Neura is preparing your experience..."),
                ],
              ),
            ),
          )
        : widget.page;
  }
}
