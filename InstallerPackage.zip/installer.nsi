; installer.nsi — Neura Companion Windows Installer

;--------------------------------
; General Attributes

  Name "Neura Companion"
  OutFile "NeuraCompanionInstaller.exe"
  InstallDir "$PROGRAMFILES\NeuraCompanion"
  InstallDirRegKey HKLM "Software\NeuraCompanion" "Install_Dir"
  RequestExecutionLevel admin

;--------------------------------
; Pages

  Page directory     ; directory selection
  Page instfiles     ; installation progress

;--------------------------------
; Sections

Section "MainSection" SEC01
  ; Set output path to the chosen install directory
  SetOutPath "$INSTDIR"

  ; Copy all files from build folder
  File /r "build\\*.*"

  ; Write installation path to registry
  WriteRegStr HKLM "Software\\NeuraCompanion" "Install_Dir" "$INSTDIR"

  ; Create desktop shortcut
  CreateShortcut "$DESKTOP\\Neura Companion.lnk" "$INSTDIR\\NeuraCompanion.exe" "" "$INSTDIR\\resources\\images\\logo.png"
SectionEnd

;--------------------------------
; Uninstaller

Section "Uninstall"
  ; Remove installed files
  Delete "$INSTDIR\\NeuraCompanion.exe"
  RMDir /r "$INSTDIR"

  ; Remove registry entry
  DeleteRegKey HKLM "Software\\NeuraCompanion"

  ; Remove shortcuts
  Delete "$DESKTOP\\Neura Companion.lnk"
SectionEnd
