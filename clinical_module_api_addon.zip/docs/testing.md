# Testing

Run `flutter test` in the module directory.