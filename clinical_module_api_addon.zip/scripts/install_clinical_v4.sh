#!/usr/bin/env bash
set -e
flutter pub get
echo "Clinical Module installed."
