@echo off
flutter pub get
echo Clinical Module installed.
pause
