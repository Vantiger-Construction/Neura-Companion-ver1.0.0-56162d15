# Clinical Module v4 - API Integration Add-On

## Upgrade Overview

This **Clinical Module v4** add-on provides advanced API-driven features for medical professionals:
- **Subscription Gating**: Requires in-app professional subscription via IAP.
- **FHIR Integration**: Fetch and send FHIR `Patient` and `Observation` resources.
- **Caching**: Caches fetched patient data locally; falls back to cache when offline.
- **Offline Queue**: Queues observations if network fails and flushes when available.
- **Secure Storage**: Uses encrypted storage for cache and queue data.
- **Dependency Injection**: Testable via injectable IAP, HTTP client, and storage.
- **Comprehensive API**: Methods to `init()`, `purchase()`, `fetchPatient()`, `sendObservation()`, `flushQueue()`, and `listCachedPatients()`.

## Step-by-Step Installation

1. **Unzip** the add-on into your project root:
   ```bash
   unzip clinical_module_addon.zip -d .
   ```
2. **Add Dependency**  
   In your `pubspec.yaml`, include:
   ```yaml
   clinical_module:
     path: ./packages/clinical_module
   ```
3. **Install Packages**  
   - **macOS/Linux/WSL**:
     ```bash
     ./scripts/install_clinical_v4.sh
     ```
   - **Windows**:
     ```bat
     scripts\install_clinical_v4.bat
     ```
4. **Initialize Module**  
   In `main.dart` before `runApp()`:
   ```dart
   import 'package:clinical_module/clinical_upgrades_v4.dart';

   void main() async {
     WidgetsFlutterBinding.ensureInitialized();
     final module = await ClinicalUpgradesV4.initModule(
       fhirServerUrl: 'https://your.fhir.server',
       apiKey: 'YOUR_API_KEY',
     );
     runApp(MyApp(clinicalModule: module));
   }
   ```
5. **Use Features**  
   - Fetch patient:
     ```dart
     final patient = await module.fetchPatient('patient-id');
     ```
   - Send observation:
     ```dart
     await module.sendObservation(obs);
     ```
   - Flush offline queue:
     ```dart
     await module.flushQueue();
     ```
   - List cached patients:
     ```dart
     final ids = await module.listCachedPatients();
     ```

For detailed API reference, testing guides, and CI setup, see the **docs/** directory.
