# Clinical Module

## Usage

Initialize:
```dart
final module = await ClinicalUpgradesV4.initModule(
  fhirServerUrl: 'https://your.fhir.server',
  apiKey: 'YOUR_API_KEY',
);
```

Fetch Patient:
```dart
final patient = await module.fetchPatient('patient-id');
```

Send Observation:
```dart
await module.sendObservation(obs);
```

Flush Queue:
```dart
await module.flushQueue();
```

List Cached:
```dart
final ids = await module.listCachedPatients();
```
