# AI-Driven Error Handling

## Overview
This feature integrates an AI assistant (via OpenAI) to provide on-the-fly suggestions for unhandled exceptions.

### Configuration
- Set `OPENAI_API_KEY` in your environment or `.env` file.

### Behavior
1. Any unhandled exception is caught by the global exception handler.
2. The exception details and traceback are sent to the AI model (`gpt-4o-mini`).
3. The AI response is returned alongside the error message in the API response:
   ```json
   {
     "error": "division by zero",
     "suggestion": "Check for zero values before dividing to avoid division by zero."
   }
   ```
