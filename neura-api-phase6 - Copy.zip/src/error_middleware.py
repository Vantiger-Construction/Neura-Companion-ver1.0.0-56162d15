from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi import HTTPException
from src.ai_error_handler import ai_autofix

async def global_exception_handler(request: Request, exc: Exception):
    # For HTTPExceptions, respect status code
    if isinstance(exc, HTTPException):
        suggestion = await ai_autofix(exc, request)
        return JSONResponse(status_code=exc.status_code, content={
            "error": exc.detail,
            "suggestion": suggestion
        })
    # Generic exceptions
    suggestion = await ai_autofix(exc, request)
    return JSONResponse(status_code=500, content={
        "error": str(exc),
        "suggestion": suggestion
    })
