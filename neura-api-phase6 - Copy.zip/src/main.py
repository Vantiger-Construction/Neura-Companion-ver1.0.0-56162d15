from fastapi import FastAPI
from src.db import init_db
from src.auth import router as auth_router
from src.resources import router as resources_router
from src.webhooks import router as webhooks_router
from src.rate_limit import init_rate_limiter
from src.health import router as health_router
from src.metrics import metrics_endpoint
from src.logging_config import configure_logging
from src.error_middleware import global_exception_handler

app = FastAPI()

# Configure logging, CORS, metrics, etc. assumed previously done

# Register global exception handler
app.add_exception_handler(Exception, global_exception_handler)

# Existing init and routes
init_rate_limiter(app)
configure_logging()
init_db()
app.add_api_route('/metrics', metrics_endpoint, include_in_schema=False)
app.include_router(health_router, include_in_schema=False)
app.include_router(auth_router, prefix="/v1/auth", tags=["auth"])
app.include_router(resources_router, prefix="/v1/resources", tags=["resources"])
app.include_router(webhooks_router, prefix="/v1/webhooks", tags=["webhooks"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
