import traceback
import os
from fastapi import Request
from openai import OpenAI
from fastapi import HTTPException

# Initialize OpenAI client
openai_api_key = os.getenv("OPENAI_API_KEY")
ai_client = OpenAI(api_key=openai_api_key) if openai_api_key else None

async def ai_autofix(exc: Exception, request: Request) -> str:
    if not ai_client:
        return "AI client not configured."
    tb = traceback.format_exc()
    prompt = (
        f"You are an AI assistant for code debugging. An exception occurred: {exc}\n"
        f"Stack trace:\n{tb}\n"
        f"Request URL: {request.url}\n"
        "Provide a concise suggestion to fix this error in the code."
    )
    try:
        response = await ai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
        )
        suggestion = response.choices[0].message.content.strip()
    except Exception as e:
        suggestion = f"Error obtaining AI suggestion: {e}"
    return suggestion
