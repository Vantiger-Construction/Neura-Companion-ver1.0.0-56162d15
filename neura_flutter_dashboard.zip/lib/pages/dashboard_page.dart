import 'package:flutter/material.dart';

class DashboardPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Neura Dashboard")),
      body: Center(child: Text("Welcome to the Neura Dashboard! (Mood, Export, Integrations, Copilot coming soon)")),
    );
  }
}
