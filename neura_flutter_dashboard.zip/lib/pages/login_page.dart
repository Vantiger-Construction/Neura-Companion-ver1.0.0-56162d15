import 'package:flutter/material.dart';
import '../api.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _userController = TextEditingController();
  final _passController = TextEditingController();
  String? _error;

  void _login() async {
    final token = await NeuraApi.login(_userController.text, _passController.text);
    if (token != null) {
      Navigator.pushReplacementNamed(context, '/dashboard');
    } else {
      setState(() { _error = "Login failed. Check your credentials."; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Card(
          elevation: 5,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: _userController, decoration: InputDecoration(labelText: "Username")),
                TextField(controller: _passController, decoration: InputDecoration(labelText: "Password"), obscureText: true),
                SizedBox(height: 16),
                ElevatedButton(onPressed: _login, child: Text("Login")),
                if (_error != null) ...[SizedBox(height: 8), Text(_error!, style: TextStyle(color: Colors.red))],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
