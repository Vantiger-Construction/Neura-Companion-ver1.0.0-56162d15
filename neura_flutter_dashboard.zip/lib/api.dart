import 'package:http/http.dart' as http;
import 'dart:convert';

class NeuraApi {
  static const String baseUrl = 'http://localhost:8000'; // change for prod

  static Future<String?> login(String username, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/v1/auth/token'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {'username': username, 'password': password},
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body)['access_token'];
    }
    return null;
  }
}
