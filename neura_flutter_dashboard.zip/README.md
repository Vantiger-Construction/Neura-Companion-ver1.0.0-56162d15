# Neura Flutter Dashboard (Starter)

1. Set your backend API base URL in `lib/api.dart`.
2. Run:
    flutter pub get
    flutter run -d chrome    # for web
    flutter run              # for mobile

## Pages
- Login (with JWT)
- Dashboard (future: mood chart, feed, integrations, copilot, export, etc)

Ready to extend for enterprise features.
