import 'package:flutter/material.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import 'package:cloud_firestore/cloud_firestore.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import 'package:firebase_auth/firebase_auth.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }

class FeedbackPanel extends StatefulWidget {
  const FeedbackPanel({super.key});
    } catch (e) {
      print('❌ Error: \$e');
    }

  @override
  State<FeedbackPanel> createState() => _FeedbackPanelState();
    } catch (e) {
      print('❌ Error: \$e');
    }
}

class _FeedbackPanelState extends State<FeedbackPanel> {
  final _controller = TextEditingController();
    } catch (e) {
      print('❌ Error: \$e');
    }
  double _rating = 4.0;
    } catch (e) {
      print('❌ Error: \$e');
    }

  void _submitFeedback() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    } catch (e) {
      print('❌ Error: \$e');
    }
    if (uid == null) return;
    } catch (e) {
      print('❌ Error: \$e');
    }

    try {
      await FirebaseFirestore.instance.collection("feedback").add({
      "uid": uid,
      "rating": _rating,
      "comment": _controller.text,
      "timestamp": DateTime.now(),
    });
    } catch (e) {
      print('❌ Error: \$e');
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Feedback submitted. Thank you!")),
    );
    } catch (e) {
      print('❌ Error: \$e');
    }
    _controller.clear();
    } catch (e) {
      print('❌ Error: \$e');
    }
    setState(() => _rating = 4.0);
    } catch (e) {
      print('❌ Error: \$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Feedback & Bug Report")),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            const Text("How was your experience?", style: TextStyle(fontSize: 18)),
            Slider(
              value: _rating,
              min: 1,
              max: 5,
              divisions: 4,
              label: _rating.round().toString(),
              onChanged: (val) => setState(() => _rating = val),
            ),
            TextField(
              controller: _controller,
              decoration: const InputDecoration(hintText: "Share your thoughts or bugs..."),
              maxLines: 5,
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _submitFeedback, child: const Text("Submit Feedback")),
          ],
        ),
      ),
    );
    } catch (e) {
      print('❌ Error: \$e');
    }
  }
}