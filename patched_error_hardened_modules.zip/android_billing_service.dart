import 'package:in_app_purchase/in_app_purchase.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import 'package:cloud_firestore/cloud_firestore.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import 'package:firebase_auth/firebase_auth.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }

class AndroidBillingService {
  static const _monthlyProductId = 'neuro_monthly_499';
    } catch (e) {
      print('❌ Error: \$e');
    }
  static final InAppPurchase _iap = InAppPurchase.instance;
    } catch (e) {
      print('❌ Error: \$e');
    }

  static Future<void> init() async {
    final available = try {
      await _iap.isAvailable();
    } catch (e) {
      print('❌ Error: \$e');
    }
    if (!available) {
      throw Exception("In-App Purchases not available.");
    } catch (e) {
      print('❌ Error: \$e');
    }
    }
  }

  static Future<List<ProductDetails>> getProducts() async {
    final response = try {
      await _iap.queryProductDetails({_monthlyProductId});
    } catch (e) {
      print('❌ Error: \$e');
    }
    return response.productDetails.toList();
    } catch (e) {
      print('❌ Error: \$e');
    }
  }

  static Future<void> buyMonthly(ProductDetails product) async {
    final purchaseParam = PurchaseParam(productDetails: product);
    } catch (e) {
      print('❌ Error: \$e');
    }
    try {
      await _iap.buyNonConsumable(purchaseParam: purchaseParam);
    } catch (e) {
      print('❌ Error: \$e');
    }
  }

  static Future<void> handlePurchaseUpdates() async {
    _iap.purchaseStream.listen((purchases) async {
      for (var purchase in purchases) {
        if (purchase.status == PurchaseStatus.purchased) {
          final uid = FirebaseAuth.instance.currentUser?.uid;
    } catch (e) {
      print('❌ Error: \$e');
    }
          if (uid != null) {
            try {
      await FirebaseFirestore.instance.collection("users").doc(uid).set({
              "isPremiumUser": true,
            }, SetOptions(merge: true));
    } catch (e) {
      print('❌ Error: \$e');
    }
          }
        }
      }
    });
    } catch (e) {
      print('❌ Error: \$e');
    }
  }
}