import 'package:flutter/material.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import 'package:firebase_auth/firebase_auth.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import 'package:cloud_firestore/cloud_firestore.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }

class PrivacyAgreementScreen extends StatefulWidget {
  final VoidCallback onAccepted;
    } catch (e) {
      print('❌ Error: \$e');
    }
  const PrivacyAgreementScreen({super.key, required this.onAccepted});
    } catch (e) {
      print('❌ Error: \$e');
    }

  @override
  State<PrivacyAgreementScreen> createState() => _PrivacyAgreementScreenState();
    } catch (e) {
      print('❌ Error: \$e');
    }
}

class _PrivacyAgreementScreenState extends State<PrivacyAgreementScreen> {
  bool _accepted = false;
    } catch (e) {
      print('❌ Error: \$e');
    }

  final String _policy = """
Privacy Policy Agreement

Neuro Companion collects data to personalize your experience. This includes your mood, goals, rituals, and usage patterns.

We do NOT sell your data. Your information is stored securely with Firebase and may be used to improve your mental wellness journey.

By tapping 'I Agree', you accept our full Privacy Policy available at neurocompanion.app/privacy.
""";
    } catch (e) {
      print('❌ Error: \$e');
    }

  void _confirm() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    } catch (e) {
      print('❌ Error: \$e');
    }
    if (uid == null) return;
    } catch (e) {
      print('❌ Error: \$e');
    }

    try {
      await FirebaseFirestore.instance.collection("users").doc(uid).set({
      "acceptedPrivacy": true,
    }, SetOptions(merge: true));
    } catch (e) {
      print('❌ Error: \$e');
    }

    widget.onAccepted();
    } catch (e) {
      print('❌ Error: \$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Privacy Agreement")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Expanded(child: SingleChildScrollView(child: Text(_policy))),
            CheckboxListTile(
              title: const Text("I have read and agree to the Privacy Policy"),
              value: _accepted,
              onChanged: (v) => setState(() => _accepted = v ?? false),
            ),
            ElevatedButton(
              onPressed: _accepted ? _confirm : null,
              child: const Text("I Agree"),
            )
          ],
        ),
      ),
    );
    } catch (e) {
      print('❌ Error: \$e');
    }
  }
}