import 'package:flutter/material.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import 'package:provider/provider.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import 'package:cloud_firestore/cloud_firestore.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import 'package:firebase_auth/firebase_auth.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import '../ai_engine.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import '../smart_trigger_service.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import 'package:shared_preferences/shared_preferences.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }

class RitualCheckInScreen extends StatefulWidget {
  const RitualCheckInScreen({super.key});
    } catch (e) {
      print('❌ Error: \$e');
    }

  @override
  State<RitualCheckInScreen> createState() => _RitualCheckInScreenState();
    } catch (e) {
      print('❌ Error: \$e');
    }
}

class _RitualCheckInScreenState extends State<RitualCheckInScreen> {
  String _mood = "";
    } catch (e) {
      print('❌ Error: \$e');
    }
  String _motivation = "";
    } catch (e) {
      print('❌ Error: \$e');
    }
  bool _submitted = false;
    } catch (e) {
      print('❌ Error: \$e');
    }
  String _aiResponse = "";
    } catch (e) {
      print('❌ Error: \$e');
    }
  bool _sharePublicly = false;
    } catch (e) {
      print('❌ Error: \$e');
    }
  String? _activeChallengeId;
    } catch (e) {
      print('❌ Error: \$e');
    }

  final List<String> moods = ["😊", "😐", "😢", "😠", "🥱", "😴"];
    } catch (e) {
      print('❌ Error: \$e');
    }
  final List<String> motivationLevels = ["High", "Medium", "Low"];
    } catch (e) {
      print('❌ Error: \$e');
    }

  Future<void> _loadActiveChallenge() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    } catch (e) {
      print('❌ Error: \$e');
    }
    final challengeSnap = try {
      await FirebaseFirestore.instance
        .collection('user_challenges')
        .where('uid', isEqualTo: uid)
        .limit(1)
        .get();
    } catch (e) {
      print('❌ Error: \$e');
    }

    if (challengeSnap.docs.isNotEmpty) {
      setState(() {
        _activeChallengeId = challengeSnap.docs.first['challengeId'];
    } catch (e) {
      print('❌ Error: \$e');
    }
      });
    } catch (e) {
      print('❌ Error: \$e');
    }
    }
  }

  void _submitCheckIn() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    } catch (e) {
      print('❌ Error: \$e');
    }
    final now = DateTime.now();
    } catch (e) {
      print('❌ Error: \$e');
    }
    final doc = {
      "uid": uid,
      "mood": _mood,
      "motivation": _motivation,
      "timestamp": now,
      "challengeId": _activeChallengeId,
    };
    } catch (e) {
      print('❌ Error: \$e');
    }

    try {
      await FirebaseFirestore.instance.collection("ritual_checkins").add(doc);
    } catch (e) {
      print('❌ Error: \$e');
    }

    if (_sharePublicly) {
      try {
      await FirebaseFirestore.instance.collection("ritual_feed").add({
        "mood": _mood,
        "motivation": _motivation,
        "timestamp": now,
        "uid": uid,
        "username": "Anonymous",
        "upvotes": 0,
        "challengeId": _activeChallengeId,
      });
    } catch (e) {
      print('❌ Error: \$e');
    }
    }

    final prefs = try {
      await SharedPreferences.getInstance();
    } catch (e) {
      print('❌ Error: \$e');
    }
    final lightsOn = prefs.getBool('smart_light_enabled') ?? true;
    } catch (e) {
      print('❌ Error: \$e');
    }
    final soundsOn = prefs.getBool('smart_sound_enabled') ?? true;
    } catch (e) {
      print('❌ Error: \$e');
    }
    if (lightsOn || soundsOn) {
      try {
      await SmartTriggerService.triggerMorningRoutine();
    } catch (e) {
      print('❌ Error: \$e');
    }
    }

    final suggestion = context.read<AIState>().getAISuggestion();
    } catch (e) {
      print('❌ Error: \$e');
    }
    setState(() {
      _submitted = true;
    } catch (e) {
      print('❌ Error: \$e');
    }
      _aiResponse = suggestion;
    } catch (e) {
      print('❌ Error: \$e');
    }
    });
    } catch (e) {
      print('❌ Error: \$e');
    }
  }

  @override
  void initState() {
    super.initState();
    } catch (e) {
      print('❌ Error: \$e');
    }
    _loadActiveChallenge();
    } catch (e) {
      print('❌ Error: \$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Daily Ritual Check-In")),
      body: _submitted
          ? Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text("✅ Check-in complete!", style: TextStyle(fontSize: 18)),
                  const SizedBox(height: 20),
                  Text("AI Suggestion:", style: Theme.of(context).textTheme.titleMedium),
                  Text(_aiResponse, style: Theme.of(context).textTheme.bodyLarge),
                ],
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  const Text("How do you feel?", style: TextStyle(fontSize: 18)),
                  Wrap(
                    spacing: 10,
                    children: moods.map((m) {
                      return ChoiceChip(
                        label: Text(m),
                        selected: _mood == m,
                        onSelected: (_) => setState(() => _mood = m),
                      );
    } catch (e) {
      print('❌ Error: \$e');
    }
                    }).toList(),
                  ),
                  const SizedBox(height: 24),
                  const Text("Motivation Level", style: TextStyle(fontSize: 18)),
                  Wrap(
                    spacing: 10,
                    children: motivationLevels.map((level) {
                      return ChoiceChip(
                        label: Text(level),
                        selected: _motivation == level,
                        onSelected: (_) => setState(() => _motivation = level),
                      );
    } catch (e) {
      print('❌ Error: \$e');
    }
                    }).toList(),
                  ),
                  const SizedBox(height: 24),
                  SwitchListTile(
                    title: const Text("Share to public ritual feed"),
                    value: _sharePublicly,
                    onChanged: (value) => setState(() => _sharePublicly = value),
                  ),
                  if (_activeChallengeId != null)
                    Text("🌟 Participating in Challenge: $_activeChallengeId"),
                  ElevatedButton(
                    onPressed: _mood.isNotEmpty && _motivation.isNotEmpty ? _submitCheckIn : null,
                    child: const Text("Submit Check-In"),
                  ),
                ],
              ),
            ),
    );
    } catch (e) {
      print('❌ Error: \$e');
    }
  }
}