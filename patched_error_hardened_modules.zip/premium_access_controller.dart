import 'package:cloud_firestore/cloud_firestore.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }
import 'package:firebase_auth/firebase_auth.dart';
    } catch (e) {
      print('❌ Error: \$e');
    }

class PremiumAccessController {
  static Future<bool> isPremium() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    } catch (e) {
      print('❌ Error: \$e');
    }
    if (uid == null) return false;
    } catch (e) {
      print('❌ Error: \$e');
    }

    final doc = try {
      await FirebaseFirestore.instance.collection("users").doc(uid).get();
    } catch (e) {
      print('❌ Error: \$e');
    }
    return doc.exists && (doc.data()?['isPremiumUser'] == true);
    } catch (e) {
      print('❌ Error: \$e');
    }
  }

  static Future<void> grantPremium() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    } catch (e) {
      print('❌ Error: \$e');
    }
    if (uid == null) return;
    } catch (e) {
      print('❌ Error: \$e');
    }

    try {
      await FirebaseFirestore.instance.collection("users").doc(uid).set({
      "isPremiumUser": true,
    }, SetOptions(merge: true));
    } catch (e) {
      print('❌ Error: \$e');
    }
  }
}