const STRIPE_CHECKOUT_URL = 'https://buy.stripe.com/test_a1b2c3d4e5f6g7h8';
const API_BASE_URL = 'https://yourserver.com/api';

document.getElementById("buyNow").addEventListener("click", () => {
    window.location.href = STRIPE_CHECKOUT_URL;
});

document.getElementById("activateLicense").addEventListener("click", async () => {
    const email = document.getElementById("email").value.trim();
    const licenseKey = document.getElementById("licenseKey").value.trim();
    const activationMessage = document.getElementById("activationMessage");

    if (!email || !licenseKey) {
        activationMessage.textContent = "Please enter both your email and license key.";
        activationMessage.style.color = "red";
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/verify-key`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ key: licenseKey, email })
        });

        const result = await response.json();
        if (result.valid) {
            activationMessage.textContent = "License activated successfully! You can now access premium features.";
            activationMessage.style.color = "green";
            localStorage.setItem("premiumUser", "true"); 
        } else {
            activationMessage.textContent = "Invalid license key. Please check your email or contact support.";
            activationMessage.style.color = "red";
        }
    } catch (error) {
        activationMessage.textContent = "Error activating license. Please try again later.";
        activationMessage.style.color = "red";
    }
});