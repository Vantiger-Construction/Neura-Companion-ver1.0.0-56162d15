Double-click Launch_Neura_Companion.bat to open the Neura Companion preview in your browser.
