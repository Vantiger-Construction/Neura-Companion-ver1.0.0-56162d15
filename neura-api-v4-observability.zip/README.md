# Neura API v4

## Environment Variables

- `JWT_SECRET`: Secret key for JWT encoding
- `WEBHOOK_SECRET`: Secret for HMAC signatures
- `DATABASE_URL`: SQLModel database URL

## Quickstart

Run migrations:
```bash
alembic upgrade head
```

Start server:
```bash
uvicorn src.main:app --reload
```
