from fastapi import HTTPException
from typing import Any, Dict

error_catalog: Dict[str, Dict[str, Any]] = {
    "SUB_NOT_FOUND": {"status": 404, "message": "Subscription not found"},
    "HISTORY_NOT_FOUND": {"status": 404, "message": "History not found"},
    "INVALID_SIGNATURE": {"status": 401, "message": "Signature verification failed"},
    "RATE_LIMIT": {"status": 429, "message": "Too Many Requests"},
    "AUTH_FAILURE": {"status": 401, "message": "Authentication Failed"}
}

class APIError(HTTPException):
    def __init__(self, code: str):
        info = error_catalog.get(code, {"status":400,"message":"Unknown error"})
        super().__init__(status_code=info["status"], detail={"code":code,"message":info["message"]})
