from fastapi import APIRouter, Depends, Query
from sqlmodel import select
from src.db import get_session
from src.models import Resource
from src.pagination import paginate_list
from src.errors import APIError
from slowapi import limiter

router = APIRouter()

@router.get("/", response_model=dict)
@limiter.limit("100/minute")
def list_resources(cursor: int = Query(0), limit: int = Query(50), session=Depends(get_session)):
    resources = session.exec(select(Resource).offset(cursor).limit(limit)).all()
    if resources is None:
        raise APIError("UNKNOWN")
    data = paginate_list([r.dict() for r in resources], cursor, limit)
    return data
