def paginate_list(items, cursor=0, limit=50):
    start = int(cursor)
    end = start + limit
    next_cursor = end if end < len(items) else None
    prev_cursor = start - limit if start - limit >= 0 else None
    return {
        "items": items[start:end],
        "pageInfo": {"nextCursor": next_cursor, "prevCursor": prev_cursor}
    }
