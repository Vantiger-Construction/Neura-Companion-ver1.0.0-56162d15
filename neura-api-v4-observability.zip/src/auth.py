import os
from fastapi import APIRouter, Depends, HTTPException, Security
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm, SecurityScopes
import jwt
from src.errors import APIError

SECRET_KEY = os.getenv("JWT_SECRET", "secretkey")
ALGORITHM = "HS256"

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/v1/auth/token", scopes={
    "resources:read": "Read resources",
    "webhooks:manage": "Manage webhooks"
})
router = APIRouter()

@router.post("/token", response_model=dict)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    token_data = {"sub": form_data.username, "scopes": form_data.scopes}
    token = jwt.encode(token_data, SECRET_KEY, algorithm=ALGORITHM)
    return {"access_token": token, "token_type": "bearer"}

@router.get("/me", response_model=dict)
async def read_me(security_scopes: SecurityScopes, token: str = Security(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.PyJWTError:
        raise APIError("AUTH_FAILURE")
    for scope in security_scopes.scopes:
        if scope not in payload.get("scopes", []):
            raise APIError("AUTH_FAILURE")
    return {"username": payload["sub"], "scopes": payload.get("scopes", [])}
