from pydantic import BaseModel, HttpUrl
from typing import Dict, Any

class SubscriptionCreate(BaseModel):
    url: HttpUrl
    eventType: str

class LegacyTrigger(BaseModel):
    legacyEventName: str
    payload: Dict[str, Any]
