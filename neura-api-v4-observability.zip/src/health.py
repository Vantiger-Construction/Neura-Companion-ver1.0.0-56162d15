from fastapi import APIRouter, HTTPException

router = APIRouter()

@router.get('/healthz')
def healthz():
    return {'status': 'ok'}

@router.get('/readyz')
def readyz():
    # Could check DB connection, cache, etc.
    return {'status': 'ready'}
