from loguru import logger
import sys

def configure_logging():
    logger.remove()
    logger.add(sys.stdout, format='{"time": "{time}", "level": "{level}", "message": "{message}" }', serialize=True)
    logger.add("logs/neura_api.log", rotation="10 MB", retention="10 days", serialize=True)
