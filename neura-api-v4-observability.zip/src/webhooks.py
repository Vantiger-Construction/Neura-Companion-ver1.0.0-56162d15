import os, time, hmac, datetime
import httpx
from typing import List, Dict, Any
from fastapi import APIRouter, Request, Depends
from sqlmodel import select
from src.db import get_session
from src.models import Subscription, DeliveryRecord
from src.schemas import SubscriptionCreate, LegacyTrigger
from src.errors import APIError
from slowapi import limiter

router = APIRouter()

@router.post("/subscribe", response_model=Subscription, status_code=201)
@limiter.limit("50/minute")
def subscribe(sub: SubscriptionCreate, session=Depends(get_session)):
    subscription = Subscription(url=sub.url, eventType=sub.eventType)
    session.add(subscription); session.commit(); session.refresh(subscription)
    return subscription

@router.get("/subscriptions", response_model=List[Subscription])
@limiter.limit("50/minute")
def list_subscriptions(session=Depends(get_session)):
    return session.exec(select(Subscription)).all()

@router.delete("/subscriptions/{id}", status_code=204)
@limiter.limit("20/minute")
def unsubscribe(id: int, session=Depends(get_session)):
    sub = session.get(Subscription, id)
    if not sub:
        raise APIError("SUB_NOT_FOUND")
    session.delete(sub); session.commit()

@router.get("/subscriptions/{id}/history", response_model=List[DeliveryRecord])
@limiter.limit("50/minute")
def get_history(id: int, session=Depends(get_session)):
    sub = session.get(Subscription, id)
    if not sub:
        raise APIError("HISTORY_NOT_FOUND")
    return session.exec(select(DeliveryRecord).where(DeliveryRecord.subscription_id == id)).all()

@router.get("/subscriptions/{id}/status", response_model=DeliveryRecord)
@limiter.limit("50/minute")
def get_status(id: int, session=Depends(get_session)):
    record = session.exec(select(DeliveryRecord).where(DeliveryRecord.subscription_id == id).order_by(DeliveryRecord.timestamp.desc()).limit(1)).one_or_none()
    if not record: 
        raise APIError("HISTORY_NOT_FOUND")
    return record

@router.post("/receive", status_code=200)
@limiter.limit("100/minute")
async def receive_event(request: Request, session=Depends(get_session)):
    ts = request.headers.get("X-Timestamp")
    sig = request.headers.get("X-Signature")
    body = await request.body()
    if not ts or not sig or not (abs(time.time() - int(ts)) <= 300):
        raise APIError("INVALID_SIGNATURE")
    expected = hmac.new(os.getenv("WEBHOOK_SECRET", "secretkey").encode(), body, getattr(__import__('hashlib'), 'sha256')).hexdigest()
    if not hmac.compare_digest(expected, sig):
        raise APIError("INVALID_SIGNATURE")
    event = await request.json()
    results = []
    subs = session.exec(select(Subscription)).all()
    for sub in subs:
        try:
            resp = await httpx.post(sub.url, json=event)
            code = resp.status_code
        except:
            code = 500
        rec = DeliveryRecord(timestamp=datetime.datetime.utcnow(), statusCode=code, subscription_id=sub.id)
        session.add(rec); session.commit()
        results.append({"id": sub.id, "status": code})
    return {"dispatched": results}

@router.post("/legacy", response_model=List[Dict[str, Any]])
@limiter.limit("30/minute")
def legacy_trigger(trigger: LegacyTrigger, session=Depends(get_session)):
    event = {"type": trigger.legacyEventName, **trigger.payload}
    results = []
    subs = session.exec(select(Subscription)).all()
    for sub in subs:
        try:
            resp = httpx.post(sub.url, json=event)
            code = resp.status_code
        except:
            code = 500
        rec = DeliveryRecord(timestamp=datetime.datetime.utcnow(), statusCode=code, subscription_id=sub.id)
        session.add(rec); session.commit()
        results.append({"id": sub.id, "status": code})
    return results
