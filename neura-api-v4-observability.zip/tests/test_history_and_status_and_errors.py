from fastapi.testclient import TestClient
import hmac, hashlib, time
import os

from src.main import app
client = TestClient(app)

def test_status_and_errors(monkeypatch):
    # Subscribe
    sub = client.post("/v1/webhooks/subscribe", json={"url":"http://x","eventType":"e"})
    sid = sub.json()["id"]
    # Status before any receive -> 404
    assert client.get(f"/v1/webhooks/subscriptions/{sid}/status").status_code == 404
    # Invalid subscribe payload
    assert client.post("/v1/webhooks/subscribe", json={"eventType":"e"}).status_code == 422
    # Simulate receive
    secret = "secretkey"
    monkeypatch.setenv("WEBHOOK_SECRET", secret)
    body = b'{"foo":"bar"}'
    ts = str(int(time.time()))
    sig = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    rec = client.post("/v1/webhooks/receive", data=body, headers={"X-Timestamp":ts,"X-Signature":sig})
    assert rec.status_code == 200
    # Status now
    assert client.get(f"/v1/webhooks/subscriptions/{sid}/status").status_code == 200
