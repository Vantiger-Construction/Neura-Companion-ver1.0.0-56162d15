from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_subscribe_list_unsubscribe():
    sub = client.post("/v1/webhooks/subscribe", json={"url":"http://x","eventType":"foo"})
    assert sub.status_code == 201
    sid = sub.json()["id"]
    lst = client.get("/v1/webhooks/subscriptions")
    assert any(s["id"]==sid for s in lst.json())
    del_resp = client.delete(f"/v1/webhooks/subscriptions/{sid}")
    assert del_resp.status_code == 204
