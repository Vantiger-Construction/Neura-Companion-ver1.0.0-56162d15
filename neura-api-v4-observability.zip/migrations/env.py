import os, sys
from logging.config import fileConfig
from alembic import context
from sqlalchemy import engine_from_config, pool

# include src path
sys.path.append(os.getcwd())
config = context.config
fileConfig(config.config_file_name)

from src.models import SQLModel
target_metadata = SQLModel.metadata

def run_migrations_online():
    connectable = engine_from_config(config.get_section(config.config_ini_section), prefix='sqlalchemy.', poolclass=pool.NullPool)
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()

if context.is_offline_mode():
    context.configure(url=os.getenv("DATABASE_URL"))
    with context.begin_transaction():
        context.run_migrations()
else:
    run_migrations_online()
