import 'package:flutter/material.dart';

enum MoodType { calm, focus, energy, reflective }

class MoodNotifier extends ValueNotifier<MoodType> {
  MoodNotifier() : super(MoodType.calm);

  void update(MoodType newMood) {
    if (value != newMood) {
      value = newMood;
    }
  }
}