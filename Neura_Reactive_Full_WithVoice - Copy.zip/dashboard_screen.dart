
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'mood_notifier.dart';
import 'mood_history_tracker.dart';
import 'neura_mood_dashboard_tile.dart';
import 'neura_mood_trend_chart.dart';
import 'neura_mood_snapshot_tile.dart';

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final moodNotifier = Provider.of<MoodNotifier>(context);
    final moodHistory = Provider.of<MoodHistoryTracker>(context);

    try {
      moodHistory.log(moodNotifier.value);
    } catch (e) {
      debugPrint("Failed to log mood: \$e");
    }

    final recentMoods = moodHistory.getRecent();
    final todayMood = moodHistory.todayDominant;
    final yesterdayMood = moodHistory.yesterdayDominant;

    return Scaffold(
      appBar: AppBar(title: Text("Neura Dashboard")),
      body: ListView(
        children: [
          NeuraMoodDashboardTile(
            currentMood: moodNotifier.value,
            recentHistory: recentMoods,
            lastUpdate: DateTime.now(),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: AspectRatio(
              aspectRatio: 1.6,
              child: NeuraMoodTrendChart(moods: recentMoods),
            ),
          ),
          NeuraMoodSnapshotTile(
            todayMood: todayMood,
            yesterdayMood: yesterdayMood,
          ),
        ],
      ),
    );
  }
}
