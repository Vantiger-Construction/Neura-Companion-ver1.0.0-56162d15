import React, { useEffect, useState } from "react";

export default function RealTimeEvents() {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const ws = new WebSocket(`ws://${window.location.host}/ws/webhooks`);
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      setMessages((msgs) => [...msgs, data]);
    };
    return () => ws.close();
  }, []);

  return (
    <div className="bg-white bg-opacity-80 rounded p-4">
      <h2 className="text-2xl font-bold">Real-Time Events</h2>
      <ul>
        {messages.map((m, i) => (
          <li key={i}>{JSON.stringify(m)}</li>
        ))}
      </ul>
    </div>
  );
}
