# ... existing imports ...
from src.realtime import manager

# In receive_event (after dispatching to Celery):
    for sub in subs:
        dispatch_event.delay(sub.id, event)
    # Real-time broadcast to connected clients
    await manager.broadcast({"type": "event_received", "event": event})
    return {"dispatched": len(subs)}

# WebSocket endpoint registration
router.websocket("/ws/webhooks")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except:
        manager.disconnect(websocket)
