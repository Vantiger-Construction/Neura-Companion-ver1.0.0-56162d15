from fastapi import FastAPI, WebSocket
from src.realtime import manager
# ... other imports ...

app = FastAPI()
# ... existing middleware and routes ...

# Mount WebSocket endpoint via router (imported above)
# (Ensure 'router' from src.webhooks is included)
