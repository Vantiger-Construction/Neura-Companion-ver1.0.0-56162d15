describe('Neura Portal E2E', () => {
  it('Loads dashboard and connects WebSocket', () => {
    cy.visit('/');
    cy.contains('Dashboard');
    cy.visit('/realtime');
    cy.contains('Real-Time Events');
    // We cannot simulate real WS easily, but ensure WS connection property
    cy.window().its('WebSocket').should('exist');
  });
});
