
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server.dart';
import '../services/mood/mood_logger_service.dart';
import '../services/mood/mood_export_service.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

Future<void> sendWeeklyMoodReport() async {
  final entries = MoodLoggerService.getLast7Days();
  final dir = await getApplicationDocumentsDirectory();
  final pdfPath = "\${dir.path}/weekly_mood_report.pdf";
  await MoodExportService.exportToPDF(entries, pdfPath);

  final smtpServer = gmail('neura.bot@example.com', 'securepassword'); // replace with env
  final message = Message()
    ..from = Address('neura.bot@example.com', 'Neura Companion')
    ..recipients.add('user@example.com') // to be dynamically injected per account
    ..subject = '🧠 Your Weekly Mood Report'
    ..text = 'Attached is your mood history for the past week.'
    ..attachments = [FileAttachment(File(pdfPath))];

  try {
    final sendReport = await send(message, smtpServer);
    print('Weekly report sent: ' + sendReport.toString());
  } catch (e) {
    print('Failed to send report: $e');
  }
}
