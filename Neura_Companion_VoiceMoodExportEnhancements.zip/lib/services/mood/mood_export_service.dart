
import 'dart:io';
import 'package:csv/csv.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

class MoodExportService {
  static Future<File> exportToCSV(List<Map<String, dynamic>> moodEntries, String path) async {
    List<List<dynamic>> rows = [
      ["Date", "Mood", "Note"]
    ];
    for (var entry in moodEntries) {
      rows.add([entry["date"], entry["mood"], entry["note"] ?? ""]);
    }
    String csvData = const ListToCsvConverter().convert(rows);
    final file = File(path);
    return file.writeAsString(csvData);
  }

  static Future<File> exportToPDF(List<Map<String, dynamic>> moodEntries, String path) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) => pw.ListView.builder(
          itemCount: moodEntries.length,
          itemBuilder: (ctx, i) {
            final e = moodEntries[i];
            return pw.Text("${e["date"]}: ${e["mood"]} - ${e["note"] ?? ""}");
          },
        ),
      ),
    );
    final file = File(path);
    return file.writeAsBytes(await pdf.save());
  }
}
