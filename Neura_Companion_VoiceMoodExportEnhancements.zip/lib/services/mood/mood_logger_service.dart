
class MoodLoggerService {
  static final List<Map<String, dynamic>> _moodEntries = [];

  static void logMood(String mood, {String? note}) {
    final now = DateTime.now().toIso8601String();
    _moodEntries.add({"date": now, "mood": mood, "note": note});
  }

  static List<Map<String, dynamic>> getMoodHistory() {
    return List<Map<String, dynamic>>.from(_moodEntries);
  }
}
