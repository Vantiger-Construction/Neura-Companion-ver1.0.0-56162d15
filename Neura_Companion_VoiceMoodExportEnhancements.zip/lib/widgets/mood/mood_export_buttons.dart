
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import '../../services/mood/mood_export_service.dart';
import '../../services/mood/mood_logger_service.dart';

class MoodExportButtons extends StatelessWidget {
  const MoodExportButtons({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ElevatedButton.icon(
          onPressed: () async {
            final dir = await getApplicationDocumentsDirectory();
            final path = "\${dir.path}/mood_log.csv";
            final entries = MoodLoggerService.getMoodHistory();
            await MoodExportService.exportToCSV(entries, path);
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("CSV exported to \$path")));
            }
          },
          icon: Icon(Icons.file_download),
          label: Text("Export CSV"),
        ),
        SizedBox(width: 10),
        ElevatedButton.icon(
          onPressed: () async {
            final dir = await getApplicationDocumentsDirectory();
            final path = "\${dir.path}/mood_log.pdf";
            final entries = MoodLoggerService.getMoodHistory();
            await MoodExportService.exportToPDF(entries, path);
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("PDF exported to \$path")));
            }
          },
          icon: Icon(Icons.picture_as_pdf),
          label: Text("Export PDF"),
        ),
      ],
    );
  }
}
