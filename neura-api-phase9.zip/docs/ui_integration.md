# Full UI Integration

Embed the React Webhooks Dashboard into your Neura Companion portal:

```jsx
import React from 'react';
import WebhooksDashboard from 'webhooks-dashboard/dist/App';

function MainApp() {
  return (
    <div>
      {/* Other components */}
      <WebhooksDashboard token={userToken} />
    </div>
  );
}
```
