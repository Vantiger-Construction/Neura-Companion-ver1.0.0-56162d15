from fastapi import Request
from sqlmodel import Session
from src.db import get_session
from src.models import AuditLog
from datetime import datetime

async def audit_middleware(request: Request, call_next):
    # Extract user from auth, defaults to 'anonymous'
    token = request.headers.get('Authorization', '')
    user = token.split()[1] if token else 'anonymous'
    path = request.url.path
    method = request.method
    session = next(get_session())
    response = await call_next(request)
    log = AuditLog(user=user, action=method, resource=path, resource_id=None, details=response.status_code)
    session.add(log)
    session.commit()
    session.close()
    return response
