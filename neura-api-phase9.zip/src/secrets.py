import os
from hvac import Client as VaultClient

def get_secret(key: str) -> str:
    vault_addr = os.getenv('VAULT_ADDR')
    vault_token = os.getenv('VAULT_TOKEN')
    if vault_addr and vault_token:
        client = VaultClient(url=vault_addr, token=vault_token)
        secret = client.secrets.kv.v2.read_secret_version(path='neura')[ 'data' ][ 'data' ].get(key)
        if secret:
            return secret
    return os.getenv(key)
