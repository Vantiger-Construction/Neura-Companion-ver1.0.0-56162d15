from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from fastapi import Response

# Existing metrics
REQUEST_COUNT = Counter('request_count', 'Total HTTP Requests', ['method', 'endpoint', 'http_status'])
REQUEST_LATENCY = Histogram('request_latency_seconds', 'HTTP Request latency in seconds', ['method', 'endpoint'])

# New business metrics
FEATURE_USAGE = Counter('feature_usage', 'Count of business feature usage', ['feature'])
ERROR_COUNT = Counter('error_count', 'Count of errors by endpoint', ['endpoint', 'error_type'])

def record_request(method: str, endpoint: str, status: str, latency: float):
    REQUEST_COUNT.labels(method=method, endpoint=endpoint, http_status=status).inc()
    REQUEST_LATENCY.labels(method=method, endpoint=endpoint).observe(latency)

def record_feature(feature: str):
    FEATURE_USAGE.labels(feature=feature).inc()

def record_error(endpoint: str, error_type: str):
    ERROR_COUNT.labels(endpoint=endpoint, error_type=error_type).inc()

def metrics_endpoint():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)
