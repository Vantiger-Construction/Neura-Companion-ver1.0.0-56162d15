# ... existing imports ...
from sqlmodel import SQLModel, Field, Relationship
import datetime
from typing import Optional, List

# Existing models...

class AuditLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    timestamp: datetime.datetime = Field(default_factory=datetime.datetime.utcnow)
    user: str
    action: str
    resource: str
    resource_id: Optional[int]
    details: Optional[str]
