"""add auditlog table

Revision ID: 0002_add_auditlog
Revises: 0001_create_tables
Create Date: 2025-07-30 00:00:00.000000

"""

from alembic import op
from src.models import SQLModel
import sqlalchemy as sa

revision = '0002_add_auditlog'
down_revision = '0001_create_tables'
branch_labels = None
depends_on = None

def upgrade():
    bind = op.get_bind()
    SQLModel.metadata.tables['auditlog'].create(bind)

def downgrade():
    bind = op.get_bind()
    SQLModel.metadata.tables['auditlog'].drop(bind)
