// lib/neura_coach.dart
import 'package:flutter/material.dart';
import 'neura_api_service.dart';

class NeuraCoach extends StatefulWidget {
  final String mood;
  final String userName;
  final bool useAI;

  const NeuraCoach({required this.mood, required this.userName, this.useAI = false});

  @override
  State<NeuraCoach> createState() => _NeuraCoachState();
}

class _NeuraCoachState extends State<NeuraCoach> {
  String feedback = "...";

  @override
  void initState() {
    super.initState();
    getReflection();
  }

  void getReflection() async {
    String reply = widget.useAI
        ? await NeuraAPIService.getPersonalized(widget.userName, widget.mood)
        : await NeuraAPIService.getCoaching(widget.mood);

    setState(() => feedback = reply);
  }

  @override
  Widget build(BuildContext context) {
    return Text(feedback, style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic));
  }
}