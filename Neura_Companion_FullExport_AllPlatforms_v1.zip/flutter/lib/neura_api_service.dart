// lib/neura_api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

class NeuraAPIService {
  static const String baseUrl = "http://localhost:8000";

  static Future<Map<String, dynamic>> sendVoiceInput(String text, String emotion) async {
    final response = await http.post(
      Uri.parse("\$baseUrl/api/voice/input"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"text": text, "emotion": emotion, "viseme": "A"}),
    );
    return jsonDecode(response.body);
  }

  static Future<Map<String, dynamic>> triggerLottie(String emotion, String viseme) async {
    final response = await http.post(
      Uri.parse("\$baseUrl/api/lottie/trigger"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"emotion": emotion, "viseme": viseme}),
    );
    return jsonDecode(response.body);
  }

  static Future<String> getCoaching(String mood) async {
    final response = await http.post(
      Uri.parse("\$baseUrl/api/reflection/generate"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"mood": mood, "timestamp": DateTime.now().toIso8601String()}),
    );
    return jsonDecode(response.body)["reflection"];
  }

  static Future<String> getPersonalized(String name, String mood) async {
    final response = await http.post(
      Uri.parse("\$baseUrl/api/openai/personalized"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"user_name": name, "mood": mood}),
    );
    return jsonDecode(response.body)["reflection"];
  }
}