# 🛡️ Neura Companion — Ban Monitor Suite

This application monitors malicious IPs, triggers alerts, and visualizes ban trends.

## Modules

### 🧩 Admin Dashboard
- View bans and whitelist IPs
- Located at `/dashboard`

### 🛡️ IP Whitelist API
- Manage trusted IPs via REST

### 📘 OpenAPI Documentation
- [Swagger UI `/docs`](http://localhost:4000/docs)
- Includes `/bans`, `/bans/trend(.json)`, `/whitelist`, `/health`

### 🧪 Integration Tests
- Runs via Docker/CI using Jest
- Mocks Redis & Slack
- View coverage at `coverage/index.html`

### 🔁 GitHub CI/CD
- Lint, test, sync OpenAPI, upload Codecov
- Docker build + NPM publish
- Nightly chart cleanup

### 🐳 Docker Runtime
- `make dev` + `.env` support
- Includes Redis

---

## Quick Start

```bash
cp .env.example .env
make dev
```

## Test

```bash
make test
```

---

## License
MIT © Neura Team
