# API Materials

This directory includes:
- **openapi.yaml**: OpenAPI 3.0 specification for the Neura Companion API.
- **postman_collection.json**: Postman collection to test the API.
- **README_API.md**: This file.
