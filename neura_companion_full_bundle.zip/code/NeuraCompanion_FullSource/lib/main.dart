
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'neura_manager.dart';
import 'neura_emotion_engine.dart';
import 'neura_settings_manager.dart';
import 'neura_joke_panel_animated.dart';
import 'neura_dream_journal_screen.dart';
import 'neura_dream_calendar_navigator.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final neuraManager = NeuraManager();
  await neuraManager.init();

  runApp(
    MyApp(neuraManager: neuraManager),
  );
}

class MyApp extends StatelessWidget {
  final NeuraManager neuraManager;

  MyApp({required this.neuraManager});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: neuraManager),
        ChangeNotifierProvider(create: (_) => NeuraEmotionEngine()),
        ChangeNotifierProvider(create: (_) => NeuraSettingsManager()..loadSettings()),
        ChangeNotifierProvider(create: (_) => NeuraJokePreferencesManager()..loadPreferences()),
      ],
      child: Consumer<NeuraSettingsManager>(
        builder: (context, settings, _) {
          return MaterialApp(
            title: 'Neura Companion',
            theme: ThemeData(
              primarySwatch: Colors.deepPurple,
              brightness: Brightness.light,
            ),
            home: HomeScreen(),
          );
        },
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  final List<Widget> _pages = [];

  @override
  void initState() {
    super.initState();
    _pages.add(
      NeuraJokePanelAnimated(
        humorEngine: NeuraHumorEngine(),
        prefs: NeuraJokePreferencesManager()..loadPreferences(),
      ),
    );
    _pages.add(
      NeuraDreamJournalScreen(
        dreamEntries: [],
      ),
    );
    _pages.add(
      NeuraDreamCalendarNavigator(
        dreamEntries: [],
      ),
    );
    _pages.add(
      SettingsScreen(),
    );
  }

  void _onNavTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Neura Companion'),
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onNavTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.mood), label: 'Jokes'),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: 'Dreams'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: 'Calendar'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final settings = Provider.of<NeuraSettingsManager>(context);
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          SwitchListTile(
            title: Text('Enable Voice'),
            value: settings.isVoiceEnabled,
            onChanged: (v) => settings.toggleVoice(v),
          ),
          SwitchListTile(
            title: Text('Quiet Mode'),
            value: settings.quietMode,
            onChanged: (v) => settings.toggleQuietMode(v),
          ),
        ],
      ),
    );
  }
}
