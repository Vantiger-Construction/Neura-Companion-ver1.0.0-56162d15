import 'package:flutter_test/flutter_test.dart';
import 'package:neuracompanionapp/neura_memory_model.dart';

void main() {
  test('Memory model increments correctly', () async {
    final model = NeuraMemoryModel();
    await model.loadMemory(); // should start at default values
    final initialLogs = model.moodLogs;
    await model.incrementMoodLogs();
    expect(model.moodLogs, initialLogs + 1);
  });
}