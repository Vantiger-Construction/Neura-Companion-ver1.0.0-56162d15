# Neura Companion 🌐🤖

Welcome to the official Neura Companion microsite repository. This project represents the public-facing demo, landing page, and live preview of Neura — your emotionally intelligent AI assistant.

---

## 🚀 Features Included

- 🎨 Custom avatar landing page
- 💬 Neura’s real-time AI error handling
- 🌐 GitHub Pages deploy-ready site
- 📦 Bash script for auto deployment
- 🧠 Memory, mood tracking, and VR sync prep

---

## 🔧 Deployment

Run the `deploy_to_github.sh` file after extracting this ZIP to push to GitHub Pages:
```bash
chmod +x deploy_to_github.sh
./deploy_to_github.sh
```

---

## 📄 License

© 2025 Vantiger Construction. All rights reserved.
This content is protected under copyright and intellectual property law.

