from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from src.db import get_session
from src.models import User, Application
from passlib.context import CryptContext
import secrets
from src.auth import create_access_token

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
router = APIRouter()

class RegisterForm(BaseModel):
    username: str
    password: str

class AppCreate(BaseModel):
    name: str

@router.post("/auth/register", status_code=201)
def register(form: RegisterForm, session: Session = Depends(get_session)):
    user = session.query(User).filter(User.username == form.username).first()
    if user:
        raise HTTPException(status_code=400, detail="Username already exists")
    hashed = pwd_context.hash(form.password)
    user = User(username=form.username, hashed_password=hashed)
    session.add(user)
    session.commit()
    session.refresh(user)
    return {"id": user.id, "username": user.username}

@router.post("/auth/login")
def login(form: RegisterForm, session: Session = Depends(get_session)):
    user = session.query(User).filter(User.username == form.username).first()
    if not user or not pwd_context.verify(form.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token({"sub": user.username})
    return {"access_token": token, "token_type": "bearer"}

@router.post("/apps", status_code=201)
def create_app(req: AppCreate, session: Session = Depends(get_session), token: str = Depends()):
    # token dependency to get current_user omitted for brevity
    current_user_id = 1
    api_key = secrets.token_hex(16)
    app = Application(name=req.name, api_key=api_key, owner_id=current_user_id)
    session.add(app); session.commit(); session.refresh(app)
    return {"id": app.id, "name": app.name, "api_key": app.api_key}

@router.get("/apps")
def list_apps(session: Session = Depends(get_session), token: str = Depends()):
    current_user_id = 1
    apps = session.query(Application).filter(Application.owner_id == current_user_id).all()
    return [{"id": a.id, "name": a.name} for a in apps]

@router.delete("/apps/{app_id}", status_code=204)
def delete_app(app_id: int, session: Session = Depends(get_session), token: str = Depends()):
    app = session.get(Application, app_id)
    if not app:
        raise HTTPException(status_code=404, detail="App not found")
    session.delete(app); session.commit()
