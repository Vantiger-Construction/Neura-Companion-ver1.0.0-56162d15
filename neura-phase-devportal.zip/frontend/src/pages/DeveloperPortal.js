import React, { useEffect, useState } from 'react';
import axios from 'axios';
export default function DeveloperPortal() {
  const [apps, setApps] = useState([]);
  const [name, setName] = useState('');
  const token = localStorage.getItem('neura_token');
  const fetch = () => axios.get('/v1/apps', { headers:{Authorization:`Bearer ${token}`} })
    .then(res=>setApps(res.data));
  useEffect(fetch, []);
  const create = () => {
    axios.post('/v1/apps', { name }, { headers:{Authorization:`Bearer ${token}`} })
      .then(fetch);
  };
  return (
    <div><h2>Developer Portal</h2>
      <input placeholder="App Name" value={name} onChange={e=>setName(e.target.value)}/>
      <button onClick={create}>Create App</button>
      <ul>{apps.map(a=><li key={a.id}>{a.name}</li>)}</ul>
    </div>
  );
}
