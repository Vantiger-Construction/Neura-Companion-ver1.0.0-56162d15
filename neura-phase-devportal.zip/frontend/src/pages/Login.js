import React, { useState } from 'react';
import axios from 'axios';
export default function Login({onLogin}) {
  const [u, setU] = useState(''), [p, setP] = useState('');
  const submit = () => {
    axios.post('/v1/auth/login', { username: u, password: p })
      .then(res => { localStorage.setItem('neura_token', res.data.access_token); onLogin(); })
      .catch(() => alert('Invalid credentials'));
  };
  return (
    <div><h2>Login</h2>
      <input placeholder="username" value={u} onChange={e=>setU(e.target.value)}/>
      <input placeholder="password" type="password" value={p} onChange={e=>setP(e.target.value)}/>
      <button onClick={submit}>Login</button>
    </div>
  );
}
