import React, { useState } from 'react';
import axios from 'axios';
export default function Register() {
  const [u, setU] = useState(''), [p, setP] = useState('');
  const submit = () => {
    axios.post('/v1/auth/register', { username: u, password: p })
      .then(() => alert('Registered!'))
      .catch(e => alert(e.response.data.detail));
  };
  return (
    <div><h2>Register</h2>
      <input placeholder="username" value={u} onChange={e=>setU(e.target.value)}/>
      <input placeholder="password" type="password" value={p} onChange={e=>setP(e.target.value)}/>
      <button onClick={submit}>Register</button>
    </div>
  );
}
