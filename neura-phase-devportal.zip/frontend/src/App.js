import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Register from './pages/Register';
import Login from './pages/Login';
import DeveloperPortal from './pages/DeveloperPortal';
function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  return (
    <BrowserRouter>
      <nav><Link to="/register">Register</Link> | <Link to="/login">Login</Link> | <Link to="/developer">Portal</Link></nav>
      <Routes>
        <Route path="/register" element={<Register/>}/>
        <Route path="/login" element={<Login onLogin={()=>setLoggedIn(true)}/>}/>
        <Route path="/developer" element={loggedIn?<DeveloperPortal/>:<Login onLogin={()=>setLoggedIn(true)}/>}/>
      </Routes>
    </BrowserRouter>
  );
}
export default App;
