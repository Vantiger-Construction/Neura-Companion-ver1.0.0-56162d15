# Neura Lottie Animation

This bundle contains the Lottie JSON and preview for Neura's wave animation.

Includes:
- wave_smile_hello.json
- idle_breathing_glow.json