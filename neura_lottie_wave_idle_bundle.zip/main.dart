
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

void main() => runApp(const NeuraApp());

class NeuraApp extends StatelessWidget {
  const NeuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.asset('assets/wave_smile_hello.json'),
            SizedBox(height: 20),
            Lottie.asset('assets/idle_breathing_glow.json'),
          ],
        ),
      ),
    );
  }
}
