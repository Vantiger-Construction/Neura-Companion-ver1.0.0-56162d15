import 'package:flutter/material.dart';
import 'neura_controller.dart';

class PenthouseScene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: NeuraController(),
    );
  }
}