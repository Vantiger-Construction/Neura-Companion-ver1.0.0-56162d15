import 'package:flutter/material.dart';

class FloatingDashboard extends StatelessWidget {
  final Function(String) onRoomTap;

  FloatingDashboard({required this.onRoomTap});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 40,
      right: 20,
      child: Card(
        color: Colors.black87,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(Icons.self_improvement, color: Colors.cyan),
              tooltip: "Meditation Room",
              onPressed: () => onRoomTap("meditation"),
            ),
            IconButton(
              icon: Icon(Icons.bedtime, color: Colors.deepPurple),
              tooltip: "Dream Room",
              onPressed: () => onRoomTap("dream"),
            ),
            IconButton(
              icon: Icon(Icons.analytics, color: Colors.greenAccent),
              tooltip: "Reflection Room",
              onPressed: () => onRoomTap("reflection"),
            ),
          ],
        ),
      ),
    );
  }
}