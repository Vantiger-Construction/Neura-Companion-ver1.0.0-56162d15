import 'package:flutter/material.dart';

class VRPopupRoomSelector extends StatelessWidget {
  final Function(String) onEnterRoom;

  VRPopupRoomSelector({required this.onEnterRoom});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.black,
      title: Text("VR Room Selector", style: TextStyle(color: Colors.white)),
      content: Wrap(
        spacing: 10,
        children: [
          ElevatedButton(
            onPressed: () => onEnterRoom('meditation'),
            child: Text('Meditation Room'),
          ),
          ElevatedButton(
            onPressed: () => onEnterRoom('dream'),
            child: Text('Dream Room'),
          ),
          ElevatedButton(
            onPressed: () => onEnterRoom('reflection'),
            child: Text('Reflection Room'),
          ),
        ],
      ),
    );
  }
}