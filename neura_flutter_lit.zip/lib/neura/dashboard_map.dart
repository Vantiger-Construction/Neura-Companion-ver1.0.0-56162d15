import 'package:flutter/material.dart';

class DashboardMap extends StatelessWidget {
  final Function(String) onRoomSelect;

  DashboardMap({required this.onRoomSelect});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text("Choose Your Room"),
      backgroundColor: Colors.grey[900],
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ElevatedButton(onPressed: () => onRoomSelect('meditation'), child: Text("Meditation Room")),
          ElevatedButton(onPressed: () => onRoomSelect('dream')), // etc.
        ],
      ),
    );
  }
}