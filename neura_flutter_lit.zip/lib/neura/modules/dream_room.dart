import 'package:flutter/material.dart';

class DreamRoom extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo.shade900,
      body: Center(
        child: Text(
          'Welcome to the Dream Room',
          style: TextStyle(color: Colors.white, fontSize: 24),
        ),
      ),
    );
  }
}