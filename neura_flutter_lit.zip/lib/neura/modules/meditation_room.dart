import 'package:flutter/material.dart';

class MeditationRoom extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple.shade900,
      body: Center(
        child: Text(
          'Welcome to the Meditation Room',
          style: TextStyle(color: Colors.white, fontSize: 24),
        ),
      ),
    );
  }
}