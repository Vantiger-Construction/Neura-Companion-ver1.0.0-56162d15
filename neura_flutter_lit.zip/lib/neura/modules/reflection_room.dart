import 'package:flutter/material.dart';

class ReflectionRoom extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal.shade900,
      body: Center(
        child: Text(
          'Welcome to the Reflection Room',
          style: TextStyle(color: Colors.white, fontSize: 24),
        ),
      ),
    );
  }
}