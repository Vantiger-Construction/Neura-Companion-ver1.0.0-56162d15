import 'package:speech_to_text/speech_to_text.dart' as stt;

class VoiceInput {
  final stt.SpeechToText _speech = stt.SpeechToText();

  Future<void> initSpeech(Function(String) onResult) async {
    bool available = await _speech.initialize();
    if (available) {
      _speech.listen(onResult: (val) => onResult(val.recognizedWords));
    }
  }

  void stopListening() {
    _speech.stop();
  }
}