import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:audioplayers/audioplayers.dart';

class NeuraController extends StatefulWidget {
  @override
  _NeuraControllerState createState() => _NeuraControllerState();
}

class _NeuraControllerState extends State<NeuraController> {
  final AudioPlayer _player = AudioPlayer();

  void playVoice(String emotion) async {
    await _player.play(AssetSource('neura_penthouse/voice_$emotion.mp3'));
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Lottie.asset('assets/neura_penthouse/idle.json'),
    );
  }
}