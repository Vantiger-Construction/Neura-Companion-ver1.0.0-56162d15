
import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'dart:typed_data';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class MoodboardExportHelper {
  static Future<void> exportMoodboard(GlobalKey repaintKey) async {
    try {
      RenderRepaintBoundary boundary = repaintKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
      ui.Image image = await boundary.toImage(pixelRatio: 3.0);
      ByteData? byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      Uint8List pngBytes = byteData!.buffer.asUint8List();

      if (await Permission.storage.request().isGranted) {
        final directory = await getExternalStorageDirectory();
        final file = File('\${directory!.path}/moodboard_\${DateTime.now().millisecondsSinceEpoch}.png');
        await file.writeAsBytes(pngBytes);
        print("Moodboard PNG saved: \${file.path}");
      }
    } catch (e) {
      print("Error exporting moodboard: \$e");
    }
  }
}
