package backend.models

data class Ritual(val id: String, val name: String, val description: String)
data class Goal(val id: String, val title: String, val completed: Boolean)
data class MoodEntry(val id: String, val timestamp: Long, val moodLabel: String, val notes: String)
data class MeditationSession(val id: String, val durationSec: Int, val instructions: String)
data class TherapistCheckIn(val id: String, val timestamp: Long, val notes: String)
data class PayItForward(val id: String, val action: String, val date: Long)
data class DreamEntry(val id: String, val date: Long, val description: String, val interpretation: String)
data class Feedback(val id: String, val user: String, val comments: String)
