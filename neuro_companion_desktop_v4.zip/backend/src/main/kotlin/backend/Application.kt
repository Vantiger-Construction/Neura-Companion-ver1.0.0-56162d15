package backend

import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.application.*
import io.ktor.routing.*
import io.ktor.response.*
import io.ktor.request.*
import io.ktor.features.*
import io.ktor.serialization.*
import backend.models.*
import java.util.concurrent.ConcurrentHashMap
import io.ktor.http.*

fun main() {
    val rituals = ConcurrentHashMap<String, Ritual>()
    val goals = ConcurrentHashMap<String, Goal>()
    val moods = ConcurrentHashMap<String, MoodEntry>()
    val meditations = ConcurrentHashMap<String, MeditationSession>()
    val checkIns = ConcurrentHashMap<String, TherapistCheckIn>()
    val payItForward = ConcurrentHashMap<String, PayItForward>()
    val dreams = ConcurrentHashMap<String, DreamEntry>()
    val feedbacks = ConcurrentHashMap<String, Feedback>()

    embeddedServer(Netty, port = 8080) {
        install(ContentNegotiation) {
            json()
        }
        routing {
            route("/rituals") {
                get { call.respond(rituals.values.toList()) }
                post {
                    val r = call.receive<Ritual>()
                    rituals[r.id] = r
                    call.respondText("Created", status = HttpStatusCode.Created)
                }
            }
            // Add other routes similarly...
        }
    }.start(wait = true)
}
