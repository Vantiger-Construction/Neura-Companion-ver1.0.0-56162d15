const express = require('express');
const router = express.Router();
router.post('/interpret', (req, res) => {
  const { transcript } = req.body;
  res.json({ interpretation: 'This dream means you need more rest.' });
});
router.get('/replay/:userId', (req, res) => {
  res.json({ userId: req.params.userId, replay: [] });
});
module.exports = router;