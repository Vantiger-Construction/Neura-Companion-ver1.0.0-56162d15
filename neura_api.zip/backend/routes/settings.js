const express = require('express');
const router = express.Router();
let settingsStore = {};
router.get('/:userId', (req, res) => res.json(settingsStore[req.params.userId] || {}));
router.post('/:userId', (req, res) => {
  settingsStore[req.params.userId] = req.body;
  res.json({ success: true });
});
module.exports = router;