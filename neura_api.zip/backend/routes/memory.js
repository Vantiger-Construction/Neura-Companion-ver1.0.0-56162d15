const express = require('express');
const router = express.Router();
let memoryStore = {};
router.get('/:userId', (req, res) => res.json(memoryStore[req.params.userId] || []));
router.post('/:userId', (req, res) => {
  memoryStore[req.params.userId] = memoryStore[req.params.userId] || [];
  memoryStore[req.params.userId].push(req.body);
  res.json({ success: true });
});
module.exports = router;