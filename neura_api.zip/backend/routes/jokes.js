const express = require('express');
const router = express.Router();
let jokes = [{ id: 1, text: 'Why did the neuron cross the synapse? To get to the other side!' }];
router.get('/', (req, res) => res.json(jokes));
router.post('/:id/rate', (req, res) => {
  const id = parseInt(req.params.id);
  const { rating } = req.body;
  res.json({ id, rating });
});
module.exports = router;