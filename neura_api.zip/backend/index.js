const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const jokes = require('./routes/jokes');
const dreams = require('./routes/dreams');
const settings = require('./routes/settings');
const memory = require('./routes/memory');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use('/api/jokes', jokes);
app.use('/api/dreams', dreams);
app.use('/api/settings', settings);
app.use('/api/memory', memory);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Neura API running on port ${PORT}`));
