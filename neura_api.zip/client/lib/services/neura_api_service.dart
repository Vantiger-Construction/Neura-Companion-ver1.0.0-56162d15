import 'dart:convert';
import 'package:http/http.dart' as http;

class NeuraApiService {
  final String baseUrl;
  NeuraApiService({required this.baseUrl});

  Future<List<dynamic>> fetchJokes() async {
    final res = await http.get(Uri.parse('\$baseUrl/api/jokes'));
    return jsonDecode(res.body);
  }

  Future<void> rateJoke(int id, int rating) async {
    await http.post(Uri.parse('\$baseUrl/api/jokes/\$id/rate'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'rating': rating}));
  }

  Future<String> interpretDream(String transcript) async {
    final res = await http.post(Uri.parse('\$baseUrl/api/dreams/interpret'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'transcript': transcript}));
    return jsonDecode(res.body)['interpretation'];
  }

  Future<List<dynamic>> fetchDreamReplay(String userId) async {
    final res = await http.get(Uri.parse('\$baseUrl/api/dreams/replay/\$userId'));
    return jsonDecode(res.body)['replay'];
  }

  Future<Map<String, dynamic>> getSettings(String userId) async {
    final res = await http.get(Uri.parse('\$baseUrl/api/settings/\$userId'));
    return jsonDecode(res.body);
  }

  Future<void> updateSettings(String userId, Map<String, dynamic> settings) async {
    await http.post(Uri.parse('\$baseUrl/api/settings/\$userId'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(settings));
  }

  Future<List<dynamic>> fetchMemory(String userId) async {
    final res = await http.get(Uri.parse('\$baseUrl/api/memory/\$userId'));
    return jsonDecode(res.body);
  }

  Future<void> addMemory(String userId, Map<String, dynamic> memory) async {
    await http.post(Uri.parse('\$baseUrl/api/memory/\$userId'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(memory));
  }
}
