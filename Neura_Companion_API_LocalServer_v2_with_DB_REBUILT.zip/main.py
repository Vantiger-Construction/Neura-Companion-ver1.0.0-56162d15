from fastapi import FastAPI
from app.routes import voice, persona, journal, emotion, sync

app = FastAPI(title="Neura Companion API")

app.include_router(persona.router, prefix="/api/ai/persona")
app.include_router(voice.router, prefix="/api/voice")
app.include_router(journal.router, prefix="/api/journal")
app.include_router(emotion.router, prefix="/api/emotion")
app.include_router(sync.router, prefix="/api/sync")

@app.get("/")
def root():
    return {"status": "Neura API is running"}