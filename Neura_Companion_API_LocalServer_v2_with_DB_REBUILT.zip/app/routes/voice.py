from fastapi import APIRouter, Body

router = APIRouter()

@router.post("/input")
def handle_voice_input(data: dict = Body(...)):
    # Placeholder logic for speech + viseme
    return {"status": "Voice input received", "data": data}