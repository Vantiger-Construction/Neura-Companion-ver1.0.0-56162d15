import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'pages/landing_page.dart';
import 'pages/login_page.dart';
import 'pages/dashboard_page.dart';
import 'pages/mood_page.dart';
import 'pages/export_page.dart';
import 'pages/admin_page.dart';
import 'pages/org_page.dart';
import 'pages/analytics_page.dart';
import 'pages/notifications_page.dart';
import 'pages/copilot_page.dart';
import 'pages/integrations_page.dart';
import 'pages/about_page.dart';
import 'pages/contact_page.dart';
import 'pages/profile_page.dart';
import 'pages/push_notifications_page.dart';
import 'providers/mood_provider.dart';
import 'widgets/notification_bell.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => MoodProvider()),
        ChangeNotifierProvider(create: (_) => NotificationProvider()),
      ],
      child: NeuraApp(),
    ),
  );
}

class NeuraApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        scaffoldBackgroundColor: Colors.grey[100],
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.indigo,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => LandingPage(),
        '/login': (context) => LoginPage(),
        '/dashboard': (context) => DashboardPage(),
        '/moods': (context) => MoodPage(),
        '/export': (context) => ExportPage(),
        '/admin': (context) => AdminPage(),
        '/org': (context) => OrgPage(),
        '/analytics': (context) => AnalyticsPage(),
        '/notifications': (context) => NotificationsPage(),
        '/copilot': (context) => CopilotPage(),
        '/integrations': (context) => IntegrationsPage(),
        '/about': (context) => AboutPage(),
        '/contact': (context) => ContactPage(),
        '/profile': (context) => ProfilePage(),
        '/push': (context) => PushNotificationsPage(),
      },
    );
  }
}
