import 'package:flutter/material.dart'; class LoginPage extends StatelessWidget { @override Widget build(BuildContext context) => Scaffold(body: Center(child: Text('Login Page'))); }
