import 'package:http/http.dart' as http;
import 'dart:convert';
import 'models/mood.dart';

class NeuraApi {
  static const String baseUrl = 'http://localhost:8000';
  static String? _token;

  static void setToken(String token) { _token = token; }

  static Future<String?> login(String username, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/v1/auth/token'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {'username': username, 'password': password},
    );
    if (response.statusCode == 200) {
      _token = jsonDecode(response.body)['access_token'];
      return _token;
    }
    return null;
  }

  static Future<List<Mood>> fetchMoods() async {
    final resp = await http.get(
      Uri.parse('$baseUrl/api/v1/mood/'),
      headers: {'Authorization': 'Bearer $_token'},
    );
    if (resp.statusCode == 200) {
      final list = jsonDecode(resp.body) as List;
      return list.map((json) => Mood.fromJson(json)).toList();
    }
    return [];
  }

  static Future<void> submitMood(String mood, String? note) async {
    await http.post(
      Uri.parse('$baseUrl/api/v1/mood/'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $_token',
      },
      body: jsonEncode({'mood': mood, 'note': note}),
    );
  }

  // ...Add more backend methods as needed for all modules (stubbed here)...

  static Future<void> sendSlack(String msg) async {}
  static Future<void> sendZapier(String msg) async {}
  static Future<void> sendSms(String phone, String msg) async {}
  static Future<String> askCopilot(String query) async => "Copilot AI response (stub)";
}
