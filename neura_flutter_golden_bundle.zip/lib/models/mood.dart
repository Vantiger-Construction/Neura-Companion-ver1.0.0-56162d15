class Mood {
  final int id;
  final String mood;
  final String? note;
  final DateTime timestamp;
  Mood({required this.id, required this.mood, this.note, required this.timestamp});

  factory Mood.fromJson(Map<String, dynamic> json) => Mood(
    id: json['id'],
    mood: json['mood'],
    note: json['note'],
    timestamp: DateTime.parse(json['timestamp']),
  );
}
