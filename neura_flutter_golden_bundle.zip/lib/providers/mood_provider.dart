import 'package:flutter/material.dart';
import '../models/mood.dart';
import '../api.dart';

class MoodProvider with ChangeNotifier {
  List<Mood> _moods = [];
  List<Mood> get moods => _moods;

  Future<void> fetchMoods() async {
    _moods = await NeuraApi.fetchMoods();
    notifyListeners();
  }

  Future<void> submitMood(String mood, String? note) async {
    await NeuraApi.submitMood(mood, note);
    await fetchMoods();
  }
}
