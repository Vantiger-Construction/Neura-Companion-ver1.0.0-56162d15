# Neura Flutter Golden Bundle

1. `flutter pub get`
2. Set your API base URL in `lib/api.dart`
3. `flutter run -d chrome` (for web) or `flutter run` (for mobile/emulator)

All modules and navigation included. Wire up your backend endpoints and swap stub pages for full implementations as you grow!
