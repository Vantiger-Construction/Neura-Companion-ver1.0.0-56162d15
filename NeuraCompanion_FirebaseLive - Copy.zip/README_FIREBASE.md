
# Firebase Hosting - Neura Companion

Deploy with:
  firebase deploy --only hosting

Suggested live domain:
  https://neura-companion.firebaseapp.com

To add a custom domain (like https://neura.app):
1. Go to Firebase Console > Hosting > Add Custom Domain
2. Point DNS to Firebase's IPs
3. Enable SSL and deploy

You can use this folder for staging or production.
